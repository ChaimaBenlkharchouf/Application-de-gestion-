<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Acceuil</title>

    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="./css/all.css">


    <!-- --------- Owl-Carousel ------------------->
    <link rel="stylesheet" href="./css/owl.carousel.min.css">
    <link rel="stylesheet" href="./css/owl.theme.default.min.css">

    <!-- ------------ AOS Library ------------------------- -->
    <link rel="stylesheet" href="./css/aos.css">

    <!-- Custom Style   -->



        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="viewport" content="width=device-width, initial-scale=1">
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<Style>


@import url('../css/fonts.css');


html, body{
    margin: 0%;
    box-sizing: border-box;
    overflow-x: hidden;
}

:root{

    /*      Theme colors        */
    --text-gray: #3f4954;
    --text-light : #686666da;
    --bg-color: #0f0f0f;
    --white: #ffffff;
    --midnight: #104f55;

    /* gradient color   */
    --sky: linear-gradient(120deg, #a1c4fd 0%, #c2e9fb 100%);

    /*      theme font-family   */
    --Abel: 'Abel', cursive;
    --Anton: 'Anton', cursive;
    --Josefin : 'Josefin', cursive;
    --Lexend: 'Lexend', cursive;
    --Livvic : 'Livvic', cursive;
}


/* ---------------- Global Classes ---------------*/

a{
    text-decoration: none;
    color: var(--text-gray);
}

.flex-row{
    display: flex;
    flex-direction: row;    
    flex-wrap: wrap;
}

ul{
    list-style-type: none;
}

h1{
    font-family: var(--Lexend);
    font-size: 2.5rem;
}

h2{
    font-family: var(--Lexend);
}

h3{
    font-family: var(--Abel);
    font-size: 1.3rem;
}

button.btn{
    border: none;
    border-radius: 2rem;
    padding: 1rem 3rem;
    font-size: 1rem;
    font-family: var(--Livvic);
    cursor: pointer;
}

span{
    font-family: var(--Abel);
}

.container{
    margin: 0 5vw;
}

.text-gray{
    color: var(--text-gray);
}

p{
    font-family: var(--Lexend);
    color: var(--text-light);
}

/* ------x------- Global Classes -------x-------*/

/* --------------- navbar ----------------- */

.nav{
    background: white;
    padding: 0 2rem;
    height: 0rem;
    min-height: 10vh;
    overflow: hidden;
    transition: height 1s ease-in-out;
}

.nav .nav-menu{    
    justify-content: space-between;
}

.nav .toggle-collapse{
    position: absolute;
    top: 0%;
    width: 90%;
    cursor: pointer;
    display: none;
}

.nav .toggle-collapse .toggle-icons{
    display: flex;
    justify-content: flex-end;
    padding: 1.7rem 0;
}

.nav .toggle-collapse .toggle-icons i{
    font-size: 1.4rem;
    color: var(--text-gray);
}

.collapse{
    height: 30rem;
}

.nav .nav-items{
    display: flex;
    margin: 0;
}

.nav .nav-items .nav-link{
    padding: 1.6rem 1rem;
    font-size: 1.1rem;
    position: relative;
    font-family: var(--Abel);
    font-size: 1.1rem;
}

.nav .nav-items .nav-link:hover{
    background-color: var(--midnight);
}

.nav .nav-items .nav-link:hover a{
    color: var(--white);
}

.nav .nav-brand a{
    font-size: 1.6rem;
    padding: 1rem 0;
    display: block;
    font-family: var(--Lexend);
    font-size: 1.6rem;
}

.nav .social{
    padding: 1.4rem 0
}

.nav .social i{
    padding: 0 .2rem;
}

.nav .social i:hover{
    color: #a1c4cf;
}

/* -------x------- navbar ---------x------- */


/* ----------------- Main Content----------- */

/* --------------- Site title ---------------- */
main .site-title{
    background-color: #D2B4DE ;
    background-size: cover;
    height: 10vh;
    display: flex;
    justify-content: center;
}

main .site-title .site-background{
    padding-top: 10rem;
    text-align: center;
    color: var(--white);
}

main .site-title h1, h3{
    margin: .3rem;
}

main .site-title .btn{
    margin: 1.8rem;
    background: var(--sky);
}

main .site-title .btn:hover{
    background: transparent;
    border: 1px solid var(--white);
    color: var(--white);
}

/* --------x------ Site title --------x------- */

/* --------------- Blog Carousel ------------ */

main .blog{
    background: url('./assets/Abract01.png');
    background-repeat: no-repeat;
    background-position: right;
    height: 100vh;
    width: 100%;
    background-size: 65%;
}

main .blog .blog-post{
    padding-top: 6rem;
}

main .blog-post .blog-content{
    display: flex;
    flex-direction: column;
    text-align: center;
    width: 80%;
    margin: 3rem 2rem;
    box-shadow: 0 15px 20px rgba(0, 0, 0, 0.2);
}

main .blog-content .blog-title{
    padding: 2rem 0;
}

main .blog-content .btn-blog{
    padding: .7rem 2rem;
    background: var(--sky);
    margin: .5rem;
}

main .blog-content span{
    display: block;
}

section .container .owl-nav{
    position: absolute;
    top: 0%;
    margin: 0 auto;
    width: 100%;
}

.owl-nav .owl-prev .owl-nav-prev,
.owl-nav .owl-next .owl-nav-next{
    color: var(--text-gray);
    background: transparent;
    font-size: 2rem;
}

.owl-theme .owl-nav [class*='owl-']:hover{
    background: transparent;
    color: var(--midnight);
}

.owl-theme .owl-nav [class*='owl-']{
    outline: none;
}


/* ---------------- Site Content ----------------*/

main .site-content{
    display: grid;
    grid-template-columns: 70% 30%;
}

main .post-content{
    width: 100%;
    
}

main .site-content .post-content > .post-image, .post-title{
    padding: 1rem 2rem;
    position: relative;
}

main .site-content .post-content > .post-image .post-info{
    background: var(--sky);
    padding: 1rem;
    position: absolute;
    bottom: 0%;
    left: 20vw;
    border-radius: 3rem;
}

main .site-content .post-content > .post-image > div{
    overflow: hidden;
}

main .site-content .post-content > .post-image .img{
    width: 100%;
    transition: all 1s ease;
}

main .site-content .post-content > .post-image .img:hover{
    transform: scale(1.3);
}

main .site-content .post-content > .post-image .post-info span{
    margin: 0 .5rem;
}

main .post-content .post-title a{
    font-family: var(--Anton);
    font-size: 1.5rem;
}

.site-content .post-content .post-title .post-btn{
    border-radius: 0;
    padding: .7rem 1.5rem;
    background: var(--sky);
}

.site-content .pagination{
    justify-content: center;
    color: var(--text-gray);
    margin: 4rem 0;
}

.site-content .pagination a{
    padding: .6rem .9rem;
    border-radius: 2rem;
    margin: 0 .3rem;
    font-family: var(--Lexend);
}

.site-content .pagination .pages{
    background: var(--text-gray);
    color: var(--white);
}

/* -------x Site Content x-------*/


/* --------------- Sidebar ----------------------- */

.site-content > .sidebar .category-list{
    font-family: var(--Livvic);   
}

.site-content > .sidebar .category-list .list-items{
    background: var(--sky);
    padding: .4rem 1rem;
    margin: .8rem 0;
    border-radius: 3rem;
    width: 70%;
    display: flex;
    justify-content: space-between;
}

.site-content > .sidebar .category-list .list-items a{
    color:  black;
}

.site-content .sidebar .popular-post .post-content{
    padding: 1rem 0;
}

.site-content .sidebar .popular-post h2{
    padding-top: 8rem;
}

.site-content .sidebar .popular-post .post-info{
    padding: .4rem .1rem !important;
    bottom: 0rem !important;
    left: 1.5rem !important;
    border-radius: 0rem !important;
    background: white !important;
}

.site-content .sidebar .popular-post .post-title a{
    font-size: 1rem;
}

.site-content .sidebar .newsletter{
    padding-top: 10rem;
}

.site-content .sidebar .newsletter .form-element{
    padding: .5rem 2rem;
}

.site-content .sidebar .newsletter .input-element{
    width: 80%;
    height: 1.9rem;
    padding: .3rem .5rem;
    font-family: var(--Lexend);
    font-size: 1rem;
}

.site-content .sidebar .newsletter .form-btn{
    border-radius: 0;
    padding: .8rem 32%;
    margin: 1rem 0;
    background: var(--sky);
}

.site-content .sidebar .popular-tags{
    padding: 5rem 0;
}

.site-content .sidebar .popular-tags .tags .tag{
    background: var(--sky);
    padding: .4rem 1rem;
    border-radius: 3rem;
    margin: .4rem .6rem;
}




/* ----------------- Footer --------------------- */

footer.footer{
    height: 100%;
    background: var(--bg-color);
    position: relative;
}

footer.footer .container{
    display: grid;
    grid-template-columns: repeat(4, 1fr);
}

footer.footer .container > div{
    flex-grow: 1;
    flex-basis: 0;
    padding: 3rem .9rem;
}

footer.footer .container h2{
    color: var(--white);
}

footer.footer .newsletter .form-element{
    background: black;
    display: inline-block;
}

footer.footer .newsletter .form-element input{
    padding: .5rem .7rem;
    border: none;
    background: transparent;
    color: white;
    font-family: var(--Josefin);
    font-size: 1rem;
    width: 74%;
}

footer.footer .newsletter .form-element span{
    background: var(--sky);
    padding: .5rem .7rem;
    cursor: pointer;
}

footer.footer .instagram div > img{
    display: inline-block;
    width: 25%;
    height: 50%;
    margin: .3rem .4rem;
}

footer.footer .follow div i{
    color: var(--white);
    padding: 0 .4rem;
}

footer.footer .rights{
    justify-content: center;
    font-family: var(--Josefin);
}

footer.footer .rights h4 a{
    color: var(--white);
}

footer.footer .move-up{
    position: absolute;
    right: 6%;
    top: 50%;
}

footer.footer .move-up span{
    color: var(--midnight);
}

footer.footer .move-up span:hover{
    color: var(--white);
    cursor: pointer;
}

/* ---------x--*          */

@media only screen and (max-width: 1130px){
    .site-content .post-content > .post-image .post-info{
        left: 2rem !important;
        bottom: 1.2rem !important;
        border-radius: 0% !important;
    }

    .site-content .sidebar .popular-post .post-info{
        display: none !important;
    }

    footer.footer .container{
        grid-template-columns: repeat(2, 1fr);
    }

}

/*      x        x     */



@media only screen and (max-width: 750px){
    .nav .nav-menu, .nav .nav-items{
        flex-direction: column;
    }

    .nav .toggle-collapse{
        display: initial;
    }

    main .site-content{
        grid-template-columns: 100%;
    }

    footer.footer .container{
        grid-template-columns: repeat(1, 1fr);
    }

}


/*        x          x     */



@media only screen and (max-width: 520px){
    main .blog{
        height: 125vh;
    }

    .site-content .post-content > .post-image .post-info{
        display: none;
    }

    footer.footer .container > div{
        padding:  1rem .9rem !important;
    }

    footer .rights{
        padding: 0 1.4rem;
        text-align: center;
    }

    nav .toggle-collapse{
        width: 80% !important;
    }

}

/*        x     style for menu      x     */


</style>





    <style>
       
       *{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Poppins' , sans-serif;

}
body{
    background: #f2f2f2;
}
nav{
    background: #1b1b1b;
}
nav:after{
    content: '';
    clear: both;
    display: table;
}
nav .logo{
    float: left;
    color: white;
    font-size: 27px;
    font-weight: 600;
    line-height: 70px;
    padding-left: 60px;

}
nav ul{
    float: right;
    list-style: none;
    margin-right: 40px;
    position: relative;
}
nav ul li{
    float: left;
    display: inline-block;
    background: #1b1b1b;
    margin: 0 5px;
}

nav ul li a{
    color: white;
    text-decoration: none;
    line-height: 70px;
    font-size: 14px;
    padding: 8px 15px;
}
nav ul li a:hover{
    color: cyan;
    border-radius:  5px;
    box-shadow:  0 0 5ps #33ffff,
                 0 0 5ps #66ffff;

}
nav ul ul li a:hover{
    color: cyan;
    box-shadow: none;
}
nav ul ul{
    position: absolute;
    top: 90px;
    border-top: 3px solid cyan;
    opacity: 0;
    visibility: hidden;
    transition: top .3s;
}

nav ul ul ul{
    border-top: none;
}
nav ul li:hover > ul{
    top: 70px;
    opacity: 1;
    visibility: visible;
}
nav ul ul li{
    position: relative;
    margin : 0px;
    width: 150px;
    float: none;
    display :list-item;
    border-bottom: 1px solid rgba(0,0,0,0,3);
}
nav ul ul li a{
    line-height: 50px;
}
nav ul ul ul li{
    position: relative;
    top: -70px;
    left: 150px;

}
.fa-plus{
    margin-left: 40px;
    font-size: 18px;
}
.show, .icon, input{
    display: none;

}
@media all and (max-width: 968px){
    nav ul{
        margin-right: 0px;
        float: left;
    }
    nav .logo{
        padding-left: 30px;
        width: 100%;
    }
    nav ul li, nav ul ul li{
        display: block;
        width: 100%;

    }
    nav ul ul {
        top: 70px;
        position: static;
        border-top: none;
        float: none;
        display: none;
        opacity: 1;
        visibility: visible;
    }

    nav ul ul ul li{
        position: static;
    }
    nav ul ul li{
        border-bottom: 0px;
    }
    nav ul ul  a{
        padding-left:40px;
    }
    nav ul ul ul a{
        padding-left:80px;
    }
    .show{
        display: block;
        color: white;
        font-size: 18px;
        padding: 0 20px;
        line-height: 70px;
        cursor: pointer;
    }
    .show :hover{
        color: cyan;
    }
    .icon{
        display: block;
        color: white;
        position: absolute;
        right: 40px;
        line-height: 70px;
        font-size: 25px;
        cursor: pointer;

    }
    nav ul li a:hover{
        box-shadow: none;
    }
    .show + a, ul{
        display: none;
    }
    [id^=btn]:checked + ul{
        display: block;
    }
}
div .a{ 
  width: 400px;
  height: 50px;
  background: ;
  position: relative;
  animation: mymove 5s infinite;
}

@keyframes mymove {
  from {right: 0px;}
  to {right: 200px;}
}
   </style>

</head>

<body>

    <!-- ----------------------------  Navigation ---------------------------------------------- -->


        
        <nav>
            <div class="logo"><a href="../face/Acceuil.php" style="color:#EB984E;"> <img src="../images/mr.jpg" alt="" width="30">ETAT CIVIL</a></div>
            <label for="btn" class="icon">
                <span class="fa fa-bars"></span>
            </label>
            <input type="checkbox"  id="btn">
            <ul>
                <li >
                    <a href="../face/Acceuil.php"> <span class=" w3-xlarge  fa fa-home"></span> Acceuil</a>
                </li>
              
               
                <li>
                    <label for="btn-1" class="show">Guide de l'état civil   +</label>

                    <a href="#">  &nbsp;Guide de l'état civil</a>
                    <input type="checkbox"  id="btn-1">
                    <ul>
                         <li><a href="bureau.php" >Les bureaux </a></li>
                        <li><a href="registreF.php">Les registres </a></li>
                        <li><a href="statistique.php">Les statistiques </a></li>
                     </ul>
                </li>
                <li>
                     <label for="btn-2" class="show"> Services électroniques   +</label>

                     <a href="../pages/visiteur.php"> Services électroniques </a>
                    <input type="checkbox"  id="btn-2">
                    <ul>
                        <li><a href="../pages/Vne.php">Acte de naissance</a></li>
                        <li><a href="../pages/Vde.php">Acte de décé</a></li>
                        <li><a href="../pages/Vma.php">Aacte de mariage</a></li>
                        <li><a href="../pages/Vdeclar.php">Pré-déclaration</a></li>
                        <li>
                        <label for="btn-3" class="show">More  +</label>
                    <a href="#">More 
                        <span class="fa fa-plus"></span>
                    </a><input type="checkbox"  id="btn-3">
                    <ul>
                        <li ><a href="Mar.php">Marocains étrange</a></li>
                        <li><a href="Etrang.php" >Etrangers Maroc</a></li>
                       
                    </ul>
                </li>
                    
                    </ul>
                </li>
                <li><a href="../contact/index.php">Contact</a></li>
                <li>
                    <label for="btn-4" class="show">Connexion +</label>

                    <a href="#">Connexion</a>
                    <input type="checkbox"  id="btn-4">
                    <ul>
                        <li><a href="../pages/login.php" > Administration</a></li>
                        <li><a href="../pages/visiteur.php">Visiteur</a></li>
                    </ul>
                </li>
           
                       
            </ul>
        </nav>
<br><br>

    <!-- ------------x  page princ x------------------- -->

    <!----------------------------- background image1  ------------------------------>

    <main>

        <!--------------  Title ---------->
      
        <section class="site-title">
            <div    > 
            

            <div class="a" align ="center" style="color:#17202A;"><strong>Site web du ministére pour retirer les extraits et vérifier leur validité  <br>
            موقع تابع للوزارة   من أجل سحب العقود و التحقق من صحتها</strong>
            </div>
            </div> 
        </section>


         
        <!------------x----------- Site Title ----------x----------->

        <!-- --------------------- Blog Carousel ----------------- -->
<br><br>
        <section>
            <div class="blog">
                <div class="container"><br><br><br><br><br><br>
                    <div class="owl-carousel owl-theme blog-post">
                        <div class="blog-content" data-aos="fade-right" data-aos-delay="200">
                            <img src="./assets/mar.jpg" alt="post-1">
                            <div class="blog-title">
                                <h3>Extrait de mariage</h3>
                                <button class="btn btn-blog"><a href="../pages/Vma.php">Appuyez ici</a></button>
                             
                            </div>
                        </div>
                        <div class="blog-content" data-aos="fade-in" data-aos-delay="200">
                            <img src="./assets/ne.png" alt="post-1">
                            <div class="blog-title">
                                <h3>Extrait de naissance</h3>
                                <button class="btn btn-blog"><a href="../pages/Vne.php">Appuyez ici</a></button>
                               
                            </div>
                        </div>
                        <div class="blog-content" data-aos="fade-left" data-aos-delay="200">
                            <img src="./assets/declare.jpg" alt="post-1">
                            <div class="blog-title">
                                <h3> Ajouter ou consulter votre déclaration</h3>
                                <button class="btn btn-blog" ><a href="../pages/Vdeclar.php">Appuyez ici</a ></button>
                              
                            </div>
                        </div>
                        <div class="blog-content" data-aos="fade-right" data-aos-delay="200">
                            <img src="./assets/mort.jpg" alt="post-1">
                            <div class="blog-title">
                                <h3>Extrait de décé</h3>
                                <button class="btn btn-blog" ><a href="../pages/Vde.php">Appuyez ici</a ></button>
                               
                            </div>
                        </div>
                    </div> 
                    <div class="owl-navigation">
                        <span class="owl-nav-prev"><i class="fas fa-long-arrow-alt-left"></i></span>
                        <span class="owl-nav-next"><i class="fas fa-long-arrow-alt-right"></i></span>
                    </div>
                </div>
            </div>
        </section>
<br> <br><br><br><br><br>
        <!-- ----------x---------- Blog Carousel --------x-------- -->

        <!-- ---------------------- Site Content -------------------------->

        <section class="container">
            <div class="site-content">
                <div class="posts">
                    <div class="post-content" data-aos="zoom-in" data-aos-delay="200">
                        <div class="post-image">
                            <div>
                                <img src="./assets/post4.jpg" class="img" alt="blog1">
                            </div>
                            <div class="post-info flex-row">
                              
                                <span><i class="fas fa-calendar-alt text-gray"></i>&nbsp;&nbsp;Janvier 11, 2021</span>
                                <span>1 jour</span>

                            </div>
                        </div>
                       
                    </div>
                    <hr>
                    <div class="post-content" data-aos="zoom-in" data-aos-delay="200">
                        <div class="post-image">
                            <div>
                                <img src="./assets/post2.jpg" class="img" alt="blog1">
                            </div>
                            <div class="post-info flex-row">
                                <span><i class="fas fa-calendar-alt text-gray"></i>&nbsp;&nbsp;Mai 01, 2021</span>
                                <span>1 jour</span>
                            </div>
                        </div>
                     
                    </div>
                    <hr>
                    <div class="post-content" data-aos="zoom-in" data-aos-delay="200">
                        <div class="post-image">
                            <div>
                                <img src="./assets/post11.jpg" class="img" alt="blog1">
                            </div>
                            <div class="post-info flex-row">
                                <span><i class="fas fa-calendar-alt text-gray"></i>&nbsp;&nbsp;فاتح شوال , 1442</span>
                                <span>4 jours</span>
                            </div>
                        </div>
                      
                    </div>
                    <hr>
                    <div class="post-content" data-aos="zoom-in" data-aos-delay="200">
                        <div class="post-image">
                            <div>
                                <img src="./assets/post3.png" class="img" alt="blog1">
                            </div>
                            <div class="post-info flex-row">
                                <span><i class="fas fa-calendar-alt text-gray"></i>&nbsp;&nbsp;عاشر ذي الحجة , 1442</span>
                                <span>2 jours</span>
                            </div>
                        </div>
                     
                    </div>
                    <hr>
                    <div class="post-content" data-aos="zoom-in" data-aos-delay="200">
                        <div class="post-image">
                            <div>
                                <img src="./assets/post5.jpg" class="img" alt="blog1">
                            </div>
                            <div class="post-info flex-row">
                                <span><i class="fas fa-calendar-alt text-gray"></i>&nbsp;&nbsp;Juillet 20 , 2021</span>
                                <span>1 jour</span>
                            </div>
                        </div>
                      
                    </div>

                    <hr>
                    <div class="post-content" data-aos="zoom-in" data-aos-delay="200">
                        <div class="post-image">
                            <div>
                                <img src="./assets/post6.jpg" class="img" alt="blog1">
                            </div>
                            <div class="post-info flex-row">
                                <span><i class="fas fa-calendar-alt text-gray"></i>&nbsp;&nbsp;Nouvembre 18 , 2021</span>
                                <span>1 jour</span>
                            </div>
                        </div>
                      
                    </div>


                    <div class="pagination flex-row" align="center">
                        <a href="#"><i class="fas fa-chevron-left"></i></a>
                        <a href="#" class="pages">1</a>
                        <a href="#" class="pages">2</a>
                        <a href="#"><i class="fas fa-chevron-right"></i></a>
                    </div>
                </div>
                <aside class="sidebar">
                    
                    <div class="popular-post">
                        <h2></h2><br>
                        <div class="post-content" data-aos="flip-up" data-aos-delay="200">
                            <div class="post-image">
                                <div>
                                    <img src="./assets/post7.jpg" class="img" alt="blog1">
                                </div>
                                <div class="post-info flex-row">
                                    <span><i class="fas fa-calendar-alt text-gray"></i>&nbsp;&nbsp;Aout 10,
                                        2021</span>
                                    <span>1 jour</span>
                                </div>
                            </div>
                          
                        </div>
                        <div class="post-content" data-aos="flip-up" data-aos-delay="300">
                            <div class="post-image">
                                <div>
                                    <img src="./assets/post8.jpg" class="img" alt="blog1">
                                </div>
                                <div class="post-info flex-row">
                                    <span><i class="fas fa-calendar-alt text-gray"></i>&nbsp;&nbsp;Aout 14,
                                        2021</span>
                                    <span>1 jour</span>
                                </div>
                            </div>
                         
                        </div>
                        <div class="post-content" data-aos="flip-up" data-aos-delay="400">
                            <div class="post-image">
                                <div>
                                    <img src="./assets/post9.jpg" class="img" alt="blog1">
                                </div>
                                <div class="post-info flex-row">
                                    <span><i class="fas fa-calendar-alt text-gray"></i>&nbsp;&nbsp;Aout 20,
                                        2021</span>
                                    <span>1 jour</span>
                                </div>
                            </div>
                           
                    
                </aside>
            </div>
        </section>

        <!-- -----------x---------- Site Content -------------x------------>
    
    <!---------------x------------- Main Site Section ---------------x-------------->


    <!-- --------------------------- Footer ---------------------------------------- -->

    <footer class="footer" >
        <div class="container"align="center">
            <div class="about-us" data-aos="fade-right" data-aos-delay="200">
                <h2>Contactez-nous pour plus d'informations</h2>
                <p>Site pour obtenir votre extrais ou déclaration facilement</p>
            </div>
            
           
            <div class="follow" data-aos="fade-left" data-aos-delay="200" align="center">
                <h2>Suivez-nous</h2>
                <div>
                    <i class="fab fa-facebook-f"></i>
                    <i class="fab fa-twitter"></i>
                </div>
            </div>
            <div class="about-us" data-aos="fade-right" data-aos-delay="200">
                <h2>يمكنكم استخراج كل مايخصكم</h2>
                <p> عقود شواهد معلومات... </p>
            </div>
            
        </div>
        <div class="rights flex-row">
            <h4 class="text-gray">
                Copyright ©2021 Email::etatciviljd2021@gmail.com
             
            </h4>
        </div>
        <div class="move-up">
            <span><i class="fas fa-arrow-circle-up fa-2x"></i></span>
        </div>
    </footer>

    <!-- -------------x------------- Footer --------------------x------------------- -->

    <!-- Jquery Library file -->
    <script src="./js/Jquery3.4.1.min.js"></script>

    <!-- --------- Owl-Carousel js ------------------->
    <script src="./js/owl.carousel.min.js"></script>

    <!-- ------------ AOS js Library  ------------------------- -->
    <script src="./js/aos.js"></script>

    <!-- Custom Javascript file -->
    <script src="./js/main.js"></script>
</body>

</html>