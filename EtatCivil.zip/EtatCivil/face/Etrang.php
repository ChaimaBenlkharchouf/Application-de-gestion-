<!DOCTYPE html>
<html>

<head>
<?php include("../pages/menu2.php");?><br><br><br>
<meta charset="utf-8">
    <title>Etrangers au Maroc</title>


    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
<!-- Font Awesome Icons -->
    <link rel="stylesheet" href="../css/all.css">


    <!-- --------- Owl-Carousel ------------------->
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../css/owl.theme.default.min.css">

    <!-- ------------ AOS Library ------------------------- -->
    <link rel="stylesheet" href="../css/aos.css">

    <!-- Custom Style   -->
    <link rel="stylesheet" href="../css/Style.css">

</head>
<body   style="background-image: url('../images/zh1.jpg')";  >

 
<div class="container">
  
  <div class="row">
     
    <div class="col-sm-3" style="background-color:yellow;"> <br><br><br><br><br><br>
      <p  align="center"><a href="#A"> Déclaration de naissance (Cas normal pour les MRE)</a></p>
      <p  align="center"><a href="#B"> L’enregistrement à l’état civil </a></p>
      <p  align="center"><a href="#C">  Déclaration de décès</a></p>
      <p  align="center"><a href="#D"> </a></p><br><br><br><br>


    </div>
    <div >
    <p  align="right">


<div style="width:50%;" class="container">
  
           
           <div  align="center" class="panel panel-danger margetop">
        <div class="panel-heading">Préambule</div><br>
        <div class="panel-heading" id='A'> Déclaration de naissance (Cas normal pour les MRE)</div>

        <div  class="panel-body">
    <pre>   
<h4 style="color:blue;"> ​ Article 3 de la loi sur l’état civil : </h4>

Tous les marocains sont obligatoirement soumis au régime d’état civil.
Le même régime s’applique aux étrangers en ce qui concerne 
les naissances et les décès survenant sur le territoire national.

<h4 style="color:blue;">Pour la naissance : </h4>
l’article 17 du décret pris en application de la loi d’état civil :

Les étrangers résidant ou se trouvant sur le territoire national
peuvent déclarer les naissances survenues au Royaume.
La déclaration de naissance des étrangers est appuyée d’un certificat
délivré par un médecin accoucheur, une sage-femme exerçant légalement
ou par l’autorité locale attestant le lieu de sa survenance au Royaume.
Toutes pièces justifiant l’identité des parents.
<h4 style="color:blue;">Pour le décès : </h4>
l’article 32 du décret pris en application de la loi d’état civil​ :

Les étrangers résidant ou se trouvant sur le territoire national
peuvent déclarer les décès survenus au Royaume.
La déclaration de décès des étrangers est appuyée d’un certificat
de constatation délivré par le médecin, ou l’infirmier relevant
de la santé publique ou, à défaut, par un certificat de constatation 
délivré par le représentant de l’autorité compétente attestant le lieu
de sa survenance au Royaume.
Toutes pièces justifiant l’identité du défunt.
</pre>

<div  align="center" class="panel panel-danger ">
        <div class="panel-heading" id="B"> L’enregistrement à l’état civil</div><br>
        <div class="panel-heading" margetop>  Déclaration de naissance de l'étranger né au Maroc</div></div>
<pre>
<h4 style="color:blue;">Déclarants</h4>
Le père ou la mère
Le tuteur testamentaire
Le frère(le frère germain a priorité sur le consanguin et celui-ci
sur le frère utérin, de même le plus âgé sur plus jeune que lui)
Le neveu
Le mandataire
<h4 style="color:blue;">Délai réglementaire</h4>
30 jours à partir de la date de la naissance

<h4 style="color:blue;">Pièces appuyant la déclaration</h4>
Avis de naissance ou attestation de naissance délivrée par 
l'autorité locale.copie intégrale des parents ou tout documents
justifiant leur l’identité
Procuration pour le cas du mandataire
<h4 style="color:blue;">Service Compétent</h4>
-Bureau d’état civil du lieu de naissance du nouveau-né.

<h4 style="color:blue;">Remarque:</h4>
En cas de dépassement du délai réglementaire, la déclaration de
naissance se fait par jugement déclaratif.
Si le 30eme jour coïncide avec un ou plusieurs jours fériés, 
la déclaration peut être faite le premier jour ouvrable suivant.
Le formulaire de pré-déclaration disponible sur l’espace service
électronique doit être renseigné minutieusement

</pre>

<div  align="center" class="panel panel-danger ">
        <div class="panel-heading" id="C"> Déclaration de décès </div></div>
<pre>

<h4 style="color:blue;">Déclarants</h4>
le fils
Le conjoint
le père , la mère , le tuteur testamentaire ou le tuteur datif du
décédé de son vivant
Le préposé à la kafala pour la personne objet de la kafala
Frère
Le grand père et les proches parents qui suivent dans l’ordre
L’autorité locale à défaut des personnes précitées
<h4 style="color:blue;">Délai réglementaire</h4>
30 jours à partir de la date du décès

<h4 style="color:blue;">Pièces appuyant la déclaration</h4>
Certificat de constatation du décès délivrée par le médecin ou
l’infirmier relevant de la santé publique ou à défaut, un certificat
de constatation délivrée par le représentant de l'autorité compétente.
copie de l’extrait de naissance du défunt ou son livret de famille, ou
le livret de famille du son père, ou copie de sa carte de résident, ou
tout document justifiant son identité ainsi que celle de ses parents
copie de la carte de l’identité du déclarant
Procuration pour le cas du mandataire
<h4 style="color:blue;">Service compétent</h4>
Bureau d’état civil du lieu de survenance du décès

<h4 style="color:blue;">remarque:</h4>
En cas de dépassement du délai réglementaire, la déclaration du décès 
se fait via un jugement déclaratif.
Si le 30eme jour coïncide avec un ou plusieurs jours fériés ou weekend,
la déclaration peut être faite le premier jour ouvrable suivant
Le formulaire de pré-déclaration disponible sur l’espace service
 électronique doit être renseigné minutieusement

</pre>

</div>
</div></p>
    </div>
  </div>
</div>

<br>

</body>
</html>