<!DOCTYPE html>
<html>

<head>
<?php include("../pages/menu2.php");?><br><br><br>
<meta charset="utf-8">
    <title>Les registres de l’état civil</title>


    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
<!-- Font Awesome Icons -->
    <link rel="stylesheet" href="../css/all.css">


    <!-- --------- Owl-Carousel ------------------->
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../css/owl.theme.default.min.css">

    <!-- ------------ AOS Library ------------------------- -->
    <link rel="stylesheet" href="../css/aos.css">

    <!-- Custom Style   -->
    <link rel="stylesheet" href="../css/Style.css">

</head>
<body   style="background-image: url('../images/zh1.jpg')";  >

 
<div class="container">
  
  <div class="row">
     
    <div class="col-sm-3" style="background-color:yellow;"> <br><br><br><br>
      <p  align="center"><a href="bureau.php">Les bureaux de l’état civil</a></p>
      <p  align="center"><a href="registreF.php">Les registres de l’état civil</a></p>
      <p  align="center"><a href="statistique.php">Les statistiques de l’état civil</a></p><br><br><br><br>

    </div>
    <div >
    <p  align="right">


<div style="width:50%;" class="container">
  
           
           <div  align="center" class="panel panel-danger margetop">
        <div class="panel-heading">​Les registres de l’état civil</div><br>
        <div class="panel-heading"> 1/ Tenue des registres de l’état civil :</div>

        <div  class="panel-body">

​Les registres de l’état civil
Le Ministère de l’Intérieur met régulièrement à la disposition de tous les bureaux de l’état civil à l’intérieur du Royaume des registres avant la fin de chaque année grégorienne en fonction du volume de leurs activités. La dotation des postes diplomatiques et consulaires marocains à l’étranger en registres est assurée par le ministère des affaires étrangères et de la coopération. Il existe deux catégories de registres 

* les registres de naissances.

* les registres de décès.

Ces registres sont tenus en double exemplaires à l’intérieur du Maroc et en trois exemplaires dans les postes diplomatiques et consulaires marocains à l’étranger.

Les registres de l’état civil sont soumis avant leur utilisation à l’autorisation du procureur du Roi près de tribunal de 1ère instance compétent qui certifie au début de chaque registre le nombre de ses pages, la nature de ses actes, le bureau de l’état civil qui le tient et l’année pour laquelle il est réservé. Numérote les pages de chaque registre, Appose le Sceau du tribunal sur chaque feuille et revêt de​ sa signature la première et la dernière page du registre. L’ouverture des registres a lieu au début de chaque année grégorienne, ils sont clos le 31 décembre de la même année.

<div  align="center" class="panel panel-danger margetop">
        <div class="panel-heading">2/ Clôture des registres : </div></div>


L’officier de l’état civil est tenu avant d’arrêter et de clore les registres, de vérifier si toutes les déclarations reçues ont été consignées et signées. La clôture des registres doit être effectuée à la fin de chaque année immédiatement après le dernier acte, et non pas à la dernière page du registre. Il convient de préciser que lorsqu’un registre est composé de plusieurs tomes, chaque tome doit être clos au fur et à mesure de son achèvement (clôture partielle). Néanmoins une clôture finale doit avoir lieu sur le dernier tome (clôture totale).

L’officier de l’état civil dresse ensuite pour chaque exemplaire un tableau récapitulatif classé selon l’ordre alphabétique des noms et en certifie la conformité.

Lesdits tableaux sont ensuite classés selon la nature des actes (naissances, décès) et dans l’ordre alphabétique des noms, dans des registres distincts tenus une fois tous les dix ans en deux exemplaires dont l’un est adressé au tribunal compétent.

Les pages des tableaux contiennent 24 lignes.

<div  align="center" class="panel panel-danger margetop">
        <div class="panel-heading"> 3/ Contrôle des registres de l’état civil :</div></div>


En vertu de la loi , l’officier de l’état civil adresse dans le mois qui suit la fin de l’année grégorienne un exemplaire de chaque registre tenu par lui, après l’avoir contrôlé et arrêté, au gouverneur de la préfecture ou de la province afin que l’inspecteur provincial de l’état civil procède à leur contrôle et à l’élaboration d’un rapport circonstancié sur l’état des actes qu’il soumet , accompagné des exemplaires des registres, au procureur du Roi près le tribunal de première instance compétent à raison du lieu.

Le procureur du Roi près le tribunal de 1ère instance procède au contrôle des registres , à leur dépôt au tribunal et en dresse procès-verbal dont une copie est transmise au procureur général du Roi près la cour d’appel, celui-ci prend les mesures nécessaires afin d’engager des poursuites à l’encontre des officiers ou agents d’état civil contre lesquels il a été établi, suite au contrôle, qu’ils ont commis des actes sanctionnés par la loi.

Le procureur du Roi conserve les exemplaires exempts d’erreurs et renvoi à l’officier de l’état civil sous couvert du gouverneur de la préfecture ou de la province, ceux qui comportent des erreurs ou des irrégularités avec une copie du procès-verbal.

L’officier de l’état civil procède alors à la rectification des erreurs indiquées dans le procès-verbal, conserve un exemplaire de chaque catégorie de registre dans le bureau et adresse les autres au procureur du Roi qui , après contrôle, les dépose aux archives du tribunal de 1ère instance compétent

<div  align="center" class="panel panel-danger margetop">
        <div class="panel-heading"> 4/ La reconstitution des registres de l’état civil :</div></div>


Les registres d’état civil perdus ou détériorés doivent être reconstitués en vue de préserver les intérêts des citoyens qui y sont inscrits.

La reconstitution des registres a lieu sur la base d’une décision judiciaire rendue par le tribunal compétent. De même, lorsqu’un acte détérioré ne peut être reconstitué, l’intéressé est tenu de présenter une demande au tribunal compétent pour faire prononcer un jugement ordonnant de consigner à nouveau le fait objet de l’acte.

Les jugements rendus pour la reconstitution des registres sont prononcés sur la base des exemplaires des registres conservés au tribunal. 

A défaut ils seront reconstitués à partir :

- des dossiers de familles conservés au bureau d’état civil 

- des livrets de famille 

- des anciennes copies et extraits d’actes tirés des registres perdus.

En cas de perte ou détérioration des registres de l’état civil tenus par les postes diplomatiques et consulaires marocains à l’étranger, l’officier de l’état civil compétent rédige un procès-verbal qu’il adresse, sous couvert du Ministre des Affaires Etrangères et de la coopération, au procureur du Roi près le tribunal de 1ère instance de Rabat à l’effet de prononcer un jugement de reconstitution des registres conformément à la procédure définie ci-dessus.

Les registres tenus par les postes diplomatiques et consulaires marocains à l’étranger, sont soumis avant leur utilisation à l’autorisation du procureur du Roi près le tribunal de 1ère instance de Rabat. Il assure également le contrôle des exemplaires des registres qu’il reçoit l’année qui suit.



</div>
</div></p>
    </div>
  </div>
</div>

<br>

</body>
</html>