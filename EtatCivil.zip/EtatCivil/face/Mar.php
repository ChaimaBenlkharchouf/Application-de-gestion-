<!DOCTYPE html>
<html>

<head>
<?php include("../pages/menu2.php");?><br><br><br>
<meta charset="utf-8">
    <title> Marocains à l'étranger </title>


    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
<!-- Font Awesome Icons -->
    <link rel="stylesheet" href="../css/all.css">


    <!-- --------- Owl-Carousel ------------------->
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../css/owl.theme.default.min.css">

    <!-- ------------ AOS Library ------------------------- -->
    <link rel="stylesheet" href="../css/aos.css">

    <!-- Custom Style   -->
    <link rel="stylesheet" href="../css/Style.css">

</head>
<body   style="background-image: url('../images/zh1.jpg')";  >

 
<div class="container">
  
  <div class="row">
     
    <div class="col-sm-3" style="background-color:yellow;"> <br><br><br><br><br><br>
      <p  align="center"><a href="#A">Déclaration de naissance (Cas normal pour les MRE)</a></p>
      <p  align="center"><a href="#B">Transcription directe de l’acte de naissance Des Marocains nés à l’étranger </a></p>
      <p  align="center"><a href="#C">Déclaration de décès les pour RME (Cas normal)</a></p>
      <p  align="center"><a href="#D">Consignation des mentions du mariage et la dissolution du mariage</a></p><br><br><br><br>


    </div>
    <div >
    <p  align="right">


<div style="width:50%;" class="container">
  
           
           <div  align="center" class="panel panel-danger margetop">
        <div class="panel-heading">L’enregistrement à l’état civil</div><br>
        <div class="panel-heading" id='A'> Déclaration de naissance (Cas normal pour les MRE)</div>

        <div  class="panel-body">
    <pre>   
<h4 style="color:blue;"> Déclarant</h4>
le père ou la mère
le Tuteur testamentaire
ses descendants
le Frère(le frère germain a priorité sur le consanguin et celui-ci sur
 le frère utérin, de même le plus âgé sur plus jeune que lui)
le Neveu
le Mandataire
toute personne mandatée par le titulaire
<h4 style="color:blue;">Documents requis</h4>
Copie conforme de l'acte de mariage (pour les marocains musulmans) ou
copie de la CNIE des parents ou le livret de famille ou copie 
intégrale de naissance des parents.
Avis de naissance délivrée par le médecin accoucheur ou attestation 
délivrée par l’autorité compétente.
Procuration pour le cas du mandataire
CNIE du déclarant.
<h4 style="color:blue;">Délai réglementaire</h4>
Une année

<h4 style="color:blue;">Service compétent</h4>
Bureau d’état civil du consulat marocain à l’étranger relevant du lieu 
de naissance du nouveau-né.

<h4 style="color:blue;">Remarque</h4>
En cas de dépassement du délai réglementaire, la déclaration de 
naissance se fait via un jugement déclaratif auprès du tribunal de
1ère instance de Rabat.Le formulaire de pré-déclaration disponible
sur l’espace service électronique doit être renseigné minutieusement.
</pre>

<div  align="center" class="panel panel-danger margetop">
        <div class="panel-heading" id="B"> Transcription directe de l’acte de naissance Des Marocains nés à l’étranger et soumis au régime de l’état civil du pays d’accueil
</div></div>
<pre>
<h4 style="color:blue;">Déclarant</h4>
le Tuteur testamentaire
le Frère(le frère germain a priorité sur le consanguin et celui-ci sur 
le frère utérin, de même le plus âgé sur plus jeune que lui)
le Neveu
le Mandataire
<h4 style="color:blue;">Documents requis</h4>
Copie conforme de l'acte de mariage (pour les marocains musulmans)
copie de la CNIE des parents ou le livret de famille ou copie intégrale
de naissance des parents.copie intégrale de naissance délivrée par 
l’officier d’état civil du pays d’accueil.
Procuration pour le cas du mandataire
CNIE du déclarant.
<h4 style="color:blue;">Délai réglementaire</h4>
ouvert

<h4 style="color:blue;">Service compétent</h4>
Bureau d’état civil du consulat relevant du lieu de naissance 
de la personne déclarée.

<h4 style="color:blue;">Remarque:</h4>
Le formulaire de pré-déclaration disponible sur l’espace service
 électronique doit être renseigné minutieusement.

</pre>

<div  align="center" class="panel panel-danger margetop">
        <div class="panel-heading" id="C"> 
Déclaration de décès les pour RME (Cas normal)</div></div>
<pre>
<h4 style="color:blue;">Déclarants</h4>
le fils
Le conjoint
le père, la mère, le tuteur testamentaire ou le tuteur datif du
décédé de son vivant,Le préposé à la kafala pour la personne 
objet de la kafala,Frère,Le grand père et les proches parents 
qui suivent dans l’ordre,L’autorité locale à défaut 
des personnes précitées,
<h4 style="color:blue;">Délai réglementaire</h4>
Une année à partir de la date du décès,

<h4 style="color:blue;">Documents requis</h4>
Certificat de constatation du décès délivrée par le médecin 
ou l’infirmier relevant de la santé publique ou à défaut,
un certificat de constatation délivrée par le représentant
de l'autorité compétente.
copie de l’extrait de naissance du défunt ou son livret de 
famille ou son carnet d’identité et de l’état civil,
ou le livret de famille du son père, ou copie de sa CNIE,
copie de la CNIE du déclarant, Procuration pour le cas 
du mandataire
<h4 style="color:blue;">Service compétent</h4>
Bureau d’état civil du consulat relevant du lieu
 de survenance du décès.

<h4 style="color:blue;">Remarque:</h4>
Si le dernier jour coïncide avec un ou plusieurs 
jours fériés , la déclaration peut être faite 
le premier jour ouvrable suivant.En cas de
dépassement du délai réglementaire,
la déclaration du décès se fait via un
jugement déclaratif. Le formulaire de
pré-déclaration disponible sur l’espace service 
électronique doit être renseigné minutieusement

</pre>

<div  align="center" class="panel panel-danger margetop">
        <div class="panel-heading" id="D"> Consignation des mentions du mariage et la dissolution du mariage</div></div>

<pre>
<h4 style="color:blue;">déclarants</h4>
Epoux -épouse

Le divorcé- La divorcée ou toute personne en tenant lieu

<h4 style="color:blue;">Documents requis</h4>
Copie de l'acte de mariage ou copie de l'acte de divorce 
ou copie du jugement
<h4 style="color:blue;">Procuration pour le cas du mandaté</h4>
Copie de la CNIE de l'intéressé ou de toute personne en tenant lieu.
<h4 style="color:blue;">Délai règlementaire</h4>
ouvert

<h4 style="color:blue;">Service concerné</h4>
Demande déposée au:

<h4 style="color:blue;">Consulat du lieu de conclusion de l'acte</h4>
Transmise:

à l'officier d'état civil du lieu de naissance des époux pour 
consignation des mentions marginales les concernant dans leur 
acte de naissance.
Au juge de la famille de leur lieu de naissance.
Au juge de la famille de Rabat
Au procureur du roi de TPI de Rabat.
<h4 style="color:blue;">Remarque</h4>
Le citoyen peut exceptionnellement déposer la demande de 
Consignation des mentions du mariage et la dissolution du
 mariage à son bureau d’état civil de naissance. 
 le formulaire de pré-déclaration prévu dans ce cas 
 sur l’espace service électronique doit être renseigné minutieusement.
</pre>

</div>
</div></p>
    </div>
  </div>
</div>

<br>

</body>
</html>