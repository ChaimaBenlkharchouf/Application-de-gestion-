<!DOCTYPE html>
<html>

<head>
<?php include("../pages/menu2.php");?><br><br><br>
<meta charset="utf-8">
    <title>Les statistiques de l’état civil</title>


    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
<!-- Font Awesome Icons -->
    <link rel="stylesheet" href="../css/all.css">


    <!-- --------- Owl-Carousel ------------------->
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../css/owl.theme.default.min.css">

    <!-- ------------ AOS Library ------------------------- -->
    <link rel="stylesheet" href="../css/aos.css">

    <!-- Custom Style   -->
    <link rel="stylesheet" href="../css/Style.css">

</head>
<body   style="background-image: url('../images/zh1.jpg')";  >

 
<div class="container">
  
  <div class="row">
     
    <div class="col-sm-3" style="background-color:yellow;"> <br><br><br><br>
      <p  align="center"><a href="bureau.php">Les bureaux de l’état civil</a></p>
      <p  align="center"><a href="registreF.php">Les registres de l’état civil</a></p>
      <p  align="center"><a href="statistique.php">Les statistiques de l’état civil</a></p><br><br><br><br>

    </div>
    <div >
    <p  align="right">


<div style="width:50%;" class="container">
  
           
           <div  align="center" class="panel panel-danger margetop">
        <div class="panel-heading">Les statistiques de l’état civil</div><br>
        <div class="panel-heading"> 1- Définition des statistiques de l’état civil :</div>

        <div  class="panel-body">

D’après la définition donnée par l’organisation des nations unis, les statistiques de l’état civil consistent en l’enregistrement légal des faits d’état civil, la préparation des bulletins statistiques y afférents, l’élaboration, l’analyse, la présentation et la publication des statistiques de ces faits tels la naissance, le décès le mariage, le divorce………………………..etc.
<div  align="center" class="panel panel-danger margetop">
        <div class="panel-heading">2- Importance :
 </div></div>
Il est aisé de saisir la valeur réelle des statistiques de l’état civil à travers leur généralité, leur continuité, leur faible coût de réalisation, et leur large domaine d’utilisation.

Les statistiques de l’état civil touchent en effet toutes Les entités territoriales ciblées, elles sont régulières et leur coût de réalisation est dérisoire par rapport aux autres sources démographiques, sans oublier leur grande utilité dans les domaines de la santé, de l’enseignement de l’emploi, et autres domaines qui en font un instrument indispensable à la planification économique et sociale.
<div  align="center" class="panel panel-danger margetop">
        <div class="panel-heading"> 3- les feuilles de déclaration et les feuilles d’enregistrement :
</div></div>
Pour recenser les faits d’état civil tels la naissance le décès, et les mentions relatives au mariage et à la dissolution du mariage, l’officier de l’état civil doit remplir des bulletins statistiques.

Les mentions sont remplies dans des feuilles spéciales appelées ‘’feuilles de déclaration’’. Elles sont de trois sortes:

Les feuilles de déclaration de naissance
Les feuilles de déclaration de décès 
Les feuilles des jugements déclaratifs de naissance ou de décès
Les feuilles sont groupées par catégories dans des carnets appelés ‘’carnets de déclaration’’

En plus des feuilles de déclaration, il y a les feuilles d’enregistrement qui sont de deux catégories :

Les feuilles de consignation des mentions relatives au mariage. 
Les feuilles de consignation des mentions de dissolution du mariage (article 39 du décret d’application).
Les feuilles de déclaration sont remplies à la suite d’une déclaration de naissance ou de décès, et les feuilles d’enregistrement sont remplies après la réception de l’expédition de l’acte de mariage ou de dissolution du mariage.

Les carnets de déclaration (naissances, décès, jugements) et les carnets d’enregistrement sont composés de plusieurs feuilles chacune en deux exemplaires.

Les feuilles de déclaration et les feuilles d’enregistrement indiquent tous les renseignements concernant la personne déclarée et les changements qui interviennent dans sa situation familiale, constituant ainsi le document de base sur lequel est dressé l’acte de l’état civil, et une source d’information destinée à la direction de la statistique relevant du haut-commissariat au plan.

Les feuilles de déclaration doivent être remplies par les soins des agents de l’état civil avant l’inscription des naissances et des décès déclarés sur les registres de l’état civil, il en est de même des feuilles d’enregistrement qui doivent être remplies avant la consignation des mentions y afférentes.
<div  align="center" class="panel panel-danger margetop">
        <div class="panel-heading">4- Contenu des feuilles de déclaration et des feuilles d’enregistrement :
 </div></div>
a/ Contenu des feuilles de déclaration:

* la feuille de déclaration de naissance comprend:

. La localisation géographique du bureau

. Les renseignements sur la naissance (date, lieu….)

. Les renseignements sur le nouveau-né

. Les renseignements sur le père du nouveau-né

. Les renseignements sur la mère du nouveau-né

. Les renseignements sur le déclarant de la naissance

. Coupon réservé à la déclaration de naissance


* La feuille de déclaration de décès comprend:

. La localisation géographique du bureau

 

. La localisation géographique du décès

. Renseignements sur le père du décédé

. Renseignements sur la mère du décédé

. Renseignements sur le déclarant du décès

. Coupon réservé à la déclaration de décès


* la feuille du jugement déclaratif comprend:

. La localisation géographique du bureau

. Renseignements sur le jugement déclaratif (jugement déclaratif de naissance ou de décès)

. Renseignements sur le père du nouveau-né ou du défunt

. Renseignements sur la mère du nouveau-né ou du défunt

(Les jugements rectificatifs ne doivent pas être reproduits sur les feuilles de déclaration)

* feuille de déclaration d’un mort-né

Cet événement doit être inscrit dans la feuille de déclaration de décès, avec toutefois le remplacement de l’intitulé de la feuille par « feuille de déclaration d’un mort-né » Seules les informations relatives au mort-né sont consignées, les autres mentions doivent être remplies par un trait.
b/ contenu des feuilles d’enregistrement :

1- La feuille de consignation de la mention de mariage comprend:

. les mentions essentielles de l’acte de mariage et ses références de consignation au registre des mariages

. la localisation géographique du bureau

. mentions sommaires de l’acte de mariage

. les références de la mention de mariage

. la nature et la date de l’acte du mariage

. informations sur l’époux

. informations sur l’épouse

2- La feuille de consignation de la mention de dissolution de mariage comprend:

. les mentions essentielles de l’acte de dissolution de mariage, de divorce, divorce moyennant compensation, reprise en mariage, mourajaa) et ses références

. Mentions sommaires de l’acte de divorce

. Nature et date de l’acte de divorce

. Informations sur le divorcé

. Informations sur la divorcée

<div  align="center" class="panel panel-danger margetop">
        <div class="panel-heading">5- Remplissage des feuilles de déclaration :
 </div></div>
La feuille de déclaration est divisée en deux parties:

. La partie droite est réservée aux énonciations propres à l’état civil sur la base desquelles est dressé l’acte.

. La partie gauche comprend des cases de codification réservées à la direction de la statistique relevant du haut-commissariat au plan

- l’adresse des parents requise dans la feuille de déclaration de naissance, ou dans la feuille de déclaration de décès est la résidence habituelle.

- Si les parents du nouveau-né sont divorcés la résidence en question sera celle de celui qui en a la garde.

- l’adresse doit indiquer au moins le nom de la commune ou de la province

- L’officier de l’état civil doit demander aux déclarants des informations précises sur le niveau d’instruction des parents.

Il doit se contenter de mentionner sur la feuille l’un des niveaux suivants : primaire, secondaire, ou universitaire.

Au cas où l’un des parents du nouveau-né est analphabète la mention « sans instruction » doit être mentionnée sur la feuille de déclaration

Quant au rang de la naissance déclarée, la réponse doit préciser s’il s’agit de la 1ère naissance de la 2ème de la 3ème …. L’enfant mort-né n’est pas pris en considération.

Par métier ou profession, il faut entendre la fonction principale exercée par l’intéressé .Les réponses imprécises tel Fellah – fonctionnaire – commerçant doivent être évitées car elles sont

générales et ne précisent par l’activité professionnelle ou économique réelle de l’individu

Ainsi au lieu d’écrire fonctionnaire, on écrit fonctionnaire à la banque du Maroc, ou employé de banque .Au lieu de commerçant seulement on dira commerçant de produits alimentaires, ou de chaussures .....

Les professions les plus courantes telles que : enseignant, professeur, juge, avocat, coiffeur chauffeur de taxi doivent être consignées sans autres précisions.

S’agissant des feuilles relatives aux jugements déclaratifs (naissances, décès) la nature du jugement doit être précisée en haut de la feuille, et on procède ensuite au remplissage des mentions y afférentes.

Il y a lieu de préciser que lorsque le jugement déclaratif concerne une naissance, seules les informations relatives à la naissance de l’intéressé doivent être mentionnées dans la feuille de déclaration dans la partie intitulée « Renseignements relatifs à la naissance ou au décès », Si par contre le jugement déclaratif concerne un décès, dans ce cas les informations sur le défunt doivent être remplies dans la partie intitulée « renseignements complémentaires relatifs au décès seulement » en plus des informations sur sa naissance.
<div  align="center" class="panel panel-danger margetop">
        <div class="panel-heading">6- Procédure de transmission des feuilles de déclaration et des feuilles d’enregistrement :
 </div></div>
1/ Au niveau du bureau de l’état civil:

La procédure de transmission des feuilles de déclaration de naissances et de décès est la même que celle utilisée pour la transmission des feuilles d’enregistrement des mentions de mariage et de divorce.

A cet effet les bureaux de l’état civil doivent transmettre à la fin de chaque mois et avant le 15 du mois suivant, une copie de chaque feuille de déclaration et d’enregistrement collectées, sous bordereau à la division provinciale ou préfectorale de l’état civil après avoir vérifier les données recueillies et contrôler le nombre des feuilles.

Lorsqu’il n’existe qu’un seul bureau d’état civil au sein de la commune les feuilles de déclaration et les feuilles d’enregistrement doivent être transmises séparément à la division provinciale ou préfectorale dans 2 enveloppes accompagnées d’un bordereau indiquant le nombre des naissances, des décès et des jugements détaillés selon les sexes ainsi que le nombre des mariages et divorces enregistrés durant le mois.

Si par contre la commune compte plusieurs bureaux d’état civil, il convient d’établir un état synthétique au niveau de la commune faisant ressortir le nombre des naissances, des décès, des jugements déclaratifs détaillés par sexe et le nombre des mariages et divorces enregistrés dans chaque bureau d’état civil durant le mois et transmettre séparément dans deux enveloppes, les feuilles d’enregistrement et les feuilles de déclaration de chaque bureau à part à la division préfectorale de l’état civil.


2/ Au niveau de la division provinciale ou préfectorale de l’état civil:

Après réception des feuilles de déclaration et des feuilles d’enregistrement par la division préfectorale ou provinciale doit:

vérifier et contrôler toutes les feuilles de déclaration de naissance et de décès et les feuilles d’enregistrement des mentions de mariage et de divorce et les comparer avec les états statistiques élaborés aux niveaux des bureaux d’état civil et de la commune.

* un exemplaire des feuilles de déclaration de naissance et de décès et des feuilles d’enregistrement des mentions de mariage et de divorce est envoyé à la direction régionale du haut-commissariat au plan dont relève la préfecture ou la province conformément à la circulaire n° 41/DGCL/DEC/4 du 25 mars 2003.

* l’autre exemplaire est conservé au bureau d’état civil. L’ingénieur statisticien est chargé d’établir deux états statistiques, l’un contenant les faits d’état civil déclarés durant le mois (naissances, décès, jugement déclaratifs) de tous les bureaux de l’état civil de la province ou de la préfecture détaillés par sexe, et par milieu urbain ou rural . Le deuxième état comprend le nombre de mariages et de divorces enregistrés durant le mois au niveau de tous les bureaux de l’état civil relevant de la province ou de la préfecture par milieu urbain ou rural.
<div  align="center" class="panel panel-danger margetop">
        <div class="panel-heading">7/ l’envoi électronique des statistiques d’état civil :</div></div>
Conformément à la circulaire n°143 du 29 octobre 2004, une nouvelle procédure a été instaurée pour l’envoi des statistiques de l’état civil et ce à l’effet de réduire le temps de traitement de ses données et leur exploitation rapide et rationnelle.

Cette nouvelle procédure qui a débuté en octobre 2006, consiste en l’envoi par les différentes provinces et préfectures à la DIRECTION DES SYSTEMES D’INFORMATION ET DE COMMUNICATION d’une fiche de dépouillement renseignée au niveau des bureaux d’état civil

comportant les données ci-après :

. la localisation géographique du bureau

. Répartition des naissances et des décès déclarés selon le type, la date de survenance, et le sexe

. Répartition des mariages et divorces par sexe,

. Répartition des naissances par tranches d’âges de la mère et du sexe du nouveau-né

. Répartition des décès par âge et sexe du décédé

. Répartition des naissances par rang de la naissance et par sexe

. Répartition des décès par profession

. Répartition des naissances par lieu de résidence

. Autres statistiques relatives aux nombre des enfants abandonnés et aux nombre des enfants pris en charge dans le cadre de la Kafala

Les fiches de dépouillement sont adressées après leur remplissage aux services provinciaux qui procèdent à travers les ingénieurs statisticiens au contrôle des données renseignées et la saisie des dites fiches avant leur transmission via une application intranet au centre informatique relevant de DIRECTION DES SYSTEMES D’INFORMATION ET DE COMMUNICATION dans un délai ne dépassant pas 15 jours à compter du début du mois qui suit la déclaration des évènements à l’état civil pour être exploitées par - DIRECTION DES AFFAIRES JURIDIQUES, DES ETUDES,DE LA DOCUMENTATION ET DE LA COOPERATION –Division de l’Etat Civil.


</div>
</div></p>
    </div>
  </div>
</div>

<br>

</body>
</html>