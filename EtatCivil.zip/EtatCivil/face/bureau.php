<!DOCTYPE html>
<html>

<head>
<?php include("../pages/menu2.php");?><br><br><br>
<meta charset="utf-8">
    <title>Les bureau d'état civil</title>


    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
<!-- Font Awesome Icons -->
    <link rel="stylesheet" href="../css/all.css">


    <!-- --------- Owl-Carousel ------------------->
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../css/owl.theme.default.min.css">

    <!-- ------------ AOS Library ------------------------- -->
    <link rel="stylesheet" href="../css/aos.css">

    <!-- Custom Style   -->
    <link rel="stylesheet" href="../css/Style.css">

</head>
<body   style="background-image: url('../images/zh1.jpg')";  >

 
<div class="container">
  
  <div class="row">
     
    <div class="col-sm-3" style="background-color:yellow;"> <br><br><br><br>
      <p  align="center"><a href="bureau.php">Les bureaux de l’état civil</a></p>
      <p  align="center"><a href="registreF.php">Les registres de l’état civil</a></p>
      <p  align="center"><a href="statistique.php">Les statistiques de l’état civil</a></p><br><br><br><br>

    </div>
    <div >
    <p  align="right">


<div style="width:50%;" class="container">
  
           
           <div  align="center" class="panel panel-danger margetop">
        <div class="panel-heading">Définition et importance de l'état civil</div><br>
        <div class="panel-heading"> 1. Définition de « l’état civil »</div>

        <div  class="panel-body">

​
Les Dahirs du 4 septembre 1915 et du 8 Mars 1950 n’ont pas défini «l’état civil ». La nouvelle loi sur 
l’état civil lui a, par contre, donnée une définition complète et précise à travers laquelle elle matérialise ses thèmes et fixe son champ d’application.

Par consignation des faits d'état civil, on entend :

L’inscription des déclarations des naissances et décès reçues par l’officier de l’état civil aux lieux de leurs survenances sur des actes indépendants contenues dans des registres tenus spécialement à cet effet .Ils sont ensuite assortis de la signature de l’officier d’état civil compétent qui leur confère l’authenticité. Ces actes ainsi dressés permettent l’indentification des individus qui y sont inscrits.
La consignation en marge des actes de naissances des mentions sommaires relatives au mariage et au divorce

<div  align="center" class="panel panel-danger margetop">
        <div class="panel-heading">2. Importance de l'état civil</div></div>

L’institution de l’état civil occupe une place stratégique dans l’administration marocaine pour 3 raisons :

d’abord c’est une mission régalienne exercée par les présidents des conseils communaux, officiers d’état civil, pour le compte de l’Etat et sous sa responsabilité ;
Elle a ensuite la particularité d’être l’unique institution qui accompagne le citoyen de sa naissance jusqu’à son décès ;
Enfin, modernisée, elle peut constituer, à l’aide des nouvelles technologies de l’information et de la communication, un important outil de développement fournissant en temps réel aux décideurs locaux et nationaux les données démographiques nécessaires à l’action économique et sociale. Partant de cette importance, le Ministère de l’Intérieur a toujours œuvré pour la promotion de cette institution par l’extension de son champ d’application et l’assouplissement de ses règles de façon à mettre en place un état civil conforme aux standards de la société moderne.
Ces efforts ont été couronnés en 2003 par la promulgation de la loi n° 37-99 qui a instauré un nouveau régime d’état civil qui répond aux exigences de l’actuelle société marocaine tout en respectant ses valeurs historiques, mettant ainsi fin au système dual qui , outre la distinction qu’il faisait entre marocains et étrangers pour le bénéfice de l’enregistrement à l’état civil, connaissait beaucoup de limites, dûes notamment à l’éparpillement des textes et aux contradictions de la jurisprudence en la matière.


</div>
</div></p>
    </div>
  </div>
</div>

<br>

</body>
</html>