<?php



require_once('connexiondb.php');

$idd=isset($_GET['idD'])?$_GET['idD']:0;
$requete="select * from deces where idDeces=$idd";

$resultat=$pdo->query($requete);
$deces=$resultat->fetch();

$N_acte_d=strtoupper($deces['N_acte_d']);
$nom_d=strtoupper($deces['nom_d']);
$nom_darabe=strtoupper($deces['nom_darabe']);
$prenom_d=strtoupper($deces['prenom_d']);
$prenom_darabe=strtoupper($deces['prenom_darabe']);
$carte_national_d=strtoupper($deces['carte_national_d']);
$ville_d=strtoupper($deces['ville_d']);
$ville_darabe=strtoupper($deces['ville_darabe']);
$date_naissance_d=strtoupper($deces['date_naissance_d']);
$datearabe=$deces['datearabe'];
$coresp_d=strtoupper($deces['coresp_d']);
$coresp_darabe=strtoupper($deces['coresp_darabe']);
$national=strtoupper($deces['national']);
$N_et_lieu_declaration_d=strtoupper($deces['N_et_lieu_declaration_d']);
$travail_d=strtoupper($deces['travail_d']);
$travail_dar=strtoupper($deces['travail_dar']);
$prenom_pere_d =strtoupper($deces['prenom_pere_d']);
$prenom_parabe =strtoupper($deces['prenom_parabe']);
$nationalp =strtoupper($deces['nationalp']);
$neprp =strtoupper($deces['neprp']);
$neprparabe =strtoupper($deces['neprparabe']);
$travail_dprp =strtoupper($deces['travail_dprp']);
$prenom_mere_d =strtoupper($deces['prenom_mere_d']);
$prenom_marabe =strtoupper($deces['prenom_marabe']);
$nationalm =strtoupper($deces['nationalm']);
$neprm =strtoupper($deces['neprm']);
$neprmarabe =strtoupper($deces['neprmarabe']);
$travail_dprm =strtoupper($deces['travail_dprm']);
$nom_anterieur_d =strtoupper($deces['nom_anterieur_d']);
$nom_antarabe_d =strtoupper($deces['nom_antarabe_d']);
$nom_famille_confirme_d =strtoupper($deces['nom_famille_confirme_d']);
$nom_famille_confirmearabe_d =strtoupper($deces['nom_famille_confirmearabe_d']);
$declarant =strtoupper($deces['declarant']);
$date_acte_d =strtoupper($deces['date_acte_d']);

$adressdeclarantd=strtoupper($deces['adressdeclarantd']);
$date_acteAr=strtoupper($deces['date_acteAr']);
$Nedeclarantd=strtoupper($deces['Nedeclarantd']);
$adminEtat=strtoupper($deces['adminEtat']);
$travail_dprpAr=strtoupper($deces['travail_dprpAr']);
?>



<!DOCTYPE HTML>
<html>
        <head>
            <meta charset="utf-8">
                    <title>Modifier décé</title>

                    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
                    <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
                    <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
                    <link rel="stylesheet" type="text/css" href="../css/champ.css">

       </head>
    <body>
        <?php include("menu.php");?>
                <div class=" container"> 


                    <div class="panel panel-danger margetop">
                          
                            <div class="panel-heading">Veuiller modifier les données de  décé </div>
                               
                                <div class="panel-body">
                                        <form method="post" action="updateDeces.php" class="form">
                                            
                                        <div class="form-group">

                                                <label for="nomD"> Id de décé : <?php  echo $idd  ?></label>
                                                <input type="hidden" name="idD" 
                                                class="form-control" 
                                                value="<?php  echo $idd  ?>"><br>

                                         </div>    

                                         <div class="form-group">

<label for="nomD">N° d'acte :</label>
<input type="text" name="N_acte_d" 
placeholder="Tapez numéro de déclaration de decé " 
class="form-control"
value="<?php  echo $N_acte_d  ?>"/><br>
</div>



<div class="form-group" >
<label for="nomD">Nom:</label>   
<input type="text" name="nom_d" 
placeholder="tapez le nom de decé  " 
class="form-control"
value="<?php  echo $nom_d  ?>"required/> <br>
</div>

<div class="form-group" >
<label for="nomD">:الاسم العائلي(بالعربية)</label>   
<input type="text" name="nom_darabe" 
placeholder=" (أدخل الاسم العائلي للمولود(ة"
class="form-control"
value="<?php  echo $nom_darabe  ?>"required/> <br>
</div>

<div class="form-group">
<label for="nomD">Prénom:</label>
<input type="text" name="prenom_d" 
placeholder="tapez le prénom de decé " 
class="form-control"
value="<?php  echo $prenom_d  ?>"required/><br>
</div>




<div class="form-group">

<label for="nomD">:(الاسم الشخصيي (بالعربية</label>
<input type="text" name="prenom_darabe" 
placeholder=" (أدخل الاسم الشخصيي للمولود(ة" 
class="form-control"
value="<?php  echo $prenom_darabe  ?>"required/><br>
</div>
<div class="form-group">
<label for="nomD">CIN:</label>
<input type="text" name="carte_national_d" 
placeholder="tapez la carte nationale de decé " 
class="form-control"
value="<?php  echo $carte_national_d  ?>"required/><br>
</div>
<div class="form-group">
<label for="nomD">Ville de naissance:</label>
<input type="text" name="ville_d " 
placeholder="Tapez la ville de naissance de decé " 
class="form-control"
value="<?php  echo $ville_d  ?>"required/><br>
</div>


<div class="form-group">
<label for="nomD"> : مكان الولادة</label>
<input type="text" name="ville_darabe" 
placeholder="أدخل مكان الولادة  " 
class="form-control"
value="<?php  echo $ville_darabe  ?>"required/><br>
</div>

<div class="form-group">
<label for="nomD">Date de naissance: </label>
<input type="date" name="date_naissance_d" 
placeholder=" Tapez la date naissance de decé " 
class="form-control"
value="<?php  echo $date_naissance_d  ?>"required/><br>
</div>

<div class="form-group">
<label for="nomD">:تاريخ الولادة </label>
<input type="text" name="datearabe" 
placeholder=" (أدخل تاريخ الولادة (ميلادية" 
class="form-control"
value="<?php  echo $datearabe  ?>"required/><br>
</div>


<div class="form-group">
<label for="nomD">Corespondant au</label>
<input type="date" name="coresp_d" 
placeholder="Corespondant au (Hijri) :" 
class="form-control"
value="<?php  echo $coresp_d  ?>"required/><br>
</div>


<div class="form-group">
<label for="nomD">:الموافق ل</label>
<input type="text" name="coresp_darabe" 
placeholder="( الموافق ل (هجرية "
class="form-control"
value="<?php  echo $coresp_darabe  ?>"required/><br>
</div>


<div class="form-group">
<label for="nomD">Nationalité:</label>
<input type="text" name="national" 
placeholder="tapez la nationalité de decé " 
class="form-control"
value="<?php  echo $national  ?>"required/><br>
</div>

<div class="form-group">
<label for="nomD">N° et lieu de déclaration</label>
<input type="text" name="N_et_lieu_declaration_d" 
placeholder="Tapez numéro et lieu de déclaration de decé " 
class="form-control"
value="<?php  echo $N_et_lieu_declaration_d  ?>"required/><br>
</div>

<div class="form-group">
<label for="nomD">Travaille</label>
<input type="text" name="travail_d" 
placeholder="Tapez le travaille de decé :" 
class="form-control"
value="<?php  echo $travail_d  ?>"required/><br>

</div>

<div class="form-group">
<label for="nomD">مهنته</label>
<input type="text" name="travail_dar" 
placeholder="أدخل مهنة المتوفي " 
class="form-control"
value="<?php  echo $travail_dar  ?>"required/><br>
</div>

<div class="form-group">
<label for="nomD">Prénom de pére</label>
<input type="text" name="prenom_pere_d" 
placeholder="Tapez le prénom du pére de decé  :" 
class="form-control"
value="<?php  echo $prenom_pere_d  ?>"required/><br>
</div>

<div class="form-group">
<label for="nomD">اسم الأب</label>
<input type="text" name="prenom_parabe" 
placeholder="أدخل اسم أب المتوفي" 
class="form-control"
value="<?php  echo $prenom_parabe  ?>"required/><br>
</div>


<div class="form-group">
<label for="nomD">Nationalité du pére</label>
<input type="text" name="nationalp" 
placeholder="Tapez la nationalité du pére de décé :" 
class="form-control"
value="<?php  echo $nationalp  ?>"required/><br>
</div>
<div class="form-group">
<label for="nomD">Date de naissance du pére</label>
<input type="text" name="neprp" 
placeholder="Tapez la date de naissance du pére de décé :" 
class="form-control"
value="<?php  echo $neprp  ?>"required/><br>
</div>

<div class="form-group">
<label for="nomD">تاريخ ازدياد الأب </label>
<input type="text" name="neprparabe" 
placeholder=" أدخل تاريخ ازدياد الأب   " 
class="form-control"
value="<?php  echo $neprparabe  ?>"required/><br>
</div>
<div class="form-group">
<label for="nomD">Travaille de pére </label>
<input type="text" name="travail_dprp" 
placeholder="Tapez le travaille du pére :" 
class="form-control"
value="<?php  echo $travail_dprp  ?>"required/><br>
</div>
<div class="form-group">
<label for="nomD"> :مهنة الأب  </label>
<input type="text" name="travail_dprpAr" 
placeholder="أدخل مهنة الأب " 
class="form-control"
value="<?php  echo $travail_dprpAr  ?>"required/><br>
</div>

<div class="form-group">
<label for="nomD">Prénom de mére</label>
<input type="text" name="prenom_mere_d" 
placeholder="Tapez le nom et le prenom de la mére  :" 
class="form-control"
value="<?php  echo $prenom_mere_d  ?>"required/><br>
</div>


<div class="form-group">
<label for="nomD">اسم الأم</label>
<input type="text" name="prenom_marabe" 
placeholder="أدخل اسم أم المتوفي" 
class="form-control"
value="<?php  echo $prenom_marabe  ?>"required/><br>
</div>


<div class="form-group">
<label for="nomD">Nationalité du mére</label>
<input type="text" name="nationalm" 
placeholder="Tapez la nationalité du mére de décé :" 
class="form-control"
value="<?php  echo $nationalm  ?>"required/><br>
</div>
<div class="form-group">
<label for="nomD">Date de naissance du mére</label>
<input type="text" name="neprm" 
placeholder="Tapez la date de naissance du mére de décé :" 
class="form-control"
value="<?php  echo $neprm  ?>"required/><br>
</div>

<div class="form-group">
<label for="nomD">تاريخ ازدياد الأم </label>
<input type="text" name="neprmarabe" 
placeholder=" أدخل تاريخ ازدياد الأم   " 
class="form-control"
value="<?php  echo $neprmarabe  ?>"required/><br>
</div>
<div class="form-group">
<label for="nomD">Trvaille de mére </label>
<input type="text" name="travail_dprm" 
placeholder="Tapez le travaille du  mére:" 
class="form-control"
value="<?php  echo $travail_dprm  ?>"required/><br>
</div>


<div class="form-group">
<label for="nomD">Nom antérieur </label>
<input type="text" name="nom_anterieur_d" 
placeholder="Tapez le nom  antérieur  " 
class="form-control"
value="<?php  echo $nom_anterieur_d ?>"required/><br>
</div>

<div class="form-group">
<label for="nomD">:الاسم العائلي السابق (بالعربية) </label>
<input type="text" name="nom_antarabe_d" 
placeholder=" :(أدخل الاسم العائلي السابق (بالعربية " 
class="form-control"
value="<?php  echo $nom_antarabe_d ?>"required/><br>
</div>

 
<div class="form-group">
<label for="nomD">Nom de famille confirmer </label>
<input type="text" name="nom_famille_confirme_d" 
placeholder="Tapez le nom de famille confirmer " 
class="form-control"
value="<?php  echo $nom_famille_confirme_d ?>"required/><br>
</div>

 
<div class="form-group">
<label for="nomD"> :نفس اسم العائلة المصحح أو المقترح (بالعربية)</label>
<input type="text" name="nom_famille_confirmearabe_d" 
placeholder=" أدخل نفس اسم العائلة المصحح أو المقترح" 
class="form-control"
value="<?php  echo $nom_famille_confirmearabe_d ?>"required/><br>
</div>

 

<div class="form-group">
<label for="nomD">Déclarant </label>
<input type="text" name="declarant" 
placeholder="Tapez nom de déclarant  :" 
class="form-control"
value="<?php  echo $declarant ?>"required/><br>
</div>


<div class="form-group">
<label for="nomD">La date  de naissance de déclarant :</label>
<input type="text" name="Nedeclarantd" 
placeholder="tapez la date  de naissance de déclarant" 
class="form-control"
value="<?php  echo $Nedeclarantd ?>"required/><br>
</div>

<div class="form-group">
<label for="nomD">Adress de déclarant:</label>
<input type="text" name="adressdeclarantd" 
placeholder="tapez l'adress de déclarant" 
class="form-control"
value="<?php  echo $adressdeclarantd ?>"required/><br>
</div>

<div class="form-group">
<label for="nomD">:اسم رئيس(ة) التحرير</label>
<input type="text" name="adminEtat" 
placeholder="tapez le nom de l'admin(président) de bureau d'etat civil" 
class="form-control"
value="<?php  echo $adminEtat ?>"required/><br>
</div>

<div class="form-group">
<label for="nomD">Date d'acte :</label>
<input type="text" name="date_acte_d" 
placeholder="tapez la date d'acte " 
class="form-control"
value="<?php  echo $date_acte_d ?>"required/><br>
</div>

<div class="form-group">
<label for="nomD">: تاريخ العقد</label>
<input type="text" name="date_acteAr" 
placeholder=" أدخل تاريخ العقد (هجري)  " 
class="form-control"
value="<?php  echo $date_acteAr ?>"required/><br>
</div>
                                                   
                          
                                                    <button onclick="return confirm('Voulez-vous enregistrer les modificatios')" type="submit" class="btn btn-success">

                                                                <span class="glyphicon glyphicon-save"></span> 
                                                                    Enregistrer
                                                        </button>

                                            </form>

                                            
                                      
                                </div>
                    </div>
                </div>  

    </body>
</html>