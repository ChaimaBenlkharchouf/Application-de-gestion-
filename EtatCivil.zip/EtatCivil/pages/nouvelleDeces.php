
<!DOCTYPE HTML>
<html>

        <head>
            <meta charset="utf-8">
                    <title>nouvelle décé</title>

                    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
                    <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
                    <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
                    <link rel="stylesheet" type="text/css" href="../css/champ.css">

       </head>
    <body>
    <?php      require_once('identifier.php');?>
        <?php include("menu.php");?>
                <div class=" container"> 


                    <div class="panel panel-danger margetop">
                          
                            <div class="panel-heading">Veuiller saisir les données de la nouvelle décé</div>
                               
                                <div class="panel-body">
                                        <form method="post" action="insertDeces.php" class="form">
                                            
                                                <div class="form-group">

                                                    <label for="nomD">N° d'acte :</label>
                                                    <input type="text" name="N_acte_d" 
                                                    placeholder="Tapez numéro de déclaration de decé " 
                                                    class="form-control" required/><br>
                                                </div>

                                                
                                                    
                                                <div class="form-group" >
                                                    <label for="nomD">Nom:</label>   
                                                    <input type="text" name="nom_d" 
                                                    placeholder="tapez le nom de decé  " 
                                                    class="form-control" required/> <br>
                                                    </div>
                                                    
                                                    <div class="form-group" >
                                                    <label for="nomD">:الاسم العائلي(بالعربية)</label>   
                                                    <input type="text" name="nom_darabe" 
                                                    placeholder=" (أدخل الاسم العائلي للمولود(ة"
                                                    class="form-control"required/> <br>
                                                    </div>

                                                    <div class="form-group">
                                                    <label for="nomD">Prénom:</label>
                                                    <input type="text" name="prenom_d" 
                                                    placeholder="tapez le prénom de decé " 
                                                    class="form-control" required/><br>
                                                    </div>
                                                    
                                                 
                                                   

                                                <div class="form-group">

                                                    <label for="nomD">:(الاسم الشخصيي (بالعربية</label>
                                                    <input type="text" name="prenom_darabe" 
                                                    placeholder=" (أدخل الاسم الشخصيي للمولود(ة" 
                                                    class="form-control"required/><br>
                                                </div>
                                                <div class="form-group">
                                                    <label for="nomD">CIN:</label>
                                                    <input type="text" name="carte_national_d" 
                                                    placeholder="tapez la carte nationale de decé " 
                                                    class="form-control"required/><br>
                                                    </div>
                                                <div class="form-group">
                                                    <label for="nomD">Ville de naissance:</label>
                                                    <input type="text" name="ville_d " 
                                                    placeholder="Tapez la ville de naissance de decé " 
                                                    class="form-control"required/><br>
                                                    </div>

                                                    
                                                <div class="form-group">
                                                    <label for="nomD"> : مكان الولادة</label>
                                                    <input type="text" name="ville_darabe" 
                                                    placeholder="أدخل مكان الولادة  " 
                                                    class="form-control" required/><br>
                                                    </div>

                                                    <div class="form-group">
                                                    <label for="nomD">Date de naissance: </label>
                                                    <input type="date" name="date_naissance_d" 
                                                    placeholder=" Tapez la date naissance de decé " 
                                                    class="form-control" required/><br>
                                                    </div>
                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">:تاريخ الولادة </label>
                                                    <input type="text" name="datearabe" 
                                                    placeholder=" (أدخل تاريخ الولادة (ميلادية" 
                                                    class="form-control" required/><br>
                                                    </div>
                                                    
                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">Corespondant au</label>
                                                    <input type="date" name="coresp_d" 
                                                    placeholder="Corespondant au (Hijri) :" 
                                                    class="form-control" required/><br>
                                                    </div>

                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">:الموافق ل</label>
                                                    <input type="text" name="coresp_darabe" 
                                                    placeholder="( الموافق ل (هجرية "
                                                    class="form-control" required/><br>
                                                    </div>
                                                
                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">Nationalité:</label>
                                                    <input type="text" name="national" 
                                                    placeholder="tapez la nationalité de decé " 
                                                    class="form-control" required/><br>
                                                    </div>

                                                    <div class="form-group">
                                                    <label for="nomD">N° et lieu de déclaration</label>
                                                    <input type="text" name="N_et_lieu_declaration_d" 
                                                    placeholder="Tapez numéro et lieu de déclaration de decé " 
                                                    class="form-control" required/><br>
                                                    </div>

                                                    <div class="form-group">
                                                    <label for="nomD">Travaille</label>
                                                    <input type="text" name="travail_d" 
                                                    placeholder="Tapez le travaille de decé :" 
                                                    class="form-control" required/><br>
                                                    </div>

                                                    <div class="form-group">
                                                    <label for="nomD">مهنته</label>
                                                    <input type="text" name="travail_dar" 
                                                    placeholder="أدخل مهنة المتوفي " 
                                                    class="form-control" required/><br>
                                                    </div>

                                                    <div class="form-group">
                                                    <label for="nomD">Prénom de pére</label>
                                                    <input type="text" name="prenom_pere_d" 
                                                    placeholder="Tapez le prénom du pére de decé  :" 
                                                    class="form-control" required/><br>
                                                    </div>

                                                    <div class="form-group">
                                                    <label for="nomD">اسم الأب</label>
                                                    <input type="text" name="prenom_parabe" 
                                                    placeholder="أدخل اسم أب المتوفي" 
                                                    class="form-control" required/><br>
                                                    </div>


                                                    <div class="form-group">
                                                    <label for="nomD">Nationalité du pére</label>
                                                    <input type="text" name="nationalp" 
                                                    placeholder="Tapez la nationalité du pére de décé :" 
                                                    class="form-control" required/><br>
                                                    </div>
                                                    <div class="form-group">
                                                    <label for="nomD">Date de naissance du pére</label>
                                                    <input type="text" name="neprp" 
                                                    placeholder="Tapez la date de naissance du pére de décé :" 
                                                    class="form-control" required/><br>
                                                    </div>

                                                    <div class="form-group">
                                                    <label for="nomD">تاريخ ازدياد الأب </label>
                                                    <input type="text" name="neprparabe" 
                                                    placeholder=" أدخل تاريخ ازدياد الأب   " 
                                                    class="form-control" required/><br>
                                                    </div>
                                                    <div class="form-group">
                                                    <label for="nomD">Trvaille de pére </label>
                                                    <input type="text" name="travail_dprp" 
                                                    placeholder="Tapez le travaille du pére :" 
                                                    class="form-control" required/><br>
                                                    </div>
                                                    <div class="form-group">
                                                <label for="nomD"> :مهنة الأب  </label>
                                                <input type="text" name="travail_dprpAr" 
                                                placeholder="أدخل مهنة الأب " 
                                                class="form-control" required/><br>
                                                </div>
                                                    <div class="form-group">
                                                    <label for="nomD">Prénom de mére</label>
                                                    <input type="text" name="prenom_mere_d" 
                                                    placeholder="Tapez le nom et le prenom de la mére  :" 
                                                    class="form-control" required/><br>
                                                    </div>
                                                 
                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">اسم الأم</label>
                                                    <input type="text" name="prenom_marabe" 
                                                    placeholder="أدخل اسم أم المتوفي" 
                                                    class="form-control" required/><br>
                                                    </div>


                                                    <div class="form-group">
                                                    <label for="nomD">Nationalité du mére</label>
                                                    <input type="text" name="nationalm" 
                                                    placeholder="Tapez la nationalité du mére de décé :" 
                                                    class="form-control" required/><br>
                                                    </div>
                                                    <div class="form-group">
                                                    <label for="nomD">Date de naissance du mére</label>
                                                    <input type="text" name="neprm" 
                                                    placeholder="Tapez la date de naissance du mére de décé :" 
                                                    class="form-control" required/><br>
                                                    </div>

                                                    <div class="form-group">
                                                    <label for="nomD">تاريخ ازدياد الأم </label>
                                                    <input type="text" name="neprmarabe" 
                                                    placeholder=" أدخل تاريخ ازدياد الأم   " 
                                                    class="form-control" required/><br>
                                                    </div>
                                                    <div class="form-group">
                                                    <label for="nomD">Trvaille de mére </label>
                                                    <input type="text" name="travail_dprm" 
                                                    placeholder="Tapez le travaille du  mére:" 
                                                    class="form-control" required/><br>
                                                    </div>

                                                  
                                                    <div class="form-group">
                                                    <label for="nomD">Nom antérieur </label>
                                                    <input type="text" name="nom_anterieur_d" 
                                                    placeholder="Tapez le nom  antérieur  " 
                                                    class="form-control" required/><br>
                                                    </div>
                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">:الاسم العائلي السابق (بالعربية) </label>
                                                    <input type="text" name="nom_antarabe_d" 
                                                    placeholder=" :(أدخل الاسم العائلي السابق (بالعربية " 
                                                    class="form-control" required/><br>
                                                    </div>

                                                     
                                                    <div class="form-group">
                                                    <label for="nomD">Nom de famille confirmer </label>
                                                    <input type="text" name="nom_famille_confirme_d" 
                                                    placeholder="Tapez le nom de famille confirmer " 
                                                    class="form-control" required/><br>
                                                    </div>

                                                     
                                                    <div class="form-group">
                                                    <label for="nomD"> :نفس اسم العائلة المصحح أو المقترح (بالعربية)</label>
                                                    <input type="text" name="nom_famille_confirmearabe_d" 
                                                    placeholder=" أدخل نفس اسم العائلة المصحح أو المقترح" 
                                                    class="form-control" required/><br>
                                                    </div>

                                                     
                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">Déclarant </label>
                                                    <input type="text" name="declarant" 
                                                    placeholder="Tapez nom antérieur :" 
                                                    class="form-control" required/><br>
                                                    </div>

                                                        
                                                    <div class="form-group">
                                                    <label for="nomD">La date  de naissance de déclarant :</label>
                                                    <input type="text" name="Nedeclarantd" 
                                                    placeholder="tapez la date  de naissance de déclarant" 
                                                    class="form-control" required/><br>
                                                    </div>

                                                    <div class="form-group">
                                                    <label for="nomD">Adress de déclarant:</label>
                                                    <input type="text" name="adressdeclarantd" 
                                                    placeholder="tapez l'adress de déclarant" 
                                                    class="form-control"  required/><br>
                                                    </div>

                                                    <div class="form-group">
                                                    <label for="nomD">:اسم رئيس(ة) التحرير</label>
                                                    <input type="text" name="adminEtat" 
                                                    placeholder="tapez le nom de l'admin(président) de bureau d'etat civil" 
                                                    class="form-control"  required/><br>
                                                    </div>
                                                                                                        


                                                    <div class="form-group">
                                                    <label for="nomD">Date d'acte :</label>
                                                    <input type="text" name="date_acte_d" 
                                                    placeholder="tapez la date d'acte de naissance" 
                                                    class="form-control" required/><br>
                                                    </div>

                                                    <div class="form-group">
                                                    <label for="nomD"> :تاريخ العقد</label>
                                                    <input type="text" name="date_acteAr" 
                                                    placeholder=" أدخل تاريخ العقد (هجري)  " 
                                                    class="form-control" required/><br>
                                                    </div>

                                                        <button type="submit" class="btn btn-success">

                                                                <span class="glyphicon glyphicon-save"></span> 
                                                                    Enregistrer
                                                        </button>

                                            </form>

                                            
                                      
                                </div>
                    </div>
                </div>  

    </body>
</html>