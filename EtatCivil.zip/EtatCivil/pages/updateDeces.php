<?php
    require_once('identifier.php');

    require_once('connexiondb.php');

    $idd=isset($_POST['idD'])?$_POST['idD']:0;



    $N_acte_d=strtoupper(isset($_POST['N_acte_d'])?$_POST['N_acte_d']:"");
    $nom_d=strtoupper(isset($_POST['nom_d'])?$_POST['nom_d']:"");
    $nom_darabe=strtoupper(isset($_POST['nom_darabe'])?$_POST['nom_darabe']:"");
    $prenom_d=strtoupper(isset($_POST['prenom_d'])?$_POST['prenom_d']:"");
    $prenom_darabe=strtoupper(isset($_POST['prenom_darabe'])?$_POST['prenom_darabe']:"");
    $carte_national_d=strtoupper(isset($_POST['carte_national_d'])?$_POST['carte_national_d']:"");
    $ville_d=strtoupper(isset($_POST['ville_d'])?$_POST['ville_d']:"");    
    $ville_darabe=isset($_POST['ville_darabe'])?$_POST['ville_darabe']:"";
    $date_naissance_d=isset($_POST['date_naissance_d'])?$_POST['date_naissance_d']:"";
    $datearabe=isset($_POST['datearabe'])?$_POST['datearabe']:"";
    $coresp_d =strtoupper(isset($_POST['coresp_d'])?$_POST['coresp_d']:"");
    $coresp_darabe=strtoupper(isset($_POST['coresp_darabe'])?$_POST['coresp_darabe']:"");
    $national=strtoupper(isset($_POST['national'])?$_POST['national']:"");
    $N_et_lieu_declaration_d=strtoupper(isset($_POST['N_et_lieu_declaration_d'])?$_POST['N_et_lieu_declaration_d']:"");
    $travail_d=strtoupper(isset($_POST['travail_d'])?$_POST['travail_d']:"");
    $travail_dar=isset($_POST['travail_dar'])?$_POST['travail_dar']:"";
    $prenom_pere_d=strtoupper(isset($_POST['prenom_pere_d'])?$_POST['prenom_pere_d']:"");
    $prenom_parabe=isset($_POST['prenom_parabe'])?$_POST['prenom_parabe']:"";
    $nationalp=strtoupper(isset($_POST['nationalp'])?$_POST['nationalp']:"");
    $neprp=strtoupper(isset($_POST['neprp'])?$_POST['neprp']:"");
    $neprparabe=strtoupper(isset($_POST['neprparabe'])?$_POST['neprparabe']:"");
    $travail_dprp=strtoupper(isset($_POST['travail_dprp'])?$_POST['travail_dprp']:"");
    $prenom_mere_d=strtoupper(isset($_POST['prenom_mere_d'])?$_POST['prenom_mere_d']:"");

    $prenom_marabe=isset($_POST['prenom_marabe'])?$_POST['prenom_marabe']:"";

    $nationalm=strtoupper(isset($_POST['nationalm'])?$_POST['nationalm']:"");
    $neprm=strtoupper(isset($_POST['neprm'])?$_POST['neprm']:"");
    $neprmarabe=isset($_POST['neprmarabe'])?$_POST['neprmarabe']:"";
    $travail_dprm=strtoupper(isset($_POST['travail_dprm'])?$_POST['travail_dprm']:"");
    $nom_anterieur_d=strtoupper(isset($_POST['nom_anterieur_d'])?$_POST['nom_anterieur_d']:"");
    $nom_antarabe_d=strtoupper(isset($_POST['nom_antarabe_d'])?$_POST['nom_antarabe_d']:"");
    $nom_famille_confirme_d=strtoupper(isset($_POST['nom_famille_confirme_d'])?$_POST['nom_famille_confirme_d']:"");
    $nom_famille_confirmearabe_d=strtoupper(isset($_POST['nom_famille_confirmearabe_d'])?$_POST['nom_famille_confirmearabe_d']:"");
    $declarant=strtoupper(isset($_POST['declarant'])?$_POST['declarant']:"");
    $date_acte_d=isset($_POST['date_acte_d'])?$_POST['date_acte_d']:"";
    
    $adressdeclarantd=isset($_POST['adressdeclarantd'])?$_POST['adressdeclarantd']:"";
    $date_acteAr=isset($_POST['date_acteAr'])?$_POST['date_acteAr']:"";
    $Nedeclarantd=isset($_POST['Nedeclarantd'])?$_POST['Nedeclarantd']:"";
    $adminEtat=isset($_POST['adminEtat'])?$_POST['adminEtat']:"";
    $travail_dprpAr=isset($_POST['travail_dprpAr'])?$_POST['travail_dprpAr']:"";





    $requete="update deces set N_acte_d=?, nom_d=?, nom_darabe=?, prenom_d=?, prenom_darabe=?, carte_national_d=?, ville_d=?, 
    ville_darabe=?, date_naissance_d=?, datearabe=?, coresp_d=?, coresp_darabe=?, national=?, N_et_lieu_declaration_d=?,
    travail_d=?, travail_dar=?, prenom_pere_d=?, prenom_parabe=?, nationalp=?, neprp=?, neprparabe=?, 
    travail_dprp=?,   prenom_mere_d=? , prenom_marabe=?,
    nationalm=?,   neprm=? , neprmarabe=?,
    travail_dprm=?,   nom_anterieur_d=? , nom_antarabe_d=?,
    nom_famille_confirme_d=?,   nom_famille_confirmearabe_d=? , declarant=?,
    date_acte_d=?,date_acteAr=?,adressdeclarantd=?,Nedeclarantd=?,adminEtat=?,travail_dprpAr=?  where idDeces=?";


    $params=array($N_acte_d, $nom_d, $nom_darabe, $prenom_d, $prenom_darabe, $carte_national_d, $ville_d, 
    $ville_darabe, $date_naissance_d, $datearabe, $coresp_d, $coresp_darabe, $national, $N_et_lieu_declaration_d,
    $travail_d, $travail_dar, $prenom_pere_d, $prenom_parabe, $nationalp, $neprp, $neprparabe, 
    $travail_dprp,   $prenom_mere_d , $prenom_marabe,
    $nationalm,   $neprm, $neprmarabe,
    $travail_dprm,   $nom_anterieur_d , $nom_antarabe_d,
    $nom_famille_confirme_d,   $nom_famille_confirmearabe_d , $declarant,
    $date_acte_d,$date_acteAr,$adressdeclarantd,$Nedeclarantd,$adminEtat,$travail_dprpAr,$idd);
    
    $resultat=$pdo->prepare($requete);
    $resultat->execute($params);

    header('location:décés.php');


?>