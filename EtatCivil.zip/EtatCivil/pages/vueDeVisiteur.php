<?php
         require_once('identifier.php');
         require_once("connexiondb.php");
              
              $size= isset($_GET['size'])?$_GET['size']:5;
              $page=isset($_GET['page'])?$_GET['page']:1 ;
              $offset=($page-1)*$size;

              $idd=isset($_GET['idD'])?$_GET['idD']:0;
              $requete="select * from naissance where idNaissance=$idd";
                            $nomd=isset($_GET['nomD'])?$_GET['nomD']:"all";
                            $idd=isset($_GET['idD'])?$_GET['idD']:0;
                            $requete="select * from deces where idDeces=$idd";
                            
                            $resultat=$pdo->query($requete);
                            $deces=$resultat->fetch();
                            
$N_acte_d=strtoupper($deces['N_acte_d']);
$nom_d=strtoupper($deces['nom_d']);
$nom_darabe=strtoupper($deces['nom_darabe']);
$prenom_d=strtoupper($deces['prenom_d']);
$prenom_darabe=strtoupper($deces['prenom_darabe']);
$carte_national_d=strtoupper($deces['carte_national_d']);
$ville_d=strtoupper($deces['ville_d']);
$ville_darabe=strtoupper($deces['ville_darabe']);
$date_naissance_d=strtoupper($deces['date_naissance_d']);
$datearabe=$deces['datearabe'];
$coresp_d=strtoupper($deces['coresp_d']);
$coresp_darabe=strtoupper($deces['coresp_darabe']);
$national=strtoupper($deces['national']);
$N_et_lieu_declaration_d=strtoupper($deces['N_et_lieu_declaration_d']);
$travail_d=strtoupper($deces['travail_d']);
$travail_dar=strtoupper($deces['travail_dar']);
$prenom_pere_d =strtoupper($deces['prenom_pere_d']);
$prenom_parabe =strtoupper($deces['prenom_parabe']);
$nationalp =strtoupper($deces['nationalp']);
$neprp =strtoupper($deces['neprp']);
$neprparabe =strtoupper($deces['neprparabe']);
$travail_dprp =strtoupper($deces['travail_dprp']);
$prenom_mere_d =strtoupper($deces['prenom_mere_d']);
$prenom_marabe =strtoupper($deces['prenom_marabe']);
$nationalm =strtoupper($deces['nationalm']);
$neprm =strtoupper($deces['neprm']);
$neprmarabe =strtoupper($deces['neprmarabe']);
$travail_dprm =strtoupper($deces['travail_dprm']);
$nom_anterieur_d =strtoupper($deces['nom_anterieur_d']);
$nom_antarabe_d =strtoupper($deces['nom_antarabe_d']);
$nom_famille_confirme_d =strtoupper($deces['nom_famille_confirme_d']);
$nom_famille_confirmearabe_d =strtoupper($deces['nom_famille_confirmearabe_d']);
$declarant =strtoupper($deces['declarant']);
$date_acte_d =strtoupper($deces['date_acte_d']);
$adressdeclarantd=strtoupper($deces['adressdeclarantd']);
$date_acteAr=strtoupper($deces['date_acteAr']);
$Nedeclarantd=strtoupper($deces['Nedeclarantd']);
$adminEtat=strtoupper($deces['adminEtat']);

             
        
if($nomd=="all")
{
       
       $requete="select * from deces
       where (nom_d like '%$N_acte_d%' or N_acte_d like '%$N_acte_d%'
       or nom_darabe like '%$N_acte_d%')
       limit $size offset $offset ";

       $requeteCount="select count(*) countD from deces
       where (nom_d like '%$N_acte_d%' or N_acte_d like '%$N_acte_d%'
       or nom_darabe like '%$N_acte_d%')";

}
else{
       $requete="select * from deces
       where nom_d like '%$nom_d%'and (N_acte_d like '%$N_acte_d%')
       and nom_darabe like '%$nom_darabe%'
     
       and idDeclaration='$nomd' 
       
       limit $size  offset $offset ";

       $requeteCount="select count(*) countD deces
       where  (nom_d like '%$N_acte_d%' or N_acte_d like '%$N_acte_d%'
       or nom_darabe like '%$N_acte_d%')
     

       and idDeclaration='$nomd' ";

}
       $resultatD=$pdo->query($requete);
       $resultatCount=$pdo->query($requeteCount);
       $tabCount=$resultatCount->fetch();
       $nbrNaissance=$tabCount['countD'];
       $reste=$nbrNaissance % $size;

       if($reste===0)
              $nbrPage=$nbrNaissance/$size;
       else
              $nbrPage=floor($nbrNaissance/$size) + 1;


                     
       
?>

<!DOCTYPE HTML>
<html>
       <head>
              <meta charset="utf-8">
              <title>Acte de décée </title>
              <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
              <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
              <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
              <meta name="viewport" content="width=device-width, initial-scale=1">
              <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
              <link rel="stylesheet" href="print.css" >

              <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


                <STYle>
                DIV.double {
                    border-style: double;
                    border-radius: 20px;
                }
                pre.arb{
                  background: white ;
                }
             
                </STYle>
            
       </head>
       <body  style="background-image: url('../images/etat1.jpg')"; >


       <?php include("menu2.php");?><br><br>      
       <div style="width:85%;" class="container ">
             <div class="panel panel-primary margetop">
        <div class="panel-heading" align="center">نسخة موجزة من رسم الوفيات</div>
          <div  > <h5   align="center"><b> Extrait d'acte de décés</b> </h5>
          <h5 align="center"><b><i> نسخة موجزة من رسم الوفيات</i></b> </h5>  </div> 
                 <div  align="center">        <img src="../images/kingdom.jpg" alt="kingdom" style="width:100px;height:120px;">                   
<H6 ><B><div align="left">   ROYAUME DU MAROC</div>                                                                                                                   <div align="right">   المملكة المغربية </div>
<div align="left">MINISTERE DE L'INTERIEUR</div>                                                                                                               <div align="right">  وزارة الداخلية</div>  
<div align="left">       REGION</div>                                                                                                                     <div align="right">   جهة الدارالبيضاء-سطات</div>
<div align="left">   CASABLANCA-STAT</div>                                                                                                                <div align="right">    عمالة اقليم الجديدة </div></B></H6>
<div align="center">    ____________________________________________________     </div>          
<div align="left">Commune : El jadida</div>                                                                                                               <div align="right">   جماعة الجديدة</div>
<div align="left">Bureau de l'état civil : arr 1</div>                                                                                            <div align="right"> مكتب الحالة المدني:  م1</div>
<div align="left">Acte n°  : <b><?php echo $deces['N_acte_d'] ?> </b></div>                                                                                                               <div align="right">    <b><?php echo $deces['N_acte_d'] ?> </b>    :رقم الرسم</div>
<div align="left">Année  : <b><?php echo $deces['date_acte_d'] ?> </b></div>                                                                                                       <div align="right">   <b><?php echo $deces['date_acte_d'] ?> </b>    :السنة</div>
<div align="left">Nom  : <?php echo $deces['nom_d'] ?></div>                                                                                                                      <div align="right"> الاسم العائلي :<b><?php echo $deces['nom_darabe'] ?> </div></b></b>
<div align="left">Prénom  :  <?php echo $deces['prenom_d'] ?></div>                                                                                                                     <div align="right"> الاسم الشخصيي: <b><?php echo $deces['prenom_darabe'] ?></div></b>
<div align="left">Né(é) le : <?php echo $deces['date_naissance_d'] ?></div>                                                                                                                                  <div align="right">    تاريخ الولادة: <b><?php echo $deces['datearabe'] ?></div></b>
<div align="left">Corespondant au  :  <?php echo $deces['coresp_d'] ?></div>                                                                                                                                <div align="right">      الموافق: <b><?php echo $deces['coresp_darabe'] ?></div></b>
<div align="left">Lieu de naissance  :  <?php echo $deces['ville_d'] ?></div>                                                                                                                               <div align="right">  مكان الولادة: <b><?php echo $deces['ville_darabe'] ?></div></b>
<div align="left">Nationalité  :    <?php echo $deces['nationalp'] ?>  </div>                                                                                                        <div align="right"> جنسيته: <b>مغريبي(ة)</b></div>
<div align="left">CIN  :    <?php echo $deces['carte_national_d'] ?>  </div>                                                                                                       
<div align="left">N° et lieu de déclaration  :    <?php echo $deces['N_et_lieu_declaration_d'] ?> </div>                                                                                                        
<div align="left">Travaille   :    <?php echo $deces['travail_d'] ?>  </div>                                                                                                          <div align="right">   مهنته: <b><?php echo $deces['travail_dar'] ?></div></b>
<div align="left">Fils ou fille de :  <?php echo $deces['prenom_pere_d'] ?></div>                                                                                                                          <div align="right">   والده(ا) هو: <b><?php echo $deces['prenom_parabe'] ?></div></b>
<div align="left">Nationalité de pére :    <?php echo $deces['nationalp'] ?> </div>                                                                                                        <div align="right"> جنسيته: <b>مغريبي(ة)</b></div>
<div align="left">Date de naissance de pére  :    <?php echo $deces['neprp'] ?>  </div>                                                                                                        <div align="right">    تاريخ ازدياد الأب: <b><?php echo $deces['neprparabe'] ?></div></b>
<div align="left">Travialle de pére  :    <?php echo $deces['travail_dprp'] ?> </div>                                                                                                        <div align="right">    مهنة الأب: <b><?php echo $deces['travail_dprp'] ?></div></b>
<div align="left">Et de :  <?php echo $deces['prenom_mere_d'] ?></div>                                                                                                                      <div align="right">    والدتها هي : <b><?php echo $deces['prenom_marabe'] ?></div></b>
<div align="left">Nationalité de mére  :    <?php echo $deces['nationalm'] ?> </div>                                                                                                        <div align="right"> جنسيته: <b>مغريبي(ة)</b></div><br><br>
<div align="left">Date de naissance de mére :    <?php echo $deces['neprm'] ?>  </div>                                                                                                        <div align="right">    تاريخ ازدياد الأم : <b><?php echo $deces['neprmarabe'] ?></div></b>
<div align="left">travaille de mére  :    <?php echo $deces['travail_dprm'] ?>  </div>                                                                                                        <div align="right">  مهنةالأم : <b><?php echo $deces['travail_dprm'] ?></div></b>


<div align="right">    نشهد بصفتنا ضابطا الحالة المدنية نحن : رئيس المجلس الجماعي </div>
<div align="right"> بمطابقة هذه النسخة لما هو مضمن في سجلات الحالة المدنية بالمكتب المذكور </div>
<div align="left"> Extrait certifié conforme aux registres de l'état civil , par 
  nous le président et officier de l'état civil </div>

                     El jadida le :                  <?php echo $deces['date_acte_d'] ?>             <div align="right"> :الجديدة في</div>
                     L'officier de l'état civil                       <div align="right"> ضابط الحالة المدنية</div>
                                
 <div align="left"><b>Signature </b></div><div align="right"> <b>Date</b> </div>
                 </div><br><br><br>
         </div> 
</div>  </div></div> 
                         <div align="center"> 
                            <button  type="submit" class="btn btn-success" onclick="window.print();" classe="btn btn primary" id="print-btn" >
                                          <span href="vueDeclaration.php"> <i class="material-icons">&#xe8ad;</i>
                                          <b>Imprimer </b>
                                          </span> 
                            </button>
                                     </div> <br><br><br>
                                  
</body>
</html>