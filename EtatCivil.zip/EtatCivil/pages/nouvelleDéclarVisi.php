<!DOCTYPE HTML>
<html>
        <head>
            <meta charset="utf-8">
                    <title>Déclaration pour l'utilisateur</title>

                    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
                    <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
                    <link rel="stylesheet" type="text/css" href="../css/champ.css">

                    <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
       </head>
       <body  style="background-image: url('../images/zh1.jpg')"; >

        <?php include("menu2.php");?>
                <div class=" container"> 


                    <div class="panel panel-danger margetop">
                          
                            <div class="panel-heading">Veuillea saisir les données de la nouvelle déclaration</div>
                               
                                <div class="panel-body">
                                        <form method="post" action="insertDéclavisi.php" class="form">
                                            
                                                <div class="form-group">

                                                    <label for="nomD">Numéro de déclaration :</label>
                                                    <input type="text" name="num" 
                                                    placeholder="Numéro de déclaration" 
                                                    class="form-control" required/><br>
                                                </div>

                                                
                                                    
                                                <div class="form-group" >
                                                    <label for="nomD">Nom:</label>   
                                                    <input type="text" name="nom" 
                                                    placeholder="Nom " 
                                                    class="form-control" required/> <br>
                                                    </div>
                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">Prénom:</label>
                                                    <input type="text" name="prenom" 
                                                    placeholder="Prénom" 
                                                    class="form-control" required/><br>
                                                    </div>
                                                    
                                                    <div class="form-group">

                                                <label for="nomD">(الاسم العائلي (بالعربية</label>
                                                <input type="text" name="nomarabe" 
                                                placeholder="الاسم العائلي" 
                                                class="form-control"required/><br>
                                                </div>

                                                <div class="form-group">

                                                <label for="nomD">(الاسم الشخصيي (بالعربية</label>
                                                <input type="text" name="prenomarabe" 
                                                placeholder="الاسم الشخصيي" 
                                                class="form-control"required/><br>
                                                </div>

                                                    <div class="form-group">
                                                    <label for="nomD">Date de naissance: </label>
                                                    <input type="date" name="date" 
                                                    placeholder="Date naissance" 
                                                    class="form-control"/><br>
                                                    </div>
                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">Ville de naissance:</label>
                                                    <input type="text" name="ville" 
                                                    placeholder="Ville" 
                                                    class="form-control"required/><br>
                                                    </div>
                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">Carte national</label>
                                                    <input type="text" name="carteN" 
                                                    placeholder="CIN: Carte national" 
                                                    class="form-control"required/><br>
                                                    </div>
                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">Adress:</label>
                                                    <input type="text" name="adress" 
                                                    placeholder="Adress actuel" 
                                                    class="form-control"required/><br>
                                                    </div>
                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">N° de téléphone ou email:</label>
                                                    <input type="text" name="tele_email" 
                                                    placeholder="télé/eamil" 
                                                    class="form-control"required/><br>
                                                    </div>
                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">Prénom de pére:</label>
                                                    <input type="text" name="prp" 
                                                    placeholder="Prénom de pére" 
                                                    class="form-control"required/><br>
                                                    </div>

                                                    <div class="form-group">

                                                <label for="nomD"> (اسم الأب (بالعربية</label>
                                                <input type="text" name="prparabe" 
                                                placeholder="الاسم الأب" 
                                                class="form-control"required/><br>
                                                </div>
                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">Prénom de mére:</label>
                                                    <input type="text" name="prm" 
                                                    placeholder="Prénom de mére" 
                                                    class="form-control"required/><br>
                                                    </div>
                                                    
                                                    <div class="form-group">

                                                <label  for="nomD"> (اسم الأم (بالعربية</label>
                                                <input  type="text" name="prmarabe" 
                                                placeholder="الاسم الأم" 
                                                class="form-control"required/><br>
                                                </div>
                                                    
                          
                                        <div class="form-group">
                                            <label for="nomD" >Type de déclaration :</label>  

                                                <select name="nomD" class="form-control" id="nomD" required>
                                                      
                                                       
                                                        <option value="DN"  > DN( Declaration de naissance normale )</option>
                                                        <option value="DNC"> DNC( Declaration de naissance cas voyage )</option>
                                                        <option value="DNE" selected> DNE( Declaration de naissance d"enfant abandonné )</option>
                                                        <option value="DD"  > DD( Declaration de décées normale )</option>
                                                        <option value="DDA" > DDA( Declaration de décés anormales )</option>
                                                </select><br>
                                        </div>
                                                        <button type="submit" class="btn btn-success">

                                                                <span class="glyphicon glyphicon-valide"></span> 
                                                                    Validé
                                                        </button>

                                            </form>

                                            
                                      
                                </div>
                    </div>
                </div>  

    </body>
</html>