<?php
session_start();   
if(isset($_SESSION['user'])) {
   
    require_once('connexiondb.php');

    $idd=isset($_GET['idD'])?$_GET['idD']:0;

   /*
    $requeteN="select count(*) countN from naissance where idNaissance=$idd";
    $resultatN=$pdo->query($requeteN);
    $tabCountN=$resultatNais->fetch();
    $nbrNais=$tabCountN['countN'];

    if($nbrNais==0){ */
    $requete="delete from  naissance where idNaissance=?";
    $params=array($idd);
    $resultat=$pdo->prepare($requete);
    $resultat->execute($params);
    header('location:naissance.php');
   /* }else{
        $msg="Supression impossible: Vous devez supprimer tous  les informations inscris dans cette page de naissance.";
        header("location:alert.php?message=$msg");
        
    }
    */
}else{
    header('location:login.php');

}
  

?>