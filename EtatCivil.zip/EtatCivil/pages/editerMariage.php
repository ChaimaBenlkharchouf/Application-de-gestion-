<?php

require_once('identifier.php');
require_once('connexiondb.php');

$idd=isset($_GET['idD'])?$_GET['idD']:0;
$requete="select * from mariage where idMar=$idd";

$resultatM=$pdo->query($requete);
$deces=$resultatM->fetch();

$numMAH=strtoupper($deces['numMAH']);
$dateM=strtoupper($deces['dateM']);
$numdossier=strtoupper($deces['numdossier']);
$time=strtoupper($deces['time']);
$dateMam=strtoupper($deces['dateMam']);
$dateMah=strtoupper($deces['dateMah']);
$nomadl1=strtoupper($deces['nomadl1']);
$nomadl2=strtoupper($deces['nomadl2']);
$page=strtoupper($deces['page']);
$numero=strtoupper($deces['numero']);
$wasl=strtoupper($deces['wasl']);
$nomh=strtoupper($deces['nomh']);
$prenomh=strtoupper($deces['prenomh']);
$dateNeh=strtoupper($deces['dateNeh']);
$villeh=strtoupper($deces['villeh']);
$prph=strtoupper($deces['prph']);
$mereh =strtoupper($deces['mereh']);
$nationalh =strtoupper($deces['nationalh']);
$travailh =strtoupper($deces['travailh']);
$habiteh =strtoupper($deces['habiteh']);
$cinh =strtoupper($deces['cinh']);
$etath =strtoupper($deces['etath']);
$nomf =strtoupper($deces['nomf']);
$prenomf =strtoupper($deces['prenomf']);
$dateNef =strtoupper($deces['dateNef']);
$villef =strtoupper($deces['villef']);
$prpf =strtoupper($deces['prpf']);
$cinprpf =strtoupper($deces['cinprpf']);
$neprpf =strtoupper($deces['neprpf']);
$nationalprpf =strtoupper($deces['nationalprpf']);
$travailprpf =strtoupper($deces['travailprpf']);
$meref =strtoupper($deces['meref']);
$nationalf =strtoupper($deces['nationalf']);
$travailf =strtoupper($deces['travailf']);
$habitef =strtoupper($deces['habitef']);
$cinf =strtoupper($deces['cinf']);
$etatf =strtoupper($deces['etatf']);
$prix =strtoupper($deces['prix']);
$date_acteM =strtoupper($deces['date_acteM']);
$date_acteH =strtoupper($deces['date_acteH']);



?>



<!DOCTYPE HTML>
<html>
        <head>
            <meta charset="utf-8">
                    <title>Modifier mariage</title>

                    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
                    <link rel="stylesheet" type="text/css" href="../css/champ.css">

                    <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
                    <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
       </head>
    <body>
        <?php include("menu.php");?>
                <div class=" container"> 


                    <div class="panel panel-danger margetop">
                          
                            <div class="panel-heading">Veuiller modifier les données de mariage </div>
                               
                                <div class="panel-body">
                                        <form method="post" action="updateMariage.php" class="form">
                                        <div class="form-group">

<label for="nomD"> Id de Mariage : <?php  echo $idd  ?></label>
<input type="hidden" name="idD" 
class="form-control" 
value="<?php  echo $idd  ?>"><br>

</div>   
                                      
<div class="form-group">
<label for="nomD"> :رقم المحكمة الابتدائية</label>
<input type="text" name="numMAH" 
placeholder=" أدخل رقم قسم قضاء الأسرة بالمحكمة الابتدائية بالجديدة " 
class="form-control"   
 value="<?php  echo $numMAH  ?>"required/><br>
</div>



<div class="form-group" >
<label for="nomD">:تاريخ الطلب </label>   
<input type="date" name="dateM" 
placeholder="أدخل تاريخ الطلب الزواج " 
class="form-control"
value="<?php  echo $dateM  ?>"required /> <br>
</div>
<div class="form-group" >
<label for="nomD">:رقم الملف</label>   
<input type="text" name="numdossier" 
placeholder="أدخل رقم ملف مستندات الزواج  " 
class="form-control"
value="<?php  echo $numdossier  ?>"required/> <br>
</div>
<div class="form-group" >
<label for="nomD">:على الساعة  </label>   
<input type="text" name="time" 
placeholder="أدخل وقت تسجيل الطلب " 
class="form-control"
value="<?php  echo $time  ?>"required/> <br>
</div>
<div class="form-group" >
<label for="nomD">: تاريخ الزواج (ميلادي) </label>   
<input type="date" name="dateMam" 
placeholder="أدخل تاريخ الزواج الميلادي " 
class="form-control"
value="<?php  echo $dateMam  ?>"required/> <br>
</div>
<div class="form-group" >
<label for="nomD">:تاريخ الزواج(هجري) </label>   
<input type="date" name="dateMah" 
placeholder="أدخل تاريخ الزواج الهجري   " 
class="form-control"
value="<?php  echo $dateMah  ?>"required/> <br>
</div>


<div class="form-group">
<label for="nomD">:اسم العدل الأول </label>
<input type="text" name="nomadl1" 
placeholder="أدخل اسم العدل الأول" 
class="form-control"
value="<?php  echo $nomadl1  ?>"required/><br>
</div>




<div class="form-group">

<label for="nomD">:اسم العدل الثاني </label>
<input type="text" name="nomadl2" 
placeholder=" (أدخل اسم العدل الثاني(ة" 
class="form-control"
value="<?php  echo $nomadl2  ?>"required/><br>
</div>
<div class="form-group">
<label for="nomD"> :الصفحة</label>
<input type="text" name="page" 
placeholder="  أدخل رقم الصفحة " 
class="form-control"
value="<?php  echo $page  ?>"required/><br>
</div>
<div class="form-group">
<label for="nomD">:عدد</label>
<input type="text" name="wasl " 
placeholder="أدخل عدد الملف" 
class="form-control"
value="<?php  echo $wasl  ?>"required/><br>
</div>


<div class="form-group">
<label for="nomD"> : الوصل</label>
<input type="text" name="wasl" 
placeholder="أدخل رقم الوصل  " 
class="form-control"
value="<?php  echo $wasl  ?>"required/><br>
</div>

<div class="form-group">
<label for="nomD">:الاسم العائلي للزوج </label>
<input type="text" name="nomh" 
placeholder=" أدخل الاسم العائلي للزوج" 
class="form-control"
value="<?php  echo $nomh  ?>"required/><br>
</div>
<div class="form-group">
<label for="nomD">:الاسم الشخصي للزوج </label>
<input type="text" name="prenomh" 
placeholder=" أدخل الاسم الشخصي للزوج  " 
class="form-control"
value="<?php  echo $prenomh  ?>"required/><br>
</div>
<div class="form-group">
<label for="nomD">:تاريخ ازدياد الزوج </label>
<input type="date" name="dateNeh" 
placeholder=" (أدخل تاريخ الولادة (ميلادية" 
class="form-control"
value="<?php  echo $dateNeh  ?>"required/><br>
</div>


<div class="form-group">
<label for="nomD">مكان ازدياد الزوج</label>
<input type="text" name="villeh" 
placeholder="أدخل مكان ازدياد الزوج" 
class="form-control"
value="<?php  echo $villeh  ?>"required/><br>
</div>


<div class="form-group">
<label for="nomD">:اسم أب الزوج</label>
<input type="text" name="prph" 
placeholder=" أدخل اسم أب الزوج" 
 class="form-control"
 value="<?php  echo $prph  ?>"required/><br>
</div>


<div class="form-group">
<label for="nomD">:اسم أم الزوج</label>
<input type="text" name="mereh" 
placeholder="أدخل اسم أم الزوج  " 
class="form-control"
value="<?php  echo $mereh  ?>"required/><br>
</div>

<div class="form-group">
<label for="nomD">جنسيته </label>
<input type="text" name="nationalh" 
placeholder=" أدخل جنسية الزوج" 
class="form-control"
value="<?php  echo $nationalh  ?>"required/><br>
</div>

<div class="form-group">
<label for="nomD">:مهنته</label>
<input type="text" name="travailh" 
placeholder=" أدخل مهنة الزوج" 
class="form-control"
value="<?php  echo $travailh  ?>"required/><br>
</div>

<div class="form-group">
<label for="nomD">:الساكن في </label>
<input type="text" name="habiteh" 
placeholder="أدخل مقر سكن الزوج " 
class="form-control"
value="<?php  echo $habiteh  ?>"required/><br>
</div>

<div class="form-group">
<label for="nomD">CIN</label>
<input type="text" name="cinh" 
placeholder="أدخل رمز البطاقة الوطنية" 
class="form-control"
value="<?php  echo $cinh  ?>"required/><br>
</div>

<div class="form-group">
<label for="nomD">:حالته</label>
<input type="text" name="etath" 
placeholder="(أدخل حالة الزوج (عازب /مطلق/ أرمل" 
class="form-control"
value="<?php  echo $etath  ?>"required/><br>
</div>


<div class="form-group">
<label for="nomD">:الاسم العائلي للزوجة </label>
<input type="text" name="nomf" 
placeholder=" أدخل الاسم العائلي للزوجة " 
class="form-control"
value="<?php  echo $nomf  ?>"required/><br>
</div>
<div class="form-group">
<label for="nomD">:الاسم الشخصي للزوجة </label>
<input type="text" name="prenomf" 
placeholder="  أدخل الاسم الشخصي للزوجة " 
class="form-control"
value="<?php  echo $prenomf  ?>"required/><br>
</div>
<div class="form-group">
<label for="nomD">:تاريخ ازدياد الزوجة </label>
<input type="date" name="dateNef" 
placeholder=" (أدخل تاريخ ازدياد الزوجة(ميلادية" 
class="form-control"
value="<?php  echo $dateNef  ?>"required/><br>
</div>


<div class="form-group">
<label for="nomD">مكان ازدياد الزوجة</label>
<input type="text" name="villef" 
placeholder="أدخل مكان ازدياد الزوجة " 
class="form-control"
value="<?php  echo $villef  ?>"required/><br>
</div>


<div class="form-group">
<label for="nomD">:اسم أب الزوجة</label>
<input type="text" name="prpf" 
placeholder="أدخل اسم أب الزوجة "
class="form-control"
value="<?php  echo $prpf  ?>"required/><br>
</div>


<div class="form-group">
<label for="nomD">CIN de pére</label>
<input type="text" name="cinprpf" 
placeholder="أدخل رمز البطاقة الوطنية للأب "
class="form-control" 
value="<?php  echo $cinprpf  ?>"required/><br>
</div>

<div class="form-group">
<label for="nomD">:تاريخ ازدياد الأب </label>
<input type="date" name="neprpf" 
placeholder="(أدخل  تاريخ ازدياد الأب (ميلادي "
class="form-control"
 value="<?php  echo $neprpf  ?>"required/><br>
</div>
<div class="form-group">
<label for="nomD">: جنسية الأب </label>
<input type="text" name="nationalprpf" 
placeholder=" أدخل جنسية الأب  "
class="form-control"
value="<?php  echo $nationalprpf  ?>"required/><br>
</div>

<div class="form-group">
<label for="nomD">:مهنة الأب </label>
<input type="text" name="travailprpf" 
placeholder="أدخل مهنة الأب "
class="form-control"
value="<?php  echo $travailprpf  ?>"required/><br>
</div>

<div class="form-group">
<label for="nomD">:اسم أم الزوجة</label>
<input type="text" name="meref" 
placeholder="أدخل اسم أم الزوجة  " 
class="form-control"
value="<?php  echo $meref  ?>"required/><br>
</div>

<div class="form-group">
<label for="nomD">جنسيتها</label>
<input type="text" name="nationalf" 
placeholder="أدخل جنسية الزوجة   " 
class="form-control"
value="<?php  echo $nationalf  ?>"required/><br>
</div>

<div class="form-group">
<label for="nomD">:مهنتها</label>
<input type="text" name="travailf" 
placeholder="أدخل مهنة الزوجة" 
class="form-control"
value="<?php  echo $travailf  ?>"required/><br>
</div>

<div class="form-group">
<label for="nomD">:الساكنة في </label>
<input type="text" name="habitef" 
placeholder="أدخل مقر سكن الزوجة " 
class="form-control"
value="<?php  echo $habitef  ?>"required/><br>
</div>

<div class="form-group">
<label for="nomD">CIN</label>
<input type="text" name="cinf" 
placeholder="أدخل رمز البطاقة الوطنية للزوجة" 
class="form-control"
value="<?php  echo $cinf  ?>"required/><br>
</div>


<div class="form-group">
<label for="nomD">:حالتها</label>
<input type="text" name="etatf" 
placeholder="(أدخل حالة الزوجة (عازب /مطلق/ أرمل" 
class="form-control"
value="<?php  echo $etatf  ?>"required/><br>
</div>
  
<div class="form-group">
                                                    <label for="nomD">:الصداق</label>
                                                    <input type="text" name="prix" 
                                                    placeholder="الصداق المتفق عليه بالدرهم " 
                                                    class="form-control"
                                                    value="<?php  echo $prix  ?>"required/><br>
                                                    </div>
<div class="form-group">
<label for="nomD">:تاريخ العقد (ميلادي) </label>
<input type="date" name="date_acteM" 
placeholder=" أدخل تاريخ العقد (ميلادي) "
class="form-control"
value="<?php  echo $date_acteM  ?>"required/><br>
</div>
<div class="form-group">
<label for="nomD">:تاريخ العقد (هجري) </label>
<input type="date" name="date_acteH" 
placeholder="أدخل تاريخ العقد (هجري) "
class="form-control"
value="<?php  echo $date_acteH  ?>"required/><br>
</div>

                                                   
                          
                                                    <button onclick="return confirm('Voulez-vous enregistrer les modificatios')" type="submit" class="btn btn-success">

                                                                <span class="glyphicon glyphicon-save"></span> 
                                                                    Enregistrer
                                                        </button>

                                            </form>

                                            
                                      
                                </div>
                    </div>
                </div>  

    </body>
</html>