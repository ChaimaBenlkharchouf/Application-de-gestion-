<?php
require_once('identifier.php');

     require_once("connexiondb.php");
  
    $login=isset($_GET['login1'])?$_GET['login1']:"";
    
    $size=isset($_GET['size'])?$_GET['size']:4;
    $page=isset($_GET['page'])?$_GET['page']:1;
    $offset=($page-1)*$size;
    

        $requeteuser="select * from utilisateur where login1 like '%$login%'
        limit $size offset $offset";
        
        $requeteCount="select count(*) countUser from utilisateur
        where login1 like '%$login%'";
  


        
    $resultatuser=$pdo->query($requeteuser);
    $resultatCount=$pdo->query($requeteCount);

    $tabCount=$resultatCount->fetch();
    $nbrUser=$tabCount['countUser'];
    $reste=$nbrUser % $size;   
    if($reste===0) 
        $nbrPage=$nbrUser/$size;   
    else
        $nbrPage=floor($nbrUser/$size)+1;  
?>
<!DOCTYPE HTML>
<HTML>
    <head>
        <meta charset="utf-8">
        <title>Gestion des utilisateurs</title>
        <link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
        <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
    </head>
    <body  style="background-image: url('../images/zh1.jpg')";> 
        <?php require("menu.php"); ?>
        
        <div class="container">
            <div class="panel panel-success margetop">
            
				<div class="panel-heading">Rechercher des utilisateurs</div>
				
				<div class="panel-body">
					<form method="get" action="utilisateur.php" class="form-inline">
						<div class="form-group">
						
                            <input type="text" name="login1" 
                                   placeholder="Taper votre login"
                                   class="form-control"
                                   value="<?php echo $login ?>"/>
                        </div>
                            
				            
				        <button type="submit" class="btn btn-success">
                            <span class="glyphicon glyphicon-search"></span>
                            Chercher...
                        </button> 
                        
					</form>
				</div>
			</div>
            
            <div class="panel panel-danger">
                <div class="panel-heading">Liste des utilisateurs (<?php echo $nbrUser ?> utilisateurs)</div>
                <div class="panel-body">
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>Login</th> <th>Email</th> <th>Role</th> <th>Actions</th>
                              
                            </tr>
                        </thead>
                        
                        <tbody>
                            <?php while($user=$resultatuser->fetch()){ ?>
                                <tr class="<?php echo $user['etat']==1?'success':'danger' ?>">
                                    <td><?php echo $user['login1'] ?> </td>
                                    <td><?php echo $user['email'] ?> </td>
                                    <td><?php echo $user['role1'] ?> </td> 
                                  
                                        <td>
                                            <a href="editerUtilisateur.php?iduser=<?php echo $user['iduser'] ?>">
                                                <span class="glyphicon glyphicon-edit"></span>
                                            </a>
                                            &nbsp; &nbsp;
                                            <a onclick="return confirm('Etes vous sur de vouloir supprimer cet utilisateur')"
                                            href="supprimerUtilisateur.php?iduser=<?php echo $user['iduser'] ?>">
                                                <span class="glyphicon glyphicon-trash"></span>
                                            </a>
                                            &nbsp; &nbsp;
                                            <a href="activerUtilisateur.php?iduser=<?php echo $user['iduser'] ?>&etat=<?php echo $user['etat'] ?>">
                                            <?php 
                                                 if($user['etat']==1){
                                                        echo '<span class="glyphicon glyphicon-ok"></span>';
                                                   }  else{
                                                        echo '<span class="glyphicon glyphicon-remove"></span>';
                                                   }
                                            ?>
                                            </a>
                                        </td>
                                    <?php }?>
                                    
                                 </tr>
                      
                        </tbody>
                    </table>
                <div>
                    <ul class="nav nav-pills">
                        <?php for($i=1;$i<=$nbrPage;$i++){ ?>
                            <li class="<?php if($i==$page) echo 'active' ?>"> 
            <a href="utilisateur.php?page=<?php echo $i;?>&login1=<?php echo $login ?>">
                                    <?php echo $i; ?>
                                </a> 
                             </li>
                        <?php } ?>
                    </ul>
                </div>
                </div>
            </div>
        </div>
    </body>
</HTML>
