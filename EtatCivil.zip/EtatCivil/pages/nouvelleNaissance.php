
<!DOCTYPE HTML>
<html>
        <head>
            <meta charset="utf-8">
                    <title>nouvelle naissance</title>

                    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
                    <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
                    <link rel="stylesheet" type="text/css" href="../css/champ.css">

                    <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
       </head>
    <body>
    <?php      require_once('identifier.php');?>

        <?php include("menu.php");?>
                <div class=" container"> 


                    <div class="panel panel-danger margetop">
                          
                            <div class="panel-heading">Veuillea saisir les données de la nouvelle naissance</div>
                               
                                <div class="panel-body">
                                        <form method="post" action="insertNaissance.php" class="form">
                                            
                                                <div class="form-group">

                                                    <label for="nomD">N° d'acte :</label>
                                                    <input type="text" name="N_acte" id="N_acte" 
                                                    placeholder="Tapez numéro de déclaration" 
                                                    class="form-control"required/><br>
                                                </div>

                                                
                                                    
                                                <div class="form-group" >
                                                    <label for="nomD">Nom:</label>   
                                                    <input type="text" name="nom"  id="nom"
                                                    placeholder="tapez le nom " 
                                                    class="form-control"required/> <br>
                                                    </div>
                                                    
                                                    <div class="form-group" >
                                                    <label for="nomD">:الاسم العائلي(بالعربية)</label>   
                                                    <input type="text" name="nomarabeN" id="nomarabeN" 
                                                    placeholder=" (أدخل الاسم العائلي المولود(ة"
                                                    class="form-control"required/> <br>
                                                    </div>

                                                    <div class="form-group">
                                                    <label for="nomD">Prénom:</label>
                                                    <input type="text" name="prenom" id="prenom" 
                                                    placeholder="tapez le prénom" 
                                                    class="form-control"required/><br>
                                                    </div>
                                                    
                                                 

                                                <div class="form-group">

                                                    <label for="nomD">:(الاسم الشخصيي (بالعربية</label>
                                                    <input type="text" name="prenomarabeN" id="prenomarabeN"
                                                    placeholder=" (أدخل الاسم الشخصيي المولود(ة" 
                                                    class="form-control"required/><br>
                                                </div>
                                                <div class="form-group">
                                                    <label for="nomD">Ville de naissance:</label>
                                                    <input type="text" name="ville " id="ville "
                                                    placeholder="Tapez la ville de naissance" 
                                                    class="form-control"required/><br>
                                                    </div>

                                                    
                                                <div class="form-group">
                                                    <label for="nomD"> : مكان الولادة</label>
                                                    <input type="text" name="villearabeN"  id="villearabeN"
                                                    placeholder="Tapez la ville de naissance" 
                                                    class="form-control"required/><br>
                                                    </div>

                                                    <div class="form-group">
                                                    <label for="nomD">Date de naissance: </label>
                                                    <input type="date" name="date_naissance" id="date_naissance"
                                                    placeholder=" Tapez la date naissance" 
                                                    class="form-control"required/><br>
                                                    </div>
                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">:تاريخ الولادة </label>
                                                    <input type="text" name="datearabeN" id="datearabeN" 
                                                    placeholder=" (أدخل تاريخ الولادة (ميلادية" 
                                                    class="form-control"required/><br>
                                                    </div>
                                                    
                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">Corespondant au</label>
                                                    <input type="date" name="corespN" id="corespN" 
                                                    placeholder="Corespondant au (Hijri) :" 
                                                    class="form-control"required/><br>
                                                    </div>

                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">:الموافق ل</label>
                                                    <input type="text" name="coresparabeN" id="coresparabeN" 
                                                    placeholder="( الموافق ل (هجرية "
                                                    class="form-control"required/><br>
                                                    </div>
                                                
                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">N° et lieu de déclaration</label>
                                                    <input type="text" name="N_et_lieu_declaration" id="N_et_lieu_declaration" 
                                                    placeholder="Tapez numéro et lieu de déclaration:" 
                                                    class="form-control"required/><br>
                                                    </div>

                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">Nom antérieur</label>
                                                    <input type="text" name="nom_anterieur" id="nom_anterieur" 
                                                    placeholder="Tapez nom antérieur :" 
                                                    class="form-control"required/><br>
                                                    </div>

                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">:الاسم العائلي السابق (بالعربية) </label>
                                                    <input type="text" name="nom_antarabeN" id="nom_antarabeN" 
                                                    placeholder=" :(أدخل الاسم العائلي السابق (بالعربية " 
                                                    class="form-control"required/><br>
                                                    </div>

                                                     
                                                    <div class="form-group">
                                                    <label for="nomD">Nom de famille confirmer </label>
                                                    <input type="text" name="nom_famille_confirme" id="nom_famille_confirme"
                                                    placeholder="Tapez le nom de famille confirmer " 
                                                    class="form-control"required/><br>
                                                    </div>

                                                     
                                                    <div class="form-group">
                                                    <label for="nomD"> :نفس اسم العائلة المصحح أو المقترح (بالعربية)</label>
                                                    <input type="text" name="nom_famille_confirmeN" id="nom_famille_confirmeN"
                                                    placeholder=" أدخل نفس اسم العائلة المصحح أو المقترح" 
                                                    class="form-control"required/><br>
                                                    </div>

                                                     
                                                    <div class="form-group">
                                                    <label for="nomD">Prénom de pére :</label>
                                                    <input type="text" name="prenom_pere" id="prenom_pere" 
                                                    placeholder=" Tapez le prenom du pére du bébé et le prénom du grand-pére " 
                                                    class="form-control"required/><br>
                                                    </div>

                                                    <div class="form-group">
                                                    <label for="nomD">:(اسم الأب ( بالعربية</label>
                                                    <input type="text" name="prparabeN" id="prparabeN" 
                                                    placeholder=" :(أدخل اسم أب المولود(ة) و اسم الجد (بالعربية "  
                                                    class="form-control"required/><br>
                                                    </div>

                                                    <div class="form-group">
                                                    <label for="nomD">Prénom de mére :</label>
                                                    <input type="text" name="prenom_mere" id="prenom_mere"
                                                    placeholder=" Tapez le prenom et le nom  du mére du bébé et le prénom du grand-pére " 
                                                    class="form-control"required/><br>
                                                    </div>

                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">:(اسم الأم ( بالعربية</label>
                                                    <input type="text" name="prmarabeN" id="prmarabeN"
                                                    placeholder="  :(أدخل اسم و لقب أم المولود(ة) و اسم الجد (بالعربية "  
                                                    class="form-control"required/><br>
                                                    </div>

                                                    <div class="form-group">
                                                    <label for="nomD">Date d'acte :</label>
                                                    <input type="text" name="date_acte" id="date_acte"
                                                    placeholder="tapez la date d'acte de naissance" 
                                                    class="form-control"required/><br>
                                                    </div>
                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">CIN (carte national) :</label>
                                                    <input type="text" name="cin" id="cin"
                                                    placeholder="Tapez la carte national (CIN) s'il existe : " 
                                                    class="form-control"required/><br>
                                                    </div>
                                                    

                                                    <div class="form-group">
                                                    <label for="nomD">مقر سكن الوالدين</label>
                                                    <input type="text" name="adress"  id="adress" 
                                                    placeholder="أدخل مقر سكن الوالدين  " 
                                                    class="form-control"required/><br>
                                                    </div>
                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">Nom de déclarant(e):</label>
                                                    <input type="text" name="declarant"  id="declarant" 
                                                    placeholder="Tapez le nom de déclarant(e) : " 
                                                    class="form-control"required/><br>
                                                    </div>
                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">Date de naissance de déclarant(e) :سنة  ازدياد  المعلن</label>
                                                    <input type="text" name="Nedeclarant"  id="Nedeclarant" 
                                                    placeholder="أدخل سنة  ازدياد  المعلن الميلادية " 
                                                    class="form-control"required/><br>
                                                    </div>
                                                    <div class="form-group">
                                                    <label for="nomD">:الموافق ل </label>
                                                    <input type="text" name="NedeclarantAr" id="NedeclarantAr" 
                                                    placeholder=" أدخل سنة  ازدياد  المعلن الهجرية " 
                                                    class="form-control"required/><br>
                                                    </div>
                                                    <div class="form-group">
                                                    <label for="nomD">:مقر سكن المعلن عن الولادة</label>
                                                    <input type="text" name="adressdeclarant"  id="adressdeclarant" 
                                                    placeholder="أدخل مقر سكن المعلن عن الولادة " 
                                                    class="form-control"required/><br>
                                                    </div>
                                                
                                                                  <button type="submit" class="btn btn-success">

                                                                <span class="glyphicon glyphicon-save"></span> 
                                                                    Enregistrer
                                                        </button>



                                            </form>

                                            
                                      
                                </div>
                    </div>
                </div>  

    </body>
</html>