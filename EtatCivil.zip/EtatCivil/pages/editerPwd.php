<?php
require_once('identifier.php');
?>

<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
    <meta charset="utf-8"/>
    <title>Changement de mot de passe</title>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
    <link rel="stylesheet" type="text/css" href="../css/champ.css">

    <script src="../js/jquery-3.3.1.js"></script>
    <script src="../js/monjs.js"></script>
</head>
<body  style="background-image: url('../images/zh1.jpg')"; >
<?php include("menu.php"); ?>


<div class="container editpwd">
<br><br><br><br><br><br><br>
    <h1 style="  color: #000;  font-size: 45px;" class="text-center">Changement de mot de passe</h1>

    <h2 style="  color: #000;   font-size: 40px; font-weight: bold;" class="text-center"> Compte :<?php echo $_SESSION['user']['login1'] ?>    </h2>

    <form style=" width: 400px; margin: auto;" class="form-horizontal" method="post" action="updatePwd.php">


        <!-- ****--*-*--******** Début Ancien mot de passe  ****--*-*--******** -->
        <div class="input-container "     >
            <input class="form-control oldpwd"
            style="margin-bottom: 20px;"
                   type="password"
                   name="oldpwd"
                   autocomplete="new-password"
                   placeholder="Taper votre Ancien Mot de passe"
                   required>
            <i class="fa fa-eye fa-2x show-old-pwd clickable"></i>
        </div>



        <!--  ****--*-*--********Début Nouveau  mot de passe !!!!  ****--*-*--******** -->

        <div class="input-container">
            <input minlength=4
                    class="form-control newpwd"
                    style="margin-bottom: 20px;"
                    type="password"
                    name="newpwd"
                    autocomplete="new-password"
                    placeholder="Taper votre Nouveau Mot de passe"
                    required>
            <i style=" position: absolute;  top: 0px; right: -35px;" class="fa fa-eye fa-2x show-new-pwd clickable"></i>

        </div>
        <!--  ****--*-*--********  Fin Nouveau  mot de passe   ****--*-*--******** -->

        <!--  ****--*-*--******** start submit field  ****--*-*--******** -->

        <input
                type="submit"
                value="Enregistrer"
                class="btn btn-primary btn-block"/>

        <!--   ***************** end submit field  ***************** -->

    </form>
</div>

</body>
</html>



