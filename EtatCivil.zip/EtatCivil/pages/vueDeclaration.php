<?php
         require_once('identifier.php');
         require_once("connexiondb.php");
              
              $size= isset($_GET['size'])?$_GET['size']:5;
              $page=isset($_GET['page'])?$_GET['page']:1 ;
              $offset=($page-1)*$size;

              $idd=isset($_GET['idD'])?$_GET['idD']:0;
              $requete="select * from declares where idDeclaration=$idd";
              
              $resultat=$pdo->query($requete);
              $declares=$resultat->fetch();
              $nom=strtoupper($declares['nom']);
              $prenom=strtoupper($declares['prenom']);
              $date=$declares['date'];
              $ville=strtoupper($declares['ville']);
              $carte=strtoupper($declares['carteN']);
              $adress=strtoupper($declares['adress']);
              $tele_email=$declares['tele_email'];
              $prp=strtoupper($declares['prp']);
              $prm=isset($_GET['prm'])?$_GET['prm']:"";
              $nomd=isset($_GET['nomD'])?$_GET['nomD']:"all";
              $num=isset($_GET['num'])?$_GET['num']:"";
             
       if($nomd=="all")
       {
              $requete="select * from declares
              where num like '%$num%'
              limit $size offset $offset ";

              $requeteCount="select count(*) countD from declares
              where num like '%$num%'";

      }
      else{
              $requete="select * from declares
              where  num like '%$num%' 
              and typeDeclaration='$nomd'
              
              limit $size  offset $offset ";

              $requeteCount="select count(*) countD from declares
              where num like '%$num%'
              and typeDeclaration='$nomd'
              ";
       }
              $resultatD=$pdo->query($requete);
              $resultatCount=$pdo->query($requeteCount);
              $tabCount=$resultatCount->fetch();
              $nbrDeclaration=$tabCount['countD'];
              $reste=$nbrDeclaration % $size;

              if($reste===0)
                     $nbrPage=$nbrDeclaration/$size;
              else
                     $nbrPage=floor($nbrDeclaration/$size) + 1;

       
?>

<!DOCTYPE HTML>
<html>
       <head>
              <meta charset="utf-8">
              <title>Acte de déclaration</title>
              <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
              <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
              <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
              <meta name="viewport" content="width=device-width, initial-scale=1">
              <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
              <link rel="stylesheet" href="print.css" >

              <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

       </head>
       <body style="background-image: url('../images/etat1.jpg')";>
       <?php include("menu.php");?><br><br>      
       <div style="width:85%;" class="container ">
             <div class="panel panel-primary margetop">
        <div class="panel-heading" align="center">Déclaration de : <b>(<?php echo $declares['typeDeclaration'] ?> )</b></div>
                           <div align="center"> <img src="../images/kingdom.jpg" alt="kingdom"></div>
             
                  <div class="panel-body">
                     <table class="table table-striped table-bordered">
                   
            
                   
                                   N° de déclaration  : <b><?php echo $declares['num'] ?> </b><br><br>
                                 Type de déclaration  :<?php echo $declares['typeDeclaration'] ?> <br><br>
                                 Nom  : <?php echo $declares['nom'] ?><br><br>
                                       
                    
                                   <div align="right"> 
                                       الاسم العائلي :  <b><?php echo $declares['nomarabe'] ?> </b><br><br>
                                     </div>
                                      Prénom  :  <b><?php echo $declares['prenom'] ?> </b><br><br>  
                                      <div align="right"> 
                                      الاسم الشخصيي: <b><?php echo $declares['prenomarabe'] ?></b><br><br>
                                   </div>

                                 carte nationale : <b><?php echo $declares['carteN'] ?></b> <br><br>
                                 Date de naissance :  <b><?php echo $declares['date'] ?> </b><br><br>
                                 Ville de naissance  :  <b><?php echo $declares['ville'] ?> </b><br><br>
                                 Adress  :  <b><?php echo $declares['adress'] ?> </b><br><br>
                                 Numéro de téléphone ou email  :  <b><?php echo $declares['tele_email'] ?> </b><br><br>
                                 Prénom de pére  :  <b><?php echo $declares['prp'] ?> </b><br><br>
                                 <div align="right"> 
                                         اسم الأب:  <b><?php echo $declares['prparabe'] ?> </b><br><br>
                                   </div>

                                 Prénom de pére  :  <b><?php echo $declares['prm'] ?> </b><br><br>

                                 <div align="right"> 
                                         اسم الأم :  <b><?php echo $declares['prmarabe'] ?> </b><br><br>
                                
                                         </div>
                            <div><br><br>

                            <div align="right">
                                   <b> Date    </b>
                            </div>
                            <div>
                                   <b>Signature </b>
                            </div>
                            </div><br><br><br>
                            
                            <i class="fa fa-scissors" style="font-size:36px;">---------------------------------------------<br><br>
                            </i><br>
                                              
                            N° de déclaration   <b><?php echo $declares['num'] ?> </b><br><br>
                                 Type de déclaration  : <b><?php echo $declares['typeDeclaration'] ?>  </b><br><br>
                                 Nom  :  <b><?php echo $declares['nom'] ?> </b><br><br>
                                       
                    
                                   <div align="right"> 
                                       الاسم العائلي :  <b><?php echo $declares['nomarabe'] ?> </b><br><br>
                                     </div>
                                      Prénom  :  <b><?php echo $declares['prenom'] ?> </b><br><br>  
                                      <div align="right"> 
                                      الاسم الشخصيي:  <b><?php echo $declares['prenomarabe'] ?> </b><br><br>
                                   </div>

                                 carte nationale :  <b><?php echo $declares['carteN'] ?>  </b><br><br><br><br> 
                                                 
                                    
                            
                     </table>

                                          
                 </div>
         </div>  
</div>  
                         <div align="center">                           
                            <button  type="submit" class="btn btn-success" onclick="window.print();" classe="btn btn primary" id="print-btn" >

                                          <span href="vueDeclaration.php"> <i class="material-icons">&#xe8ad;</i>
                                          <b>Imprimer </b>
                                          </span> 
                            
                            </button>
                                     </div> <br><br><br>
                                   
</body>
</html>