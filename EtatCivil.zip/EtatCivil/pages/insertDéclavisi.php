<?php

    require_once('connexiondb.php');

    $nom=strtoupper(isset($_POST['nom'])?$_POST['nom']:"");
    $prenom=strtoupper(isset($_POST['prenom'])?$_POST['prenom']:"");
    $nomarabe=isset($_POST['nomarabe'])?$_POST['nomarabe']:"";
    $prenomarabe=isset($_POST['prenomarabe'])?$_POST['prenomarabe']:"";
    $date=isset($_POST['date'])?$_POST['date']:"";
    $ville=strtoupper(isset($_POST['ville'])?$_POST['ville']:"");
    
    $carte=strtoupper(isset($_POST['carteN'])?$_POST['carteN']:"");
    
    $adress=strtoupper(isset($_POST['adress'])?$_POST['adress']:"");
    $tele_email=isset($_POST['tele_email'])?$_POST['tele_email']:"";
    $prp=strtoupper(isset($_POST['prp'])?$_POST['prp']:"");
    $prm=strtoupper(isset($_POST['prm'])?$_POST['prm']:"");
    $prparabe=isset($_POST['prparabe'])?$_POST['prparabe']:"";
    $prmarabe=isset($_POST['prmarabe'])?$_POST['prmarabe']:"";


    $requete="insert into declares(nom,prenom,nomarabe,prenomarabe,date,carteN,ville,adress,tele_email,prp,prparabe,prm,prmarabe) values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
    $params=array($nom,$prenom,$nomarabe,$prenomarabe,$date,$ville,$carte,$adress,$tele_email,$prp,$prparabe,$prm,$prmarabe);
    $resultatD=$pdo->prepare($requete);
    $resultatD->execute($params);

    header('location:Vdeclar.php');


?>