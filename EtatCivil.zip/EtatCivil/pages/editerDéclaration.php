<?php


require_once('connexiondb.php');

$idd=isset($_GET['idD'])?$_GET['idD']:0;
$requete="select * from declares where idDeclaration=$idd";

$resultat=$pdo->query($requete);
$declares=$resultat->fetch();
$nom=strtoupper($declares['nom']);
$prenom=strtoupper($declares['prenom']);
$nomarabe=strtoupper($declares['nomarabe']);
$prenomarabe=strtoupper($declares['prenomarabe']);
$date=$declares['date'];
$ville=strtoupper($declares['ville']);
$carte=strtoupper($declares['carteN']);
$adress=strtoupper($declares['adress']);
$tele_email=$declares['tele_email'];
$prp=strtoupper($declares['prp']);
$prm=strtoupper($declares['prm']);
$prparabe=($declares['prparabe']);
$prmarabe=($declares['prmarabe']);
$nomd=$declares['typeDeclaration'];
$num =strtoupper($declares['num']);
?>
<!DOCTYPE HTML>
<html>
        <head>
            <meta charset="utf-8">
                    <title>Edition d'une déclaration</title>
                    <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
                    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
                    <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
                    <link rel="stylesheet" type="text/css" href="../css/champ.css">

       </head>
    <body>
        <?php include("menu.php");?>
                <div class=" container"> 


                    <div class="panel panel-danger margetop">
                          
                            <div class="panel-heading">Edition de la déclaration:</div>
                               
                                <div class="panel-body">
                                        <form method="post" action="updateDéclaration.php" class="form">
                                            
                                                <div class="form-group">

                                                    <label for="nomD"> Id de déclaration : <?php  echo $idd  ?></label>
                                                    <input type="hidden" name="idD" 
                                                    class="form-control" 
                                                    value="<?php  echo $idd  ?>"required><br>

                                                </div>    
                                                    <div class="form-group">
                                                    <label for="nomD">Numéro de déclaration :</label>
                                                    <input type="text" name="num" 
                                                    placeholder="Numéro de déclaration" 
                                                    class="form-control"
                                                    value="<?php  echo $num  ?>"required/><br>

                                                    </div>    
                                                    <div class="form-group">
                                                    <label for="nomD">Nom:</label>   
                                                    <input type="text" name="nom" 
                                                    placeholder="Nom " 
                                                    class="form-control"
                                                    value="<?php  echo $nom  ?>"required/> <br>
                                                    </div>    

                                                    <div class="form-group">
                                                    <label for="nomD">Prénom:</label>
                                                    <input type="text" name="prenom" 
                                                    placeholder="Prénom" 
                                                    class="form-control"
                                                    value="<?php  echo $prenom  ?>"required/><br>
                                                    </div>    

                                                    <div class="form-group">
                                                    <label for="nomD">(الاسم العائلي (بالعربية</label>
                                                <input type="text" name="nomarabe" 
                                                placeholder="الاسم العائلي" 
                                                class="form-control"
                                                value="<?php  echo $nomarabe  ?>"required/><br>
                                                </div>

                                                <div class="form-group">

                                                <label for="nomD">(الاسم الشخصيي (بالعربية</label>
                                                <input type="text" name="prenomarabe" 
                                                placeholder="الاسم الشخصيي" 
                                                class="form-control"
                                                value="<?php  echo $prenomarabe  ?>"required/><br>
                                                </div>


                                                    <div class="form-group">
                                                    <label for="nomD">Date de naissance: </label>
                                                    <input type="date" name="date" 
                                                    placeholder="Date naissance" 
                                                    class="form-control"
                                                    value="<?php  echo $date  ?>"required/><br>
                                                    </div>    
                                                    <div class="form-group">
                                                    <label for="nomD">Ville de naissance:</label>
                                                    <input type="text" name="ville" 
                                                    placeholder="Ville" 
                                                    class="form-control"
                                                    value="<?php  echo $ville  ?>"required/><br>
                                                    </div>    
                                                    <div class="form-group">
                                                    <label for="nomD">Carte national</label>
                                                    <input type="text" name="carteN" 
                                                    placeholder="carteN" 
                                                    class="form-control"
                                                    value="<?php  echo $carte  ?>"required/><br>
                                                    </div>    
                                                    <div class="form-group">
                                                    <label for="nomD">Adress:</label>
                                                    <input type="text" name="adress" 
                                                    placeholder="Adress actuel" 
                                                    class="form-control"
                                                    value="<?php  echo $adress  ?>"required/><br>
                                                    </div>    
                                                    <div class="form-group">
                                                    <label for="nomD">N° de téléphone ou email:</label>
                                                    <input type="text" name="tele_email" 
                                                    placeholder="télé/eamil" 
                                                    class="form-control"
                                                    value="<?php  echo $tele_email  ?>"required/><br>
                                                    </div>    
                                                    <div class="form-group">
                                                    <label for="nomD">Prénom de pére:</label>
                                                    <input type="text" name="prp" 
                                                    placeholder="Prénom de pére" 
                                                    class="form-control"
                                                    value="<?php  echo $prp  ?>"required/><br>
                                                    </div>

                                                    
                                                    <div class="form-group">

                                                <label for="nomD"> (اسم الأب (بالعربية</label>
                                                <input type="text" name="prparabe" 
                                                placeholder="الاسم الأب" 
                                                class="form-control"
                                                value="<?php  echo $prparabe  ?>"required/><br>
                                                </div>

                                                    <div class="form-group">
                                                    <label for="nomD">Prénom de mére:</label>
                                                    <input type="text" name="prm" 
                                                    placeholder="Prénom de mére" 
                                                    class="form-control"
                                                    value="<?php  echo $prm  ?>"required/><br>
                                                    </div>

                                                    <div class="form-group">
                                                    <label  for="nomD"> (اسم الأم (بالعربية</label>
                                                <input  type="text" name="prmarabe" 
                                                placeholder="الاسم الأم" 
                                                class="form-control"
                                                value="<?php  echo $prmarabe  ?>"required/><br>
                                                </div>

                                                    

                                                

                                                <div class="form-group">
                                                        <label for="nomD" >Type de déclaration :</label>  

                                                                <select name="nomD" class="form-control" id="nomD" required>
                                                                
                                                                        <option value="DN"  <?php  if($nomd=="DN")   echo "selected" ?>> DN( Declaration de naissance normale )</option>
                                                                        <option value="DNC" <?php  if($nomd=="DNC")  echo "selected" ?>> DNC( Declaration de naissance cas voyage )</option>
                                                                        <option value="DNE" <?php  if($nomd=="DNE")  echo "selected" ?>> DNE( Declaration de naissance d"enfant abandonné )</option>
                                                                        <option value="DD"  <?php  if($nomd=="DD")   echo "selected" ?>> DD( Declaration de décées normale )</option>
                                                                        <option value="DDA" <?php  if($nomd=="DDA")  echo "selected" ?>> DDA( Declaration de décés anormales )</option>
                                                                </select><br>
                                                </div>
                                                        <button onclick="return confirm('Voulez-vous enregistrer les modificatios')" type="submit" class="btn btn-success">

                                                                <span class="glyphicon glyphicon-save"></span>
                                                                         Enregistrer
                                                        </button>

                                            </form>

                                            
                                </div>
                    </div>
                </div>  

    </body>
</html>