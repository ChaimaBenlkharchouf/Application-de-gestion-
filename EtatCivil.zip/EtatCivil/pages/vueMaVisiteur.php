<?php
         require_once("connexiondb.php");
              
              $size= isset($_GET['size'])?$_GET['size']:5;
              $page=isset($_GET['page'])?$_GET['page']:1 ;
              $offset=($page-1)*$size;

              $idd=isset($_GET['idD'])?$_GET['idD']:0;
              $requete="select * from mariage where idMar=$idd";
                            $nomd=isset($_GET['nomD'])?$_GET['nomD']:"all";
                            $idd=isset($_GET['idD'])?$_GET['idD']:0;
                            $requete="select * from mariage where idMar=$idd";
                            
                            $resultat=$pdo->query($requete);
                            $deces=$resultat->fetch();
                       
$numMAH=strtoupper($deces['numMAH']);
$dateM=strtoupper($deces['dateM']);
$numdossier=strtoupper($deces['numdossier']);
$time=strtoupper($deces['time']);
$dateMam=strtoupper($deces['dateMam']);
$dateMah=strtoupper($deces['dateMah']);
$nomadl1=strtoupper($deces['nomadl1']);
$nomadl2=strtoupper($deces['nomadl2']);
$page=strtoupper($deces['page']);
$numero=$deces['numero'];
$wasl=strtoupper($deces['wasl']);
$nomh=strtoupper($deces['nomh']);
$prenomh=strtoupper($deces['prenomh']);
$dateNeh=strtoupper($deces['dateNeh']);
$villeh=strtoupper($deces['villeh']);
$prph=strtoupper($deces['prph']);
$mereh =strtoupper($deces['mereh']);
$nationalh =strtoupper($deces['nationalh']);
$travailh =strtoupper($deces['travailh']);
$habiteh =strtoupper($deces['habiteh']);
$cinh =strtoupper($deces['cinh']);
$etath =strtoupper($deces['etath']);
$nomf =strtoupper($deces['nomf']);
$prenomf =strtoupper($deces['prenomf']);
$dateNef =strtoupper($deces['dateNef']);
$villef =strtoupper($deces['villef']);
$prpf =strtoupper($deces['prpf']);
$cinprpf =strtoupper($deces['cinprpf']);
$neprpf =strtoupper($deces['neprpf']);
$nationalprpf =strtoupper($deces['nationalprpf']);
$travailprpf =strtoupper($deces['travailprpf']);
$meref =strtoupper($deces['meref']);
$nationalf =strtoupper($deces['nationalf']);
$travailf =strtoupper($deces['travailf']);
$habitef =strtoupper($deces['habitef']);
$cinf =strtoupper($deces['cinf']);
$etatf =strtoupper($deces['etatf']);
$prix =strtoupper($deces['prix']);
$date_acteM =strtoupper($deces['date_acteM']);
$date_acteH =strtoupper($deces['date_acteH']);



             

if($nomd=="all")
{
       
       $requete="select * from mariage
       where (nomh like '%$nomh%' or nomf like '%$nomh%'
    
       or numdossier like '%$nomh%' or cinf like '%$nomh%'
       or cinh like '%$nomh%')
       limit $size offset $offset ";

       $requeteCount="select count(*) countD from mariage
       where (nomh like '%$nomh%' or nomf like '%$nomh%'
       or cinh like '%$nomh%' or cinf like '%$nomh%'
       or numdossier like '%$nomh%')";

}
else{
       $requete="select * from mariage
       where nomh like '%$nomh%'and (nomf like '%$nomh%')
       and numdossier like '%$nomh%'
       and cinh like '%$nomh%' and cinf like '%$nomh%'
       and page='$nomd' 
       
       limit $size  offset $offset ";

       $requeteCount="select count(*) countD mariage
       where (nomh like '%$nomh%' or nomf like '%$nomh%'
       or cinh like '%$nomh%' or cinf like '%$nomh%'
       or numdossier like '%$nomh%')
     

       and page='$nomd' ";

}
       $resultat=$pdo->query($requete);
       $resultatCount=$pdo->query($requeteCount);
       $tabCount=$resultatCount->fetch();
       $nbrNaissance=$tabCount['countD'];
       $reste=$nbrNaissance % $size;

       if($reste===0)
              $nbrPage=$nbrNaissance/$size;
       else
              $nbrPage=floor($nbrNaissance/$size) + 1;


                     
       
?>

<!DOCTYPE HTML>
<html>
       <head>
              <meta charset="utf-8">
              <title>عقد الزواج/Acte de mariage </title>
              <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
              <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
              <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
              <meta name="viewport" content="width=device-width, initial-scale=1">
              <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
              <link rel="stylesheet" href="print.css" >

              <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


                <STYle>
                DIV.double {
                    border-style: double;
                    border-radius: 20px;
                }
                pre.arb{
                  background: white ;
                }
             
                </STYle>
            
       </head>
       <body  style="background-image: url('../images/zh1.jpg')"; >


       <?php include("menu2.php");?><br><br>      
       <div style="width:85%;" class="container ">
             <div class="panel panel-primary margetop">
        <div class="panel-heading" align="center"> نسخة موجزة من  عقد النكاح </div><strong>
        <pre> 
          <div align="center"><b><i> المملكة المغربية </div>                               <div align="right">بسم الله الرحمان الرحيم  </div>  
          <div align="center"><b><i>وزارة العدل المحكمة لابتدائية </div>                  <div align="right">مكتب السعادة رقم 33م  </div>   
          <div align="center"><b><i>قسم التوثيق بالجديدة  </div>                          <div align="right"><b>  وصل عدد بتاريخ </i> </div> 
                                                                                             <div align="center"><b><u>  عقد النكاح</u></b>  </div> 



الحمد لله رب العالمين والصلاة والسلام على سيدنا محمد النبي 
الأمين وعلى آله وصحبه وسلم تسليما وبعد: فبعد إذن قاضي الأسرة
المكلف بالزواج بقسم قضاءالأسرة بالمحكمة الابتدائية بالجديدة
رقم<?php echo $deces['numMAH'] ?>   في  <?php echo $deces['dateM'] ?> م ملف مستندات الزواج رقم  <?php echo $deces['wasl'] ?>/ <?php echo $deces['numdossier'] ?> 
وبعد صدور الإيجاب من الزوج والقبول من الزوجة وفي <?php echo $deces['time'] ?> ثاني عشر محرم سنة ثلاثين وأربعمائة وألف 
(<?php echo $deces['dateMah'] ?>هـ) موافق <?php echo $deces['dateMam'] ?>م
وثق العدلان <?php echo $deces['nomadl1'] ?> <?php echo $deces['nomadl2'] ?> المعينان للإشهاد والتوثيق بدائرة محكمة الاستئناف
  <?php echo $deces['wasl'] ?>بالجديدة قسم التوثيق عقد الزواج بمذكرة الحفظ للعدل الأول رقم <?php echo $deces['numero'] ?> صفحة <?php echo $deces['page'] ?>عدد
  وصل <?php echo $deces['wasl'] ?>/<?php echo $deces['wasl'] ?> نصه: تزوج على بركة الله تعالى
   وحسن توفيقه الجميل الشاب المهذب <?php echo $deces['nomh'] ?> <?php echo $deces['nationalh'] ?> <?php echo $deces['prenomh'] ?> 
   ولد في <?php echo $deces['dateNeh'] ?>م <?php echo $deces['villeh'] ?>  من والديه <?php echo $deces['prph'] ?> <?php echo $deces['mereh'] ?>
  جنسيته <?php echo $deces['nationalh'] ?> مهنته <?php echo $deces['travailh'] ?> سكناه <?php echo $deces['habiteh'] ?> 
  <?php echo $deces['cinh'] ?>بطاقته الوطنية رقم  
حالته <?php echo $deces['etath'] ?> حسب الإذن المذكور وبتصريحه أيضا زوجــه المباركة عليه إن شاء الله تعالى البنت الآنسة المصونة بكرم
   الله تعالى  المباركة عليه إن شاء الله تعالى البنت الآنسة المصونة بكرم الله تعالى
 <?php echo $deces['nomf'] ?> <?php echo $deces['prenomf'] ?> <?php echo $deces['nationalf'] ?>  ولدت في  <?php echo $deces['dateNef'] ?>
 من والديهــا  <?php echo $deces['prpf'] ?> و<?php echo $deces['meref'] ?> جنسيتها  <?php echo $deces['nationalf'] ?>
<?php echo $deces['travailf'] ?> سكناها <?php echo $deces['habitef'] ?> 
<?php echo $deces['cinf'] ?>بطاقتها الوطنية رقم
 حالتها <?php echo $deces['etatf'] ?>  حسب الإذن المذكور وبتصريحها أيضا الحل للنكاح الخالية من موانعه على صداق مبارك قدره ونهايته درهم<?php echo $deces['prix'] ?> 
  قبضت الزوجة ووليها جميع الصداق المسطور اعترافا تزوجها وفق الكتاب والسنة أنكحه إياها والدها السيد 
<?php echo $deces['prpf'] ?> ولد في <?php echo $deces['neprpf'] ?>م جنسيته <?php echo $deces['nationalprpf'] ?>  مهنته <?php echo $deces['travailprpf'] ?> 
<?php echo $deces['cinprpf'] ?>سكناه حيث ابنته أعلاه بطاقته الوطنية  رقم
 بإذنها ورضاها وتفويضها له على ذلك وقبله الزوج كقبول الزوجة وارتضاه وأمضاه والله يؤلف بينهما
ويوفقهما لما يحبه ويرضاه وقد أشعر الزوجان بمقتضيات الفصل التاسع والأربعين (49) من قانون مدونة الأسرة عرفوا قدره شهد به عليهم
 ووثقه وهم بأتمه وعرف بهم بما ذكر سالفا وحرر في <?php echo $deces['dateMah'] ?>هـ موافق <?php echo $deces['dateMam'] ?>م وأمضوا: إمضاء الزوج 
 إمضاء الزوجة إمضاء الولي إمضاء العدل الأول ثم إمضاءالعدل الثاني ثم خطاب قاضي التوثيق وإمضاؤه

 <br><br><br>

</strong> </div> </pre>
</div>  
</div></div> 
                         <div align="center"> 
                            <button  type="submit" class="btn btn-success" onclick="window.print();" classe="btn btn primary" id="print-btn" >
                                          <span href="vueDeclaration.php"> <i class="material-icons">&#xe8ad;</i>
                                          <b>Imprimer </b>
                                          </span> 
                            </button>
                                     </div> <br><br><br>
                                  
</body>
</html>