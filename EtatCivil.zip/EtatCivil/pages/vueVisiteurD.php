<?php
             
             require_once('identifier.php');

              require_once("connexiondb.php");

              $N_acte_d=isset($_GET['N_acte_d'])?$_GET['N_acte_d']:"";
              $nom_d=isset($_GET['nom_d'])?$_GET['nom_d']:"";
              $nom_darabe=isset($_GET['nom_darabe'])?$_GET['nom_darabe']:"";


              $nomd=isset($_GET['nomD'])?$_GET['nomD']:"all";
              

              $size= isset($_GET['size'])?$_GET['size']:5;
              $page=isset($_GET['page'])?$_GET['page']:1 ;
              $offset=($page-1)*$size;

       
       if($nomd=="all")
       {
              
              $requete="select * from deces
              where (nom_d like '%$N_acte_d%' or N_acte_d like '%$N_acte_d%'
              or nom_darabe like '%$N_acte_d%')
              limit $size offset $offset ";

              $requeteCount="select count(*) countD from deces
              where (nom_d like '%$N_acte_d%' or N_acte_d like '%$N_acte_d%'
              or nom_darabe like '%$N_acte_d%')";

      }
      else{
              $requete="select * from deces
              where nom_d like '%$nom_d%'and (N_acte_d like '%$N_acte_d%')
              and nom_darabe like '%$nom_darabe%'
            
              and idDeclaration='$nomd' 
              
              limit $size  offset $offset ";

              $requeteCount="select count(*) countD deces
              where  (nom_d like '%$N_acte_d%' or N_acte_d like '%$N_acte_d%'
              or nom_darabe like '%$N_acte_d%')
            

              and idDeclaration='$nomd' ";

       }
              $resultatD=$pdo->query($requete);
              $resultatCount=$pdo->query($requeteCount);
              $tabCount=$resultatCount->fetch();
              $nbrNaissance=$tabCount['countD'];
              $reste=$nbrNaissance % $size;

              if($reste===0)
                     $nbrPage=$nbrNaissance/$size;
              else
                     $nbrPage=floor($nbrNaissance/$size) + 1;

       
?>

<!DOCTYPE HTML>
<html>
       <head>
              <meta charset="utf-8">
              <title>Acte de  décées  </title>
              <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
              <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
              <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">

              <meta name="viewport" content="width=device-width, initial-scale=1">
              <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

              <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

       </head>
       <body  style="background-image: url('../images/zh1.jpg')";  >
      
       <?php include("menu2.php");?><br><br>      
       <br><br><br><br>

         <div  class="panel panel-danger">
 <?php if($deces=$resultatD->fetch()){ ?>
                <div   class="panel-heading"> Nom de personne: <?php echo $deces['nom_d'] ?> </div>
               
                <div    class="panel-body">
                     <table   class="table table-striped table-bordered">
                            <thead>
                                 <tr>
                           
                                 <th>N° d'acte</th>
                                 <th>Nom</th>
                            
                                 <th>Prénom</th>
                                
                                 <th>CIN</th>
                                 <th>Ville de naissance</th>
                               
                                 <th>Date de l'acte</th>
                               
                                 <th >   Action</th>
                         
                                 </tr>  
                            </thead>
                            <tbody>
                                  
                                    
                                        <tr>
                                            
                                            <td><?php echo $deces['N_acte_d']?></td>
                                            <td><?php echo $deces['nom_d'] ?>  </td>
                                            <td><?php echo $deces['prenom_d'] ?>  </td>
                                            <td><?php echo $deces['carte_national_d'] ?>  </td>
                                            <td><?php echo $deces['ville_d'] ?>  </td>  
                                            <td><?php echo $deces['date_acte_d'] ?>  </td>

                                           
                                             <td >
                                                        
                                                    <a  href="vueDeVisiteur.php?idD=<?php echo $deces['idDeces'] ?> "> 
                                                        <i >Clicket ICI pour Imprimer l'acte</i>
                                                    </a>
                                                    &nbsp;
                                                  

                                                    

                                              </td>
                                      
                                          </tr>
                                      <?php } ?>
                            
                                    
                            </tbody>
                     </table>


                 </div>
         </div>
</div>  

</body>
</html>

