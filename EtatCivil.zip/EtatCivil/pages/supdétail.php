
<?php
session_start();   
if(isset($_SESSION['user'])) {
   
    require_once('connexiondb.php');
    $idcnt=isset($_GET['idcnt'])?$_GET['idcnt']:0;

    $requete="delete from  contact where idcnt=?";
    $params=array($idcnt);
    $resultat=$pdo->prepare($requete);
    $resultat->execute($params);
    header('location:détail.php');
}else{
    header('location:login.php');

}
  ?>