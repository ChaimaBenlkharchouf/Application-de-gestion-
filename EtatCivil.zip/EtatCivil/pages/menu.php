
<?php require_once('identifier.php');
?>
<nav class="navbar navbar-inverse navbar-fixed-top">
    <div class="container-fluid">
        <div class ="navbar-header">
     
              <a href="../face/acceuil.php" class="navbar-brand">Etat Civil</a>
        </div>
        <ul class="nav navbar-nav">
            <li class="nav navbar-nav"><a href="naissance.php">Naissance</a>   </li>
            <li><a href="décés.php">Décés</a>   </li>
            <li><a href="mariage.php">Mariages</a>    </li>
            <li><a href="déclaration.php">Déclaration</a>    </li> 

            <?php if ($_SESSION['user']['role1']=='ADMIN')  { ?>  
            <li><a href="register.php">Register</a>     </li>
            <?php }?>
            <li><a href="../pages/calendr.php">Calendrier </a>   </li>
            <li><a href="détail.php">Message</a>     </li>
            <?php if ($_SESSION['user']['role1']=='ADMIN')  { ?>  
            <li><a href="utilisateur.php">Utilisateurs</a></li> 
            <?php }?>
            <li><a href="../../Absence/index.php">Absence des employées</a></li> 

        </ul>

        <ul class="nav navbar-nav navbar-right">
            <li><a href="editerUser.php?iduser=<?php echo $_SESSION['user']['iduser']  ?>"><i class="glyphicon glyphicon-user ">   <?php echo $_SESSION['user']['login1'] ?></i></a>   </li>
            <li><a href="seDeconnecter.php"><i class="glyphicon glyphicon-log-out "></i>&nbsp; Se deconnecter</a>    </li>
        </ul>

    </div>
</nav>