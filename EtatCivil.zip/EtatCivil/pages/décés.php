<?php
             
             require_once('identifier.php');

              require_once("connexiondb.php");

              $N_acte_d=isset($_GET['N_acte_d'])?$_GET['N_acte_d']:"";
              $nom_d=isset($_GET['nom_d'])?$_GET['nom_d']:"";
              $nom_darabe=isset($_GET['nom_darabe'])?$_GET['nom_darabe']:"";


              $nomd=isset($_GET['nomD'])?$_GET['nomD']:"all";
              

              $size= isset($_GET['size'])?$_GET['size']:5;
              $page=isset($_GET['page'])?$_GET['page']:1 ;
              $offset=($page-1)*$size;

       
       if($nomd=="all")
       {
              
              $requete="select * from deces
              where (nom_d like '%$N_acte_d%' or N_acte_d like '%$N_acte_d%'
              or nom_darabe like '%$N_acte_d%')
              limit $size offset $offset ";

              $requeteCount="select count(*) countD from deces
              where (nom_d like '%$N_acte_d%' or N_acte_d like '%$N_acte_d%'
              or nom_darabe like '%$N_acte_d%')";

      }
      else{
              $requete="select * from deces
              where nom_d like '%$nom_d%'and (N_acte_d like '%$N_acte_d%')
              and nom_darabe like '%$nom_darabe%'
            
              and idDeclaration='$nomd' 
              
              limit $size  offset $offset ";

              $requeteCount="select count(*) countD deces
              where  (nom_d like '%$N_acte_d%' or N_acte_d like '%$N_acte_d%'
              or nom_darabe like '%$N_acte_d%')
            

              and idDeclaration='$nomd' ";

       }
              $resultatD=$pdo->query($requete);
              $resultatCount=$pdo->query($requeteCount);
              $tabCount=$resultatCount->fetch();
              $nbrNaissance=$tabCount['countD'];
              $reste=$nbrNaissance % $size;

              if($reste===0)
                     $nbrPage=$nbrNaissance/$size;
              else
                     $nbrPage=floor($nbrNaissance/$size) + 1;

       
?>

<!DOCTYPE HTML>
<html>
       <head>
              <meta charset="utf-8">
              <title>Gestion des décées  </title>
              <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
              <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
              <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">

              <meta name="viewport" content="width=device-width, initial-scale=1">
              <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

              <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<style>
body{
       background-image: url('../images/zh1.jpg') ;
}
</style>
       </head>
       <body   >
      
       <?php include("menu.php");?>
      
       <div style="text-align:center;" class="container"> 

      
        <div  style="width:114%;" class="panel panel-success margetop">
                <div class="panel-heading">Rechercher des décées...</div>

                    <div class="panel-body">
                      <form method="get" action="décés.php"  class="form-inline">
                            

                             <div class="form-group">

                                   <input style="width:160%;"  type="text" name="N_acte_d"    
                                   placeholder="Chercher sur: N° d'acte/Nom/الاسم العائلي" 
                                   class="form-control"
                                   value="<?php  echo $N_acte_d;   ?>"

                                   onchange="this.form.submit()" />
                          
                           
                                            
                      
                                          <button type="submit" class="btn btn-success">
                                                 <span class="glyphicon glyphicon-search"></span> 
                                                        Chercher...
                                          </button>
                                          &nbsp;&nbsp;
                                          <?php if ($_SESSION['user']['role1']=='ADMIN')  { ?>

                                          <a href="nouvelleDeces.php">
                                                 <span class="glyphicon glyphicon-plus"></span>
                                                 Nouvelle décé(e)
                                          </a>   
                                          <?php  }?>
                                    </div>
                            </form>
                
                      </div>
              </div>

              

         <div style="width:114%;"  class="panel panel-danger">

                <div   class="panel-heading"> Nombre de personne: <?php echo $nbrNaissance;  ?> personnes </div>
               
                <div    class="panel-body">
                     <table   style="width:114%; " class="table table-striped table-bordered">
                            <thead>
                                 <tr>
                                 <th>Id Décée</th>
                                 <th>N° d'acte</th>
                                 <th>Nom</th>
                                 <th>الاسم العائلي</th>
                                 <th>Prénom</th>
                                 <th>الاسم الشخصي</th>
                                 <th>CIN</th>
                                 <th>Ville</th>
                                 <th>مكان الولادة</th>
                                 <th>Date de naissance</th>
                                 <th>تاريخ الولادة</th>
                                 <th>Corespondant au</th>
                                 <th>الموافق</th>
                                 <th>nationalité</th>
                                 <th>Travaille</th>
                                 <th>مهنته(ا)</th>
                                 
                                 <th>Date de l'acte</th>
                                 <?php if ($_SESSION['user']['role1']=='ADMIN')  { ?>
                                 <th >   Action</th>
                                 <?php }?>
                                 </tr>  
                            </thead>
                            <tbody>
                                  
                                     <?php while($deces=$resultatD->fetch()){ ?>
                                        <tr>
                                            
                                            <td><?php echo $deces['idDeces'] ?></td>
                                            <td><?php echo $deces['N_acte_d']?></td>
                                            <td><?php echo $deces['nom_d'] ?>  </td>
                                            <td><?php echo $deces['nom_darabe'] ?>  </td>
                                            <td><?php echo $deces['prenom_d'] ?>  </td>
                                            <td><?php echo $deces['prenom_darabe'] ?>  </td>                
                                            <td><?php echo $deces['carte_national_d'] ?>  </td>
                                            <td><?php echo $deces['ville_d'] ?>  </td>  
                                            <td><?php echo $deces['ville_darabe'] ?>  </td>
                                            <td><?php echo $deces['date_naissance_d'] ?>  </td>
                                            <td><?php echo $deces['datearabe'] ?>  </td>
                                            <td><?php echo $deces['coresp_d'] ?>  </td>
                                            <td><?php echo $deces['coresp_darabe'] ?>  </td>
                                            <td><?php echo $deces['national'] ?>  </td>
                                            <td><?php echo $deces['travail_d'] ?>  </td>
                                            <td><?php echo $deces['travail_dar'] ?>  </td>
                                            <td><?php echo $deces['date_acte_d'] ?>  </td>

                                            <?php if ($_SESSION['user']['role1']=='ADMIN')  { ?>
                                             <td style="width:100px">
                                                        
                                                    <a  href="vueDeces.php?idD=<?php echo $deces['idDeces'] ?> "> 
                                                        <i class="fa fa-eye" style="font-size:20px;color:gris"></i>
                                                    </a>
                                                    &nbsp;
                                                    <a href="editerDeces.php?idD=<?php echo $deces['idDeces'] ?> ">
                                                    <span class="glyphicon glyphicon-edit">
                                                         </span>
                                                        </a> 
                                                        &nbsp;
                                                    <a onclick="return confirm('Etes-vous sur de vouloir supprimer ce personne?')" 
                                                         href="supprimeDeces.php?idD=<?php echo $deces['idDeces'] ?> "> 
                                                         <span class="glyphicon glyphicon-trash"></span>
                                                        

                                                    </a>

                                                    

                                              </td>
                                              <?php }?>
                                          </tr>
                                      <?php } ?>
                            
                                    
                            </tbody>
                     </table>

                                          <div>
                                          
                                          <ul class="nav nav-pills">
                                          <?php for($i=1;$i<=$nbrPage;$i++){ ?>
                            <li class="<?php if($i==$page) echo 'active' ?>"> 
                                   <a href="décés.php?page=<?php echo $i;?>&N_acte_d=<?php echo $N_acte_d ?>&nom_d=<?php echo $nom_d ?>&nom_darabe=<?php echo $nom_darabe ?>">
                                          <?php echo $i; ?>
                                   </a> 
                            </li>
                                  <?php } ?>
                                          </ul>
                        </div>

                 </div>
         </div>
</div>  

</body>
</html>

