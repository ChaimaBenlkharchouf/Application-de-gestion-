<?php

require_once('identifier.php');
require_once("connexiondb.php");
              
              $size= isset($_GET['size'])?$_GET['size']:5;
              $page=isset($_GET['page'])?$_GET['page']:1 ;
              $offset=($page-1)*$size;

              $idd=isset($_GET['idD'])?$_GET['idD']:0;
              $requete="select * from naissance where idNaissance=$idd";
                            $nomd=isset($_GET['nomD'])?$_GET['nomD']:"all";
                            $idd=isset($_GET['idD'])?$_GET['idD']:0;
                            $requete="select * from naissance where idNaissance=$idd";
                            
                            $resultat=$pdo->query($requete);
                            $naissance=$resultat->fetch();
                            
                            $N_acte=strtoupper($naissance['N_acte']);
                            $nom=strtoupper($naissance['nom']);
                            $nomarabeN=strtoupper($naissance['nomarabeN']);
                            $prenom=strtoupper($naissance['prenom']);
                            $prenomarabeN=strtoupper($naissance['prenomarabeN']);
                            $villeN=strtoupper($naissance['villeN']);
                            $villearabeN=strtoupper($naissance['villearabeN']);
                            $date_naissance=($naissance['date_naissance']);
                            $datearabeN=strtoupper($naissance['datearabeN']);
                            $corespN=$naissance['corespN'];
                            $coresparabeN=strtoupper($naissance['coresparabeN']);
                            $N_et_lieu_declaration=strtoupper($naissance['N_et_lieu_declaration']);
                            $nom_anterieur=strtoupper($naissance['nom_anterieur']);
                            $nom_antarabeN=$naissance['nom_antarabeN'];
                            $nom_famille_confirme=$naissance['nom_famille_confirme'];
                            $nom_famille_confirmeN=$naissance['nom_famille_confirmeN'];
                            $prenom_pere =strtoupper($naissance['prenom_pere']);
                            $prparabeN =strtoupper($naissance['prparabeN']);
                            $prenom_mere =strtoupper($naissance['prenom_mere']);
                            $prmarabeN =strtoupper($naissance['prmarabeN']);
                            $date_acte =strtoupper($naissance['date_acte']);
                            $cin =strtoupper($naissance['cin']);
                            
$adress =strtoupper($naissance['adress']);
$declarant =strtoupper($naissance['declarant']);
$Nedeclarant =strtoupper($naissance['Nedeclarant']);
$NedeclarantAr =strtoupper($naissance['NedeclarantAr']);
$adressdeclarant =strtoupper($naissance['adressdeclarant']);
$adminEtat =strtoupper($naissance['adminEtat']);
$date_acteAr =strtoupper($naissance['date_acteAr']);
             
        
                            if($nomd=="all")
                            {
                                   
                                   $requete="select * from naissance
                                   where (nom like '%$N_acte%' or N_acte like '%$N_acte%'
                                
                                   or nomarabeN like '%$N_acte%')
                                   limit $size offset $offset ";
                     
                                   $requeteCount="select count(*) countD from naissance
                                   where (nom like '%$N_acte%' or N_acte like '%$N_acte%'
                                   
                                   or nomarabeN like '%$N_acte%')";
                     
                           }
                           else{
                                   $requete="select * from naissance
                                   where nom like '%$nom%'and (N_acte like '%$N_acte%')
                                   and nomarabeN like '%$nomarabeN%'
                                 
                                   and typeDeclaration='$nomd' 
                                   
                                   limit $size  offset $offset ";
                     
                                   $requeteCount="select count(*) countD naissance
                                   where (nom like '%$N_acte%' or N_acte like '%$N_acte%'
                     
                                   or nomarabeN like '%$N_acte%')
                                 
                     
                                   and typeDeclaration='$nomd' ";
                     
                            }
                                   $resultatD=$pdo->query($requete);
                                   $resultatCount=$pdo->query($requeteCount);
                                   $tabCount=$resultatCount->fetch();
                                   $nbrNaissance=$tabCount['countD'];
                                   $reste=$nbrNaissance % $size;
                     
                                   if($reste===0)
                                          $nbrPage=$nbrNaissance/$size;
                                   else
                                          $nbrPage=floor($nbrNaissance/$size) + 1;
                     
       
?>

<!DOCTYPE HTML>
<html>
       <head>
              <meta charset="utf-8">
              <title>Register pour les actes de naissnace </title>
              <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
              <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
              <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
              <meta name="viewport" content="width=device-width, initial-scale=1">
              <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
              <link rel="stylesheet" href="print.css" >

              <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


                <STYle>
                DIV.double {
                    border-style: double;
                    border-radius: 20px;
                }
                pre.arb{
                  background: white ;
                }
             
                </STYle>
            
       </head>
       <body  style="background-image: url('../images/etat1.jpg')"; >
       <?php include("menu.php");?><br><br>      


   
       <div style="width:85%;" class="container ">
             <div class="panel panel-primary margetop">
        <div class="panel-heading" align="center">نسخة موجزة من رسم الولادة</div>
         
                                                              <strong>               <div align="center">سجل الولادات  </div>
Commune : El jadida                                            مكتب الحالة المدني:  م1                                                    جماعة الجديدة
<div align="left">Acte n°  : <b><?php echo $naissance['N_acte'] ?> </b></div>                                                                                                               <div align="right">    <b><?php echo $naissance['N_acte'] ?> </b>    :رقم الرسم</div>
<div align="left">Année  : <b><?php echo $naissance['date_acte'] ?> </b></div>                                                                                                       <div align="right">   <b><?php echo $naissance['date_acte'] ?> </b>    :السنة</div>
<div align="left">Nom  : <?php echo $naissance['nom'] ?></div>                                                                                                                      <div align="right"> الاسم العائلي :<b><?php echo $naissance['nomarabeN'] ?> </div></b></b>
<div align="left">Prénom  :  <?php echo $naissance['prenom'] ?></div>                                                                                                                     <div align="right"> الاسم الشخصيي: <b><?php echo $naissance['prenomarabeN'] ?></div></b>
<div align="left">Né(é) le : <?php echo $naissance['date_naissance'] ?></div>                                                                                                                                  <div align="right">    تاريخ الولادة: <b><?php echo $naissance['datearabeN'] ?></div></b>
<div align="left">Corespondant au  :  <?php echo $naissance['corespN'] ?></div>                                                                                                                                <div align="right">      الموافق: <b><?php echo $naissance['coresparabeN'] ?></div></b>
<div align="left">Lieu de naissance  :  <?php echo $naissance['villeN'] ?></div>                                                                                                                               <div align="right">  مكان الولادة: <b><?php echo $naissance['villearabeN'] ?></div></b>
                                                                                                     <div align="right"> جنسيته: <b>مغريبي(ة)</b></div><br><br>
<div align="left">Fils ou fille de :  <?php echo $naissance['prenom_pere'] ?></div>                                                                                                                           <div align="right">   والده هو: <b><?php echo $naissance['prparabeN'] ?></div></b>
<div align="left">Et de :  <?php echo $naissance['prenom_mere'] ?></div>                                                                                                                       <div align="right">   <b><?php echo $naissance['prmarabeN'] ?> : والدتها هي </div></b>
                                                                                                                                                       <div align="right">    <b><?php echo $naissance['adress'] ?> </b>    :سكناهما</div>
<div align="left">Mention marginale de décés :  Néant</div>                                                                                                      <div align="right">   بيان (الوفاة) المشار اليه في طرة الرسم: <b>لا شيء</b></div>
    تحت عدد <?php echo $naissance['N_acte'] ?> <?php echo $naissance['Nedeclarant'] ?> ولد(ت)  <?php echo $naissance['declarant'] ?> بناءا على ماصرح(ت) به    
     سكناها  <?php echo $naissance['adressdeclarant'] ?>
<div align="right">    <?php echo $naissance['date_acte'] ?>  :في  </div>
<div align="right">   <?php echo $naissance['date_acteAr'] ?>  :الموافق  </div>
<div align="right"> من طرفنا نحن رئيس(ة) التحرير :<?php echo $naissance['adminEtat'] ?>  موظف(ة) جماعي(ة)    </div>

<div align="right"> بمطابقة هذه النسخة لما هو مضمن في سجلات الحالة المدنية بالمكتب المذكور </div>
<div align="left"> Extrait certifié conforme aux registres de l'état civil , par 
  nous le président et officier de l'état civil </div>

                                
                 </div>
         </div> 
         </strong> 
</div>   </div></div> 
                         <div align="center"> 
                            <button  type="submit" class="btn btn-success" onclick="window.print();" classe="btn btn primary" id="print-btn" >
                                          <span href="vueRne.php"> <i class="material-icons">&#xe8ad;</i>
                                          <b>Imprimer </b>
                                          </span> 
                            </button>
                                        
                                     
                                     <br><br><br>
                                  
</body>
</html>