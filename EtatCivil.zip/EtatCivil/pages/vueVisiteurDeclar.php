<?php
require_once("connexiondb.php");

              $nomd=isset($_GET['nomD'])?$_GET['nomD']:"all";
              $num=isset($_GET['num'])?$_GET['num']:"";

              $size= isset($_GET['size'])?$_GET['size']:5;
              $page=isset($_GET['page'])?$_GET['page']:1 ;
              $offset=($page-1)*$size;

       
       if($nomd=="all")
       {
              $requete="select * from declares
              where num like '%$num%'
              limit $size offset $offset ";

              $requeteCount="select count(*) countD from declares
              where num like '%$num%'";

      }
      else{
              $requete="select * from declares
              where  num like '%$num%' 
              and typeDeclaration='$nomd'
              
              limit $size  offset $offset ";

              $requeteCount="select count(*) countD from declares
              where num like '%$num%'
              and typeDeclaration='$nomd'
              ";
       }
              $resultatD=$pdo->query($requete);
              $resultatCount=$pdo->query($requeteCount);
              $tabCount=$resultatCount->fetch();
              $nbrDeclaration=$tabCount['countD'];
              $reste=$nbrDeclaration % $size;

              if($reste===0)
                     $nbrPage=$nbrDeclaration/$size;
              else
                     $nbrPage=floor($nbrDeclaration/$size) + 1;

       
?>

<!DOCTYPE HTML>
<html>
       <head>
              <meta charset="utf-8">
              <title>Acte de déclaration </title>
              <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
              <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
              <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">

              <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


       </head>
       <body  style="background-image: url('../images/zh1.jpg')"; >
      
       <?php include("menu2.php");?>      <br><br><br>
      <br><br><br><br>
      <br><br><br><br>
      <br><br>
         <div class="panel panel-danger ">
                 <?php if($declares=$resultatD->fetch()){ ?>
                <div class="panel-heading">Type de déclaration (<?php echo $declares['typeDeclaration'] ?>  ) </div>
                  <div class="panel-body">
                     <table class="table table-striped table-bordered">
                            <thead>
                                 <tr>
                               
                                 <th>Nom</th>
                                 <th>Prénom</th>
                                 <th>carte nationale</th>
                                 <th>Date de naissance</th>
                                 <th>Type de déclaration</th>
                                 <th>N° de déclaration</th>
                   
                                 <th>Action</th>
                        
                                 </tr>  
                            </thead>
                            <tbody>
                                  
                    
                                        <tr>
                                            
                                            <td><?php echo $declares['nom'] ?>  </td>
                                            <td><?php echo $declares['prenom'] ?>  </td>
                                            <td><?php echo $declares['carteN'] ?>  </td>
                                            <td><?php echo $declares['date'] ?>  </td>
                                            <td><?php echo $declares['typeDeclaration'] ?>  </td>
                                            <td><?php echo $declares['num'] ?>  </td>
                                            
                                             <td>
                                                        
                                                    <a  href="vueDeclarVisiteur.php?idD=<?php echo $declares['idDeclaration'] ?> "> 
                                                        <span >Clicket ICI pour Imprimer l'acte</span>
                                                    </a>
                                                

                                                    

                                              </td>
                                          
                                          </tr>
                                    
                            
                                    
                            </tbody>
                     </table>

                                         

                 </div>
         </div>
         <?php } ?>
</div>  

</body>
</html>