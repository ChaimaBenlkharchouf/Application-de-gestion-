<! DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<title>Page Blache</title>

<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../css/monstyle.css">
</head>
<body>
    <?php include("menu.php");?>
    <div class=" container"> 

      
<div class="panel panel-success margetop">
        <div class="panel-heading">Rechercher des déclaration...</div>
        <div class="panel-body">le contenu du panneau</div>
 </div>


 <div class="panel panel-danger ">
        <div class="panel-heading">Type de déclaration</div>
        <div class="panel-body">Tableau des déclaration</div>
 </div>
</div>  

</body>
</html>