<?php
    require_once('identifier.php');

    require_once('connexiondb.php');

    $numMAH=strtoupper(isset($_POST['numMAH'])?$_POST['numMAH']:"");
    $dateM=strtoupper(isset($_POST['dateM'])?$_POST['dateM']:"");
    $numdossier=isset($_POST['numdossier'])?$_POST['numdossier']:"";
    $time=isset($_POST['time'])?$_POST['time']:"";
    $dateMam=isset($_POST['dateMam'])?$_POST['dateMam']:"";
    $dateMah=strtoupper(isset($_POST['dateMah'])?$_POST['dateMah']:"");
    $nomadl1=strtoupper(isset($_POST['nomadl1'])?$_POST['nomadl1']:"");
    $nomadl2=strtoupper(isset($_POST['nomadl2'])?$_POST['nomadl2']:"");
    $page=isset($_POST['page'])?$_POST['page']:"";
    $numero=strtoupper(isset($_POST['numero'])?$_POST['numero']:"");
    $wasl=strtoupper(isset($_POST['wasl'])?$_POST['wasl']:"");
    $nomh=isset($_POST['nomh'])?$_POST['nomh']:"";
    $prenomh=isset($_POST['prenomh'])?$_POST['prenomh']:"";
    $dateNeh=isset($_POST['dateNeh'])?$_POST['dateNeh']:"";
    $villeh=isset($_POST['villeh'])?$_POST['villeh']:"";
    $prph=isset($_POST['prph'])?$_POST['prph']:"";
    $mereh=isset($_POST['mereh'])?$_POST['mereh']:"";
    $nationalh=isset($_POST['nationalh'])?$_POST['nationalh']:"";
    $travailh=isset($_POST['travailh'])?$_POST['travailh']:"";
    $habiteh=isset($_POST['habiteh'])?$_POST['habiteh']:"";
    $cinh=isset($_POST['cinh'])?$_POST['cinh']:"";
    $etath=isset($_POST['etath'])?$_POST['etath']:"";
    $nomf=isset($_POST['nomf'])?$_POST['nomf']:"";
    $prenomf=isset($_POST['prenomf'])?$_POST['prenomf']:"";
    $dateNef=isset($_POST['dateNef'])?$_POST['dateNef']:"";
    $villef=isset($_POST['villef'])?$_POST['villef']:"";
    $prpf=isset($_POST['prpf'])?$_POST['prpf']:"";
    $cinprpf=isset($_POST['cinprpf'])?$_POST['cinprpf']:"";
    $neprpf=isset($_POST['neprpf'])?$_POST['neprpf']:"";
    $nationalprpf=isset($_POST['nationalprpf'])?$_POST['nationalprpf']:"";
    $travailprpf=isset($_POST['travailprpf'])?$_POST['travailprpf']:"";
    $meref=isset($_POST['meref'])?$_POST['meref']:"";
    $nationalf=isset($_POST['nationalf'])?$_POST['nationalf']:"";
    $travailf=isset($_POST['travailf'])?$_POST['travailf']:"";
    $habitef=isset($_POST['habitef'])?$_POST['habitef']:"";
    $cinf=isset($_POST['cinf'])?$_POST['cinf']:"";
    $etatf=isset($_POST['etatf'])?$_POST['etatf']:"";
    $prix=isset($_POST['prix'])?$_POST['prix']:"";
    $date_acteM=isset($_POST['date_acteM'])?$_POST['date_acteM']:"";
    $date_acteH=isset($_POST['date_acteH'])?$_POST['date_acteH']:"";


    $nomPhoto=isset($_POST['photo'])?$_POST['photo']:"";
    $nomPhotof=isset($_POST['photof'])?$_POST['photof']:"";


    $requete="insert into mariage(numMAH, dateM, numdossier, time, dateMam, dateMah, nomadl1, nomadl2, page, numero, wasl, nomh, prenomh, dateNeh, villeh, prph,mereh, nationalh, travailh, habiteh, cinh, etath, nomf, prenomf, nationalf, dateNef, villef, travailf, habitef, cinf, etatf, prpf, meref, cinprpf, neprpf, nationalprpf, travailprpf,prix,photo,photof, date_acteM, date_acteH)  values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    $params=array($numMAH,$dateM, $numdossier, $time, $dateMam, $dateMah, $nomadl1, $nomadl2, $page, $numero, $wasl, $nomh, $prenomh, $dateNeh, $villeh, $prph,$mereh, $nationalh, $travailh, $habiteh, $cinh, $etath, $nomf, $prenomf, $nationalf, $dateNef, $villef, $travailf, $habitef, $cinf, $etatf, $prpf, $meref, $cinprpf, $neprpf, $nationalprpf, $travailprpf,$prix,$nomPhoto,$nomPhotof, $date_acteM, $date_acteH);
    $resultatD=$pdo->prepare($requete);
    $resultatD->execute($params);

    header('location:mariage.php');


?>