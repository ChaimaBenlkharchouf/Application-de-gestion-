<?php



require_once('connexiondb.php');

$idd=isset($_GET['idD'])?$_GET['idD']:0;
$requete="select * from naissance where idNaissance=$idd";

$resultat=$pdo->query($requete);
$naissance=$resultat->fetch();

$N_acte=strtoupper($naissance['N_acte']);
$nom=strtoupper($naissance['nom']);
$nomarabeN=strtoupper($naissance['nomarabeN']);
$prenom=strtoupper($naissance['prenom']);
$prenomarabeN=strtoupper($naissance['prenomarabeN']);
$villeN=strtoupper($naissance['villeN']);
$villearabeN=strtoupper($naissance['villearabeN']);
$date_naissance=($naissance['date_naissance']);
$datearabeN=strtoupper($naissance['datearabeN']);
$corespN=$naissance['corespN'];
$coresparabeN=strtoupper($naissance['coresparabeN']);
$N_et_lieu_declaration=strtoupper($naissance['N_et_lieu_declaration']);
$nom_anterieur=strtoupper($naissance['nom_anterieur']);
$nom_antarabeN=$naissance['nom_antarabeN'];
$nom_famille_confirme=$naissance['nom_famille_confirme'];
$nom_famille_confirmeN=$naissance['nom_famille_confirmeN'];
$prenom_pere =strtoupper($naissance['prenom_pere']);
$prparabeN =strtoupper($naissance['prparabeN']);
$prenom_mere =strtoupper($naissance['prenom_mere']);
$prmarabeN =strtoupper($naissance['prmarabeN']);
$date_acte =strtoupper($naissance['date_acte']);
$cin =strtoupper($naissance['cin']);
$adress =strtoupper($naissance['adress']);
$declarant =strtoupper($naissance['declarant']);
$Nedeclarant =strtoupper($naissance['Nedeclarant']);
$NedeclarantAr =strtoupper($naissance['NedeclarantAr']);
$adressdeclarant =strtoupper($naissance['adressdeclarant']);
$date_acteAr =strtoupper($naissance['date_acteAr']);

$adminEtat =strtoupper($naissance['adminEtat']);
?>



<!DOCTYPE HTML>
<html>
        <head>
            <meta charset="utf-8">
                    <title>nouvelle naissance</title>

                    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
                    <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
                    <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
                    <link rel="stylesheet" type="text/css" href="../css/champ.css">

       </head>
    <body>
        <?php include("menu.php");?>
                <div class=" container"> 


                    <div class="panel panel-danger margetop">
                          
                            <div class="panel-heading">Veuillea saisir les données de la nouvelle naissance</div>
                               
                                <div class="panel-body">
                                        <form method="post" action="updateNaissance.php" class="form">
                                            
                                        <div class="form-group">

                                                <label for="nomD"> Id de Naissance : <?php  echo $idd  ?></label>
                                                <input type="hidden" name="idD" 
                                                class="form-control" 
                                                value="<?php  echo $idd  ?>"required><br>

                                         </div>    

                                                <div class="form-group">

                                                    <label for="nomD">N° d'acte :</label>
                                                    <input type="text" name="N_acte" 
                                                    placeholder="Tapez numéro de déclaration" 
                                                    class="form-control"
                                                    value="<?php  echo $N_acte  ?>"required/><br>
                                                </div>

                                                
                                                    
                                                <div class="form-group" >
                                                    <label for="nomD">Nom:</label>   
                                                    <input type="text" name="nom" id="nom"
                                                    placeholder="tapez le nom " 
                                                    class="form-control"
                                                    value="<?php  echo $nom  ?>"required/> <br>
                                                    </div>
                                                    
                                                    <div class="form-group" >
                                                    <label for="nomD">:الاسم العائلي(بالعربية)</label>   
                                                    <input type="text" name="nomarabeN" id="nomarabeN" 
                                                    placeholder=" (أدخل الاسم العائلي المولود(ة"
                                                    class="form-control"
                                                    value="<?php  echo $nomarabeN  ?>"required/> <br>
                                                    </div>

                                                    <div class="form-group">
                                                    <label for="nomD">Prénom:</label>
                                                    <input type="text" name="prenom"  id="prenom"
                                                    placeholder="tapez le prénom" 
                                                    class="form-control"
                                                    value="<?php  echo $prenom  ?>"required/><br>
                                                    </div>
                                                    
                                                 

                                                <div class="form-group">

                                                    <label for="nomD">:(الاسم الشخصيي (بالعربية</label>
                                                    <input type="text" name="prenomarabeN" id="prenomarabeN" 
                                                    placeholder=" (أدخل الاسم الشخصيي المولود(ة" 
                                                    class="form-control"
                                                    value="<?php  echo $prenomarabeN  ?>"required/><br>
                                                </div>
                                                <div class="form-group">
                                                    <label for="nomD">Ville de naissance:</label>
                                                    <input type="text" name="villeN" id="villeN"
                                                    placeholder="Tapez la ville de naissance" 
                                                    class="form-control"
                                                    value="<?php  echo $villeN  ?>"required/><br>
                                                    </div>

                                                    
                                                <div class="form-group">
                                                    <label for="nomD"> : مكان الولادة</label>
                                                    <input type="text" name="villearabeN" id="villearabeN"
                                                    placeholder="Tapez la ville de naissance" 
                                                    class="form-control"
                                                    value="<?php  echo $villearabeN  ?>"required/><br>
                                                    </div>

                                                    <div class="form-group">
                                                    <label for="nomD">Date de naissance: </label>
                                                    <input type="date" name="date_naissance" id="date_naissance"
                                                    placeholder=" Tapez la date naissance" 
                                                    class="form-control"
                                                    value="<?php  echo $date_naissance  ?>"required/><br>
                                                    </div>
                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">:تاريخ الولادة </label>
                                                    <input type="text" name="datearabeN" id="datearabeN"
                                                    placeholder=" (أدخل تاريخ الولادة (ميلادية" 
                                                    class="form-control"
                                                    value="<?php  echo $datearabeN  ?>"required/><br>
                                                    </div>
                                                    
                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">Corespondant au</label>
                                                    <input type="date" name="corespN" id="corespN"
                                                    placeholder="Corespondant au (Hijri) :" 
                                                    class="form-control"
                                                    value="<?php  echo $corespN  ?>"required/><br>
                                                    </div>

                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">:الموافق ل</label>
                                                    <input type="text" name="coresparabeN" id="coresparabeN" 
                                                    placeholder="( الموافق ل (هجرية "
                                                    class="form-control"
                                                    value="<?php  echo $coresparabeN  ?>"required/><br>
                                                    </div>
                                                
                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">N° et lieu de déclaration</label>
                                                    <input type="text" name="N_et_lieu_declaration" id="N_et_lieu_declaration"
                                                    placeholder="Tapez numéro et lieu de déclaration:" 
                                                    class="form-control"
                                                    value="<?php  echo $N_et_lieu_declaration  ?>"required/><br>
                                                    </div>

                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">Nom antérieur</label>
                                                    <input type="text" name="nom_anterieur" id="nom_anterieur"
                                                    placeholder="Tapez nom antérieur :" 
                                                    class="form-control"
                                                    value="<?php  echo $nom_anterieur  ?>"required/><br>
                                                    </div>

                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">:الاسم العائلي السابق (بالعربية) </label>
                                                    <input type="text" name="nom_antarabeN" id="nom_antarabeN"
                                                    placeholder=" :(أدخل الاسم العائلي السابق (بالعربية " 
                                                    class="form-control"
                                                    value="<?php  echo $nom_antarabeN  ?>"required/><br>
                                                    </div>

                                                     
                                                    <div class="form-group">
                                                    <label for="nomD">Nom de famille comfirmer </label>
                                                    <input type="text" name="nom_famille_confirme" id="nom_famille_confirme" 
                                                    placeholder="Tapez le nom de famille confirmer " 
                                                    class="form-control"
                                                    value="<?php  echo $nom_famille_confirme  ?>"required/><br>
                                                    </div>

                                                     
                                                    <div class="form-group">
                                                    <label for="nomD"> :نفس اسم العائلة المصحح أو المقترح (بالعربية)</label>
                                                    <input type="text" name="nom_famille_confirmeN"  id="nom_famille_confirmeN" 
                                                    placeholder=" أدخل نفس اسم العائلة المصحح أو المقترح" 
                                                    class="form-control"
                                                    value="<?php  echo $nom_famille_confirmeN  ?>"required/><br>
                                                    </div>

                                                     
                                                    <div class="form-group">
                                                    <label for="nomD">Prénom de pére :</label>
                                                    <input type="text" name="prenom_pere" id="prenom_pere"
                                                    placeholder=" Tapez le prenom du pére du bébé et le prénom du grand-pére " 
                                                    class="form-control"
                                                    value="<?php  echo $prenom_pere  ?>"required/><br>
                                                    </div>

                                                    <div class="form-group">
                                                    <label for="nomD">:(اسم الأب ( بالعربية</label>
                                                    <input type="text" name="prparabeN" id="prparabeN" 
                                                    placeholder=" :(أدخل اسم أب المولود(ة) و اسم الجد (بالعربية "  
                                                    class="form-control"
                                                    value="<?php  echo $prparabeN  ?>"required/><br>
                                                    </div>

                                                    <div class="form-group">
                                                    <label for="nomD">Prénom de mére :</label>
                                                    <input type="text" name="prenom_mere" id="prenom_mere"
                                                    placeholder=" Tapez le prenom et le nom  du mére du bébé et le prénom du grand-pére " 
                                                    class="form-control"
                                                    value="<?php  echo $prenom_mere  ?>"required/><br>
                                                    </div>

                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">:(اسم الأم ( بالعربية</label>
                                                    <input type="text" name="prmarabeN" id="prmarabeN" 
                                                    placeholder="  :(أدخل اسم و لقب أم المولود(ة) و اسم الجد (بالعربية "  
                                                    class="form-control"
                                                    value="<?php  echo $prmarabeN  ?>"required/><br>
                                                    </div>



                                                    <div class="form-group">
                                                    <label for="nomD">Date d'acte :</label>
                                                    <input type="text" name="date_acte" id="date_acte" 
                                                    placeholder="tapez la date d'acte de naissance" 
                                                    class="form-control"
                                                    value="<?php  echo $date_acte  ?>"required/><br>
                                                    </div>
                                                    <div class="form-group">
                                                    <label for="nomD">: تاريخ تسجيل المولود(ة)</label>
                                                    <input type="text" name="date_acteAr" name="date_acteAr" 
                                                    placeholder=" (أدخل تاريخ تسجيل المولود(ة  " 
                                                    class="form-control"
                                                    value="<?php  echo $date_acteAr  ?>"required/><br>
                                                    </div>
                                                    <div class="form-group">
                                                    <label for="nomD">CIN (carte national) :</label>
                                                    <input type="text" name="tele_email" id="tele_email"
                                                    placeholder="Tapez la carte national (CIN) s'il existe : " 
                                                    class="form-control"
                                                    value="<?php  echo $cin  ?>"required/><br>
                                                    </div>
                                                    

                                                    <div class="form-group">
                                                    <label for="nomD">مقر سكن الوالدين</label>
                                                    <input type="text" name="adress" id="adress"
                                                    placeholder="أدخل مقر سكن الوالدين " 
                                                    class="form-control"
                                                    value="<?php  echo $adress  ?>"required/><br>
                                                    </div>
                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">Nom de déclarant(e):</label>
                                                    <input type="text" name="declarant" id="declarant"
                                                    placeholder="Tapez le nom de déclarant(e) : " 
                                                    class="form-control"
                                                    value="<?php  echo $declarant  ?>"required/><br>
                                                    </div>
                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">Date de naissance de déclarant(e) :سنة  ازدياد  المعلن</label>
                                                    <input type="text" name="Nedeclarant" id="Nedeclarant" 
                                                    placeholder="أدخل سنة  ازدياد  المعلن الميلادية " 
                                                    class="form-control"
                                                    value="<?php  echo $Nedeclarant  ?>"required/><br>
                                                    </div>
                                                    <div class="form-group">
                                                    <label for="nomD">:الموافق ل </label>
                                                    <input type="text" name="NedeclarantAr" id="NedeclarantAr"
                                                    placeholder=" أدخل سنة  ازدياد  المعلن الهجرية " 
                                                    class="form-control"
                                                    value="<?php  echo $NedeclarantAr  ?>"required/><br>
                                                    </div>
                                                    <div class="form-group">
                                                    <label for="nomD">:مقر سكن المعلن عن الولادة</label>
                                                    <input type="text" name="adressdeclarant" id="adressdeclarant"
                                                    placeholder="أدخل مقر سكن المعلن عن الولادة " 
                                                    class="form-control"
                                                    value="<?php  echo $adressdeclarant  ?>"required/><br>
                                                    </div>
                                                  
                                                    <div class="form-group">
                                                    <label for="nomD">:رئيس(ة) التحرير</label>
                                                    <input type="text" name="adminEtat" id="adminEtat"
                                                    placeholder="أدخل اسم رئيس(ة) التحرير لمكتب الحالة المدنية " 
                                                    class="form-control"
                                                    value="<?php  echo $adminEtat  ?>"required/><br>
                                                    </div>
                                                   
                                                   
                                
                                  
                                            


                                                    <button onclick="return confirm('Voulez-vous enregistrer les modificatios')" type="submit" class="btn btn-success">

                                                                <span class="glyphicon glyphicon-save"></span> 
                                                                    Enregistrer
                                                        </button>

                                            </form>

                                            
                                      
                                </div>
                    </div>
                </div>  

    </body>
</html>