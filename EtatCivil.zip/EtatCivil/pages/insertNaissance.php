<?php
    require_once('identifier.php');

    require_once('connexiondb.php');

   
    $N_acte=strtoupper(isset($_POST['N_acte'])?$_POST['N_acte']:"");

    $nom=strtoupper(isset($_POST['nom'])?$_POST['nom']:"");
    $nomarabeN=strtoupper(isset($_POST['nomarabeN'])?$_POST['nomarabeN']:"");

    $prenom=strtoupper(isset($_POST['prenom'])?$_POST['prenom']:"");
    $prenomarabeN=isset($_POST['prenomarabeN'])?$_POST['prenomarabeN']:"";
   
    $villeN=isset($_POST['villeN'])?$_POST['villeN']:"";
    $villearabeN=isset($_POST['villearabeN'])?$_POST['villearabeN']:"";

    $date_naissance=isset($_POST['date_naissance'])?$_POST['date_naissance']:"";
    $datearabeN=isset($_POST['datearabeN'])?$_POST['datearabeN']:"";

    $corespN=isset($_POST['corespN'])?$_POST['corespN']:"";
    $coresparabeN=isset($_POST['coresparabeN'])?$_POST['coresparabeN']:"";

    $N_et_lieu_declaration=isset($_POST['N_et_lieu_declaration'])?$_POST['N_et_lieu_declaration']:"";
    $nom_anterieur=isset($_POST['nom_anterieur'])?$_POST['nom_anterieur']:"";
    $nom_antarabeN=isset($_POST['nom_antarabeN'])?$_POST['nom_antarabeN']:"";

    $nom_famille_confirme=isset($_POST['nom_famille_confirme'])?$_POST['nom_famille_confirme']:"";
    $nom_famille_confirmeN=isset($_POST['nom_famille_confirmeN'])?$_POST['nom_famille_confirmeN']:"";

    $prenom_pere=isset($_POST['prenom_pere'])?$_POST['prenom_pere']:"";
    $prparabeN=isset($_POST['prparabeN'])?$_POST['prparabeN']:"";

    $prenom_mere=isset($_POST['prenom_mere'])?$_POST['prenom_mere']:"";
    $prmarabeN=isset($_POST['prmarabeN'])?$_POST['prmarabeN']:"";

    $date_acte=isset($_POST['date_acte'])?$_POST['date_acte']:"";
    
    $cin=strtoupper(isset($_POST['cin'])?$_POST['cin']:"");
    $adress=strtoupper(isset($_POST['adress'])?$_POST['adress']:"");
    $declarant=strtoupper(isset($_POST['declarant'])?$_POST['declarant']:"");
    $Nedeclarant=strtoupper(isset($_POST['Nedeclarant'])?$_POST['Nedeclarant']:"");
    $adressdeclarant=strtoupper(isset($_POST['adressdeclarant'])?$_POST['adressdeclarant']:"");
    $NedeclarantAr=strtoupper(isset($_POST['NedeclarantAr'])?$_POST['NedeclarantAr']:"");
    $adminEtat=strtoupper(isset($_POST['adminEtat'])?$_POST['adminEtat']:"");
    $date_acteAr=strtoupper(isset($_POST['date_acteAr'])?$_POST['date_acteAr']:"");



    $requeteN="insert into naissance(N_acte,nom,nomarabeN,prenom,prenomarabeN,villeN,villearabeN,date_naissance,datearabeN,corespN,coresparabeN,N_et_lieu_declaration,nom_anterieur,nom_antarabeN,nom_famille_confirme,nom_famille_confirmeN,prenom_pere,prparabeN,prenom_mere,prmarabeN,date_acte,cin,adress,declarant,Nedeclarant,adressdeclarant,NedeclarantAr,date_acteAr,adminEtat) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    $params=array($N_acte,$nom,$nomarabeN,$prenom,$prenomarabeN,$villeN,$villearabeN,$date_naissance,$datearabeN,$corespN,$coresparabeN,$N_et_lieu_declaration,$nom_anterieur,$nom_antarabeN,$nom_famille_confirme,$nom_famille_confirmeN,$prenom_pere,$prparabeN,$prenom_mere,$prmarabeN,$date_acte,$cin,$adress,$declarant,$Nedeclarant,$adressdeclarant,$NedeclarantAr,$date_acteAr,$adminEtat);
    $resultatN=$pdo->prepare($requeteN);
    $resultatN->execute($params);

    header('location:naissance.php');


?>