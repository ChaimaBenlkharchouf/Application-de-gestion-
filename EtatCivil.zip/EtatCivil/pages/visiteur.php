
<!DOCTYPE HTML>
<html>
<head>

<meta charset="utf-8">
<title>Extrais pour les naissances - décés - mariage / تسجيلا الولادة - الوفيات - الزواج</title>

<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../css/monstyle.css">

<style>
div.cont{

    float:left; 
    margin:10px;  
}


div span img {
    font-size: 1.2rem;
    padding: 80px 90px;
    margin: 10px 0;
    background: #8d5f6a7a;;
    z-index: 5;
    position: relative;
    cursor: pointer;
    transition: all .4s;
}
div span   img::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 5px;
    height: 100%;
    z-index: -1;
    transition: all .4s;
}

div:hover::before {
    width: 100%;
}

div:nth-child(1)::before {
    background: #4285f4;
}

div :nth-child(2)::before {
    background: #db4437;
}

div:nth-child(3)::before {
    background: #f4b400;
}

div:nth-child(4)::before {
    background: #0f9d58;
}
div span  img:hover {
    transform: translateX(20px);
}
</style>


</head>
<body  style="background-image: url('../images/zh1.jpg')";  >
  
<?php include("menu2.php");?><br><br>
    <div class=" container "> 
<br>
<div class="panel panel-danger  ">
        <div class="panel-heading "  align="center"> <font style=" font:bold 44px 'Aleo'; text-shadow:1px 1px 25px #000; color:#fff;"><center>Espace d'utilisateur</center></font>
        </div>
        </div>


<div class="container">

  <div class="row">
    <div class="col-sm-6"  >
      <p>
         <div align ="right" class="cont"><span><a href="Vne.php"><img src="../images/bb1.jpg" alt="Naissance" width="60%"></a> </span></div>
      </p>
    </div>
    <div class="col-sm-6" >
      <p>
                  <div align ="center" class="cont"><span><a  href=" Vde.php"><img src="../images/mort1.jpg" alt="deces" width="60%" > </a></span></div>   

     </p>
    </div>
  </div>
</div><br><br>

<div class="container">

  <div class="row">
    <div class="col-sm-6">
      <p>
      <div align ="right" class="cont"><span><a  href=" Vma.php"><img src="../images/mar.jpg" alt="deces" width="60%" > </a></span></div>       
      </p>
    </div>
    <div class="col-sm-6" >
      <p>
      <div align ="center" class="cont"><span><a href="Vdeclar.php"><img src="../images/declar.jpg" alt="mariage" width="60%" ></a> </span> </div>

     </p>
    </div>
  </div>
</div>


</body>
</html>