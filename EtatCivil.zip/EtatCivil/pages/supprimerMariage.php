<?php
session_start();   
if(isset($_SESSION['user'])) {
   
    require_once('connexiondb.php');

$idd=isset($_GET['idD'])?$_GET['idD']:0;
$requete="delete from  mariage where idMar=?";
    $params=array($idd);
    $resultat=$pdo->prepare($requete);
    $resultat->execute($params);
    header('location:mariage.php');
}else{
    header('location:login.php');

}
   ?>