<?php
    require_once('identifier.php');

    require_once('connexiondb.php');

    $idd=isset($_POST['idD'])?$_POST['idD']:0;

    $nomd=isset($_POST['nomD'])?$_POST['nomD']:"";
    $num=isset($_POST['num'])?$_POST['num']:"";
   

    $nom=isset($_POST['nom'])?$_POST['nom']:"";
    $prenom=isset($_POST['prenom'])?$_POST['prenom']:"";

    
    $nomarabe=isset($_POST['nomarabe'])?$_POST['nomarabe']:"";
    $prenomarabe=isset($_POST['prenomarabe'])?$_POST['prenomarabe']:"";

    $date=isset($_POST['date'])?$_POST['date']:"";
    $ville=isset($_POST['ville'])?$_POST['ville']:"";
    
    $carte=isset($_POST['carteN'])?$_POST['carteN']:"";
    
    $adress=isset($_POST['adress'])?$_POST['adress']:"";
    $tele_email=isset($_POST['tele_email'])?$_POST['tele_email']:"";
    $prp=isset($_POST['prp'])?$_POST['prp']:"";
    $prm=isset($_POST['prm'])?$_POST['prm']:"";
    $prparabe=isset($_POST['prparabe'])?$_POST['prparabe']:"";
    $prmarabe=isset($_POST['prmarabe'])?$_POST['prmarabe']:"";


    $requete="update declares set nom=?, prenom=?, nomarabe=?, prenomarabe=?, date=?, ville=?, carteN=?, adress=?, tele_email=?, prp=?, prparabe=?, prm=?,prmarabe=?, typeDeclaration=?, num=? where idDeclaration=?";
    $params=array($nom,$prenom,$nomarabe,$prenomarabe,$date,$ville,$carte,$adress,$tele_email,$prp,$prparabe,$prm,$prmarabe,$nomd,$num,$idd);
    $resultat=$pdo->prepare($requete);
    $resultat->execute($params);

    header('location:déclaration.php');


?>