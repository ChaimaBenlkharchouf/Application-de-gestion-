<?php
//message reflete s'il y a un erreur:
        try{
           $pdo=new PDO("mysql:host=localhost;dbname=etat_civil","root","");
 
        }catch(Exception $e){
            die('Erreur :! impossible de se connecter à la base de donnée!' .$e->getMessage());
        
        }

            

?>