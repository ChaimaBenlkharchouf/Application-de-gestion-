<?php
                require_once('identifier.php');
     
              require_once("connexiondb.php");

              $N_acte=isset($_GET['N_actenum'])?$_GET['N_actenum']:"";
              $nom=isset($_GET['nom'])?$_GET['nom']:"";
              $nomarabeN=isset($_GET['nomarabeN'])?$_GET['nomarabeN']:"";




              $nomd=isset($_GET['nomD'])?$_GET['nomD']:"all";
              

              $size= isset($_GET['size'])?$_GET['size']:5;
              $page=isset($_GET['page'])?$_GET['page']:1 ;
              $offset=($page-1)*$size;

       
       if($nomd=="all")
       {
              
              $requete="select * from naissance
              where (nom like '%$N_acte%' or N_acte like '%$N_acte%'
           
              or nomarabeN like '%$N_acte%')
              limit $size offset $offset ";

              $requeteCount="select count(*) countD from naissance
              where (nom like '%$N_acte%' or N_acte like '%$N_acte%'
              
              or nomarabeN like '%$N_acte%')";

      }
      else{
              $requete="select * from naissance
              where nom like '%$nom%'and (N_acte like '%$N_acte%')
              and nomarabeN like '%$nomarabeN%'
            
              and typeDeclaration='$nomd' 
              
              limit $size  offset $offset ";

              $requeteCount="select count(*) countD naissance
              where (nom like '%$N_acte%' or N_acte like '%$N_acte%'

              or nomarabeN like '%$N_acte%')
            

              and typeDeclaration='$nomd' ";

       }
              $resultatD=$pdo->query($requete);
              $resultatCount=$pdo->query($requeteCount);
              $tabCount=$resultatCount->fetch();
              $nbrNaissance=$tabCount['countD'];
              $reste=$nbrNaissance % $size;

              if($reste===0)
                     $nbrPage=$nbrNaissance/$size;
              else
                     $nbrPage=floor($nbrNaissance/$size) + 1;

       
?>

<!DOCTYPE HTML>
<html>
       <head>
              <meta charset="utf-8">
              <title>Gestion de naissance  </title>
              <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
              <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
              <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">

              <meta name="viewport" content="width=device-width, initial-scale=1">
              <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

              <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

       </head>
       <body  style="background-image: url('../images/zh1.jpg')";  >
      
       <?php include("menu.php");?>
      
       <div style="text-align:center;" class="container"> 

      
        <div  style="width:114%;" class="panel panel-success margetop">
                <div class="panel-heading">Rechercher des naissances...</div>

                    <div class="panel-body">
                      <form method="get" action="naissance.php"  class="form-inline">
                            

                             <div class="form-group">

                                   <input style="width:160%;;"  type="text" name="N_actenum"    
                                   placeholder="Chercher sur: N° d'acte/Nom/الاسم العائلي" 
                                   class="form-control"
                                   value="<?php  echo $N_acte;   ?>"

                                   onchange="this.form.submit()" />
                          
                           
                                            
                      
                                          <button type="submit" class="btn btn-success">
                                                 <span class="glyphicon glyphicon-search"></span> 
                                                        Chercher...
                                          </button>
                                          &nbsp;&nbsp;
                                          <?php if ($_SESSION['user']['role1']=='ADMIN')  { ?>

                                          <a href="nouvelleNaissance.php">
                                                 <span class="glyphicon glyphicon-plus"></span>
                                                 Nouvelle naissance
                                          </a>
                                          <?php }?>   
                                    </div>
                            </form>
                
                      </div>
              </div>


              <div style="width:114%;"  class="panel panel-danger">
                <div class="panel-heading"> Nombre de personne: <?php echo $nbrNaissance;  ?> personnes </div>
              
                <div    class="panel-body">
                     <table   style="width:114%; " class="table table-striped table-bordered">
                            <thead>
                                 <tr>
                                 <th>Id Naissance</th>
                                 <th>N° d'acte</th>
                                 <th>Nom</th>
                                 <th>الاسم العائلي</th>
                                 <th>Prénom</th>
                                 <th>الاسم الشخصي</th>
                                 <th>Ville</th>
                                 <th>مكان الولادة</th>
                              
                                 <th>Date de naissance</th>
                                 <th>تاريخ الولادة</th>
                                 <th>Corespondant au</th>
                                 <th>الموافق</th>
                               
                                 <th>Date de l'acte</th>
                                 <th>CIN</th>              
                                      <?php if ($_SESSION['user']['role1']=='ADMIN')  { ?>
                                 <th >   Action</th>
                                 <?php }?>
                                 </tr>  
                            </thead>
                            <tbody>
                                  
                                     <?php while($naissance=$resultatD->fetch()){ ?>
                                        <tr>
                                            
                                            <td><?php echo $naissance['idNaissance'] ?>  </td>
                                            <td><?php echo $naissance['N_acte'] ?>  </td>
                                            <td><?php echo $naissance['nom'] ?>  </td>
                                            <td><?php echo $naissance['nomarabeN'] ?>  </td>
                                            <td><?php echo $naissance['prenom'] ?>  </td>
                                            <td><?php echo $naissance['prenomarabeN'] ?>  </td> 
                                            <td><?php echo $naissance['villeN'] ?>  </td>  
                                            <td><?php echo $naissance['villearabeN'] ?>  </td>
                                            <td><?php echo $naissance['date_naissance'] ?>  </td>
                                            <td><?php echo $naissance['datearabeN'] ?>  </td>
                                            <td><?php echo $naissance['corespN'] ?>  </td>
                                            <td><?php echo $naissance['coresparabeN'] ?>  </td>
                                            <td><?php echo $naissance['date_acte'] ?>  </td>
                                            <td><?php echo $naissance['cin'] ?>  </td>
                                           
                                            <?php if ($_SESSION['user']['role1']=='ADMIN')  { ?>
                                             <td style="width:100px">
                                                        
                                                    <a  href="vueNaissance.php?idD=<?php echo $naissance['idNaissance'] ?> "> 
                                                        <i class="fa fa-eye" style="font-size:20px;color:gris"></i>
                                                    </a>
                                                    &nbsp;
                                                    <a href="editerNaissance.php?idD=<?php echo $naissance['idNaissance'] ?> ">
                                                    <span class="glyphicon glyphicon-edit">
                                                         </span>
                                                        </a> 
                                                        &nbsp;
                                                    <a onclick="return confirm('Etes-vous sur de vouloir supprimer la naissance')" 
                                                         href="supprimerNaissance.php?idD=<?php echo $naissance['idNaissance'] ?> "> 
                                                         <span class="glyphicon glyphicon-trash"></span>
                                                        

                                                    </a>

                                                    

                                              </td>
                                              <?php }?>
                                          </tr>
                                      <?php } ?>
                            
                                    
                            </tbody>
                     </table>

                                          <div>
                                          
                                          <ul class="nav nav-pills">
                                          <?php for($i=1;$i<=$nbrPage;$i++){ ?>
                            <li class="<?php if($i==$page) echo 'active' ?>"> 
                                   <a href="naissance.php?page=<?php echo $i;?>&N_acte=<?php echo $N_acte ?>&nom=<?php echo $nom ?>&nomarabeN=<?php echo $nomarabeN ?>">
                                          <?php echo $i; ?>
                                   </a> 
                            </li>
                                  <?php } ?>
                                          </ul>
                        </div>

                 </div>
         </div>
</div>  

</body>
</html>








