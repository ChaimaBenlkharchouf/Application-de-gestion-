<?php
             

              require_once("connexiondb.php");

              $N_acte_d=isset($_GET['N_acte_d'])?$_GET['N_acte_d']:"";
              $nom_d=isset($_GET['nom_d'])?$_GET['nom_d']:"";
              $nom_darabe=isset($_GET['nom_darabe'])?$_GET['nom_darabe']:"";


              $nomd=isset($_GET['nomD'])?$_GET['nomD']:"all";
              

              $size= isset($_GET['size'])?$_GET['size']:5;
              $page=isset($_GET['page'])?$_GET['page']:1 ;
              $offset=($page-1)*$size;

       
       if($nomd=="all")
       {
              
              $requete="select * from deces
              where (nom_d like '%$N_acte_d%' or N_acte_d like '%$N_acte_d%'
              or nom_darabe like '%$N_acte_d%')
              limit $size offset $offset ";

              $requeteCount="select count(*) countD from deces
              where (nom_d like '%$N_acte_d%' or N_acte_d like '%$N_acte_d%'
              or nom_darabe like '%$N_acte_d%')";

      }
      else{
              $requete="select * from deces
              where nom_d like '%$nom_d%'and (N_acte_d like '%$N_acte_d%')
              and nom_darabe like '%$nom_darabe%'
            
              and idDeclaration='$nomd' 
              
              limit $size  offset $offset ";

              $requeteCount="select count(*) countD deces
              where  (nom_d like '%$N_acte_d%' or N_acte_d like '%$N_acte_d%'
              or nom_darabe like '%$N_acte_d%')
            

              and idDeclaration='$nomd' ";

       }
              $resultatD=$pdo->query($requete);
              $resultatCount=$pdo->query($requeteCount);
              $tabCount=$resultatCount->fetch();
              $nbrNaissance=$tabCount['countD'];
              $reste=$nbrNaissance % $size;

              if($reste===0)
                     $nbrPage=$nbrNaissance/$size;
              else
                     $nbrPage=floor($nbrNaissance/$size) + 1;

       
?>

<!DOCTYPE HTML>
<html>
       <head>
              <meta charset="utf-8">
              <title>Acte décés  </title>
              <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
              <link rel="stylesheet" type="text/css" href="../css/champ.css">

              <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
              <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">

              <meta name="viewport" content="width=device-width, initial-scale=1">
              <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

              <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

       </head>
       <body  style="background-image: url('../images/etat1.jpg')";  >
      
       <?php include("menu2.php");?><br><br><br>
      <br><br><br><br><br>
       <div style="text-align:center;" class="container"> 

      
        <div  class="panel panel-success margetop">
                <div class="panel-heading">Espace d'utilisateur</div>

                    <div class="panel-body">
                      <form method="get" action="vueVisiteurD.php"  class="form-inline">
                            

                             <div class="form-group">
                             <label for="nom_d">Nom :&nbsp;&nbsp;</label>
                                   <input  type="text" name="nom_d"    
                                   placeholder="Tapez votre Nom/الاسم العائلي" 
                                   class="form-control"
                                   value="<?php  echo $N_acte_d;   ?>"required />
                                   <label for="N_acte_d">Nom :&nbsp;&nbsp;</label>

                                   <input  type="text" name="N_acte_d"    
                                   placeholder="Tapez votre  N° d'acte" 
                                   class="form-control"
                                   value="<?php  echo $N_acte_d;   ?>"required/> <br><br>
                          
                                            
                      
                                          <button type="submit" class="btn btn-success">
                                                 <span ></span> 
                                                        Validé
                                          </button>
                                         
                                    </div>
                            </form>
                
                      </div>
              </div>

              

       

</body>
</html>

