


<!DOCTYPE html>
<html lang="fr" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>
        Acceuil
        </title>
        <link rel="stylesheet" href="../css/style.css">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="viewport" content="width=device-width, initial-scale=1">
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


<style>
       
       *{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Poppins' , sans-serif;

}
body{
    background: #f2f2f2;
}
nav{
    background: #1b1b1b;
}
nav:after{
    content: '';
    clear: both;
    display: table;
}
nav .logo{
    float: left;
    color: white;
    font-size: 14px;
    font-weight: 600;
    line-height: 70px;
    padding-left: 60px;

}
nav ul{
    float: right;
    list-style: none;
    margin-right: 40px;
    position: relative;
}
nav ul li{
    float: left;
    display: inline-block;
    background: #1b1b1b;
    margin: 0 5px;
}

nav ul li a{
    color: white;
    text-decoration: none;
    line-height: 70px;
    font-size: 18px;
    padding: 8px 15px;
}
nav ul li a:hover{
    color: cyan;
    border-radius:  5px;
    box-shadow:  0 0 5ps #33ffff,
                 0 0 5ps #66ffff;

}
nav ul ul li a:hover{
    color: cyan;
    box-shadow: none;
}
nav ul ul{
    position: absolute;
    top: 90px;
    border-top: 3px solid cyan;
    opacity: 0;
    visibility: hidden;
    transition: top .3s;
}

nav ul ul ul{
    border-top: none;
}
nav ul li:hover > ul{
    top: 70px;
    opacity: 1;
    visibility: visible;
}
nav ul ul li{
    position: relative;
    margin : 0px;
    width: 150px;
    float: none;
    display :list-item;
    border-bottom: 1px solid rgba(0,0,0,0,3);
}
nav ul ul li a{
    line-height: 50px;
}
nav ul ul ul li{
    position: relative;
    top: -70px;
    left: 150px;

}
.fa-plus{
    margin-left: 40px;
    font-size: 15px;
}
.show, .icon, input{
    display: none;

}
@media all and (max-width: 968px){
    nav ul{
        margin-right: 0px;
        float: left;
    }
    nav .logo{
        padding-left: 30px;
        width: 100%;
    }
    nav ul li, nav ul ul li{
        display: block;
        width: 100%;

    }
    nav ul ul {
        top: 70px;
        position: static;
        border-top: none;
        float: none;
        display: none;
        opacity: 1;
        visibility: visible;
    }

    nav ul ul ul li{
        position: static;
    }
    nav ul ul li{
        border-bottom: 0px;
    }
    nav ul ul  a{
        padding-left:40px;
    }
    nav ul ul ul a{
        padding-left:80px;
    }
    .show{
        display: block;
        color: white;
        font-size: 18px;
        padding: 0 20px;
        line-height: 70px;
        cursor: pointer;
    }
    .show :hover{
        color: cyan;
    }
    .icon{
        display: block;
        color: white;
        position: absolute;
        right: 40px;
        line-height: 70px;
        font-size: 25px;
        cursor: pointer;

    }
    nav ul li a:hover{
        box-shadow: none;
    }
    .show + a, ul{
        display: none;
    }
    [id^=btn]:checked + ul{
        display: block;
    }
}
   </style>
    </head>
    <body>
        
        
    <nav >
            <div class="logo"><a href="../face/Acceuil.php"><img src="../images/king.jpg"> <img src="../images/mr.jpg" alt="" width="30"> ETATA CIVIL</a></div>
            <label for="btn" class="icon">
                <span class="fa fa-bars"></span>
            </label>
            <input type="checkbox"  id="btn">
            <ul>
                <li >
                    <a href="../face/Acceuil.php"> <span class=" w3-xlarge  fa fa-home"></span> Acceuil</a>
                </li>
                
               
                <li>
                    <label for="btn-1" class="show">Guide de l'état civil   +</label>

                    <a href="#">Guide de l'état civil</a>
                    <input type="checkbox"  id="btn-1">
                    <ul>
                        <li><a href="bureau.php" >Les bureaux </a></li>
                        <li><a href="registreF.php">Les registres </a></li>
                        <li><a href="statistique.php">Les statistiques </a></li>
                    </ul>
                </li>
                <li>
                     <label for="btn-2" class="show"> Services électroniques   +</label>

                        <a href="../pages/visiteur.php"> Services électroniques </a>
                    <input type="checkbox"  id="btn-2">
                    <ul>
                        <li><a href="../pages/Vne.php">Acte de naissance</a></li>
                        <li><a href="../pages/Vde.php">Acte de décé</a></li>
                        <li><a href="../pages/Vma.php">Aacte de mariage</a></li>
                        <li><a href="../pages/Vdeclar.php">Pré-déclaration</a></li>
                        <li>
                        <label for="btn-3" class="show">More  +</label>
                    <a href="#">More 
                        <span class="fa fa-plus"></span>
                    </a><input type="checkbox"  id="btn-3">
                    <ul>
                        <li><a href="Mar.php">Marocains à l'étranger</a></li>
                        <li><a href="Etrang.php">Etrangers au Maroc</a></li>
                       
                    </ul>
                </li>
                        
                    </ul>
                </li>
                <li><a href="../contact/index.php">Contact</a></li>
                <li>
                    <label for="btn-4" class="show">Connexion +</label>

                    <a href="#">Connexion</a>
                    <input type="checkbox"  id="btn-4">
                    <ul>
                        <li><a href="../pages/login.php" > Administration</a></li>
                        <li><a href="../pages/visiteur.php">Visiteur</a></li>
                    </ul>
                </li>
           
                       
            </ul>
        </nav>


    </body>

</html>