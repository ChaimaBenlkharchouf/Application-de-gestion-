<?php


$nomd=isset($_GET['idcnt'])?$_GET['idcnt']:"all";
     require_once("connexiondb.php");
  
    $name=isset($_GET['name'])?$_GET['name']:"";
    $email=isset($_GET['email'])?$_GET['email']:"";
    $phone=isset($_GET['phone'])?$_GET['phone']:"";
    $message=isset($_GET['message'])?$_GET['message']:"";

    $size=isset($_GET['size'])?$_GET['size']:4;
    $page=isset($_GET['page'])?$_GET['page']:1;
    $offset=($page-1)*$size;
    

        if($nomd=="all")
        {
              
        $requete="select * from contact where name like '%$name%'
        limit $size offset $offset";
        
        $requeteCount="select count(*) countD from contact  where name like '%$name%'";

  
 
       }
       else{
               $requete="select * from contact
               where  name like '%$name%' 
               and idcnt='$nomd'
               
               limit $size  offset $offset ";
 
               $requeteCount="select count(*) countD from contact
               where name like '%$name%'
               and idcnt='$nomd'
               ";
        }
           

$resultatD=$pdo->query($requete);
              $resultatCount=$pdo->query($requeteCount);
              $tabCount=$resultatCount->fetch();
              $nbrDeclaration=$tabCount['countD'];
              $reste=$nbrDeclaration % $size;

              if($reste===0)
                     $nbrPage=$nbrDeclaration/$size;
              else
                     $nbrPage=floor($nbrDeclaration/$size) + 1;

       
?>

<!DOCTYPE HTML>
<html>
       <head>
              <meta charset="utf-8">
              <title>Message </title>
              <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
              <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
              <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">

              <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


       </head>
       <body  style="background-image: url('../images/zh1.jpg')"; >
      
       <?php include("menu.php");?>
      
       <div class="container"> 

      
        <div class="panel panel-success margetop">
                <div class="panel-heading">Rechercher des nom...</div>

                    <div class="panel-body">
                      <form method="get" action="détail.php"  class="form-inline">
                             <div class="form-group">

                             <input type="text" name="name" 
                                   placeholder="Taper le nom"
                                   class="form-control"
                                   value="<?php echo $name ?>"/>

                             </div> 
                                                    
                           
                            
                            
                                          <button type="submit" class="btn btn-success">
                                                 <span class="glyphicon glyphicon-search"></span> 
                                                        Chercher...
                                          </button>
                                          &nbsp;&nbsp;
                            </form>
                
                            </div></div>
      

         <div class="panel panel-danger ">
                <div class="panel-heading">Nombre de message (<?php echo $nbrDeclaration  ?> messages) </div>
                  <div class="panel-body">
                     <table class="table table-striped table-bordered">
                     <thead>
                            <tr>
                                <th>IDcontact</th> <th>Nom</th> <th>Email</th> <th>téléphone</th> <th>Message</th>
                              
                                 <?php if ($_SESSION['user']['role1']=='ADMIN')  { ?>
                                 <th>Action</th>
                                 <?php }?>
                              </tr>  
                            </thead>
                            <tbody>
                                  
                                     <?php while($user=$resultatD->fetch()){ ?>
                                        <tr>
                                            
                             <tr>
                                   <td><?php echo $user['idcnt'] ?> </td>
                                    <td><?php echo $user['name'] ?> </td>
                                    <td><?php echo $user['email'] ?> </td> 
                                    <td><?php echo $user['phone'] ?> </td>
                                    <td><?php echo $user['message'] ?> </td> 
                                            <?php if ($_SESSION['user']['role1']=='ADMIN')  { ?>
                                             <td>
                                               
                                                        &nbsp;
                                                    <a onclick="return confirm('Etes-vous sur de vouloir supprimer ce message')" 
                                                    href="supdétail.php?idcnt=<?php echo $user['idcnt'] ?>">
                                                        <span class="glyphicon glyphicon-trash"></span>
                                                    </a>

                                                    

                                              </td>
                                              <?php }?>
                               </tr>
                                      <?php } ?>
                            
                                    
                            </tbody>
                     </table>

                                          <div>
                                          
                                          <ul class="nav nav-pills">
                                          <?php for($i=1;$i<=$nbrPage;$i++){ ?>
                            <li class="<?php if($i==$page) echo 'active' ?>"> 
                                   <a href="détail.php?page=<?php echo $i;?>&name=<?php echo $name; ?>">
                                          <?php echo $i; ?>
                                   </a> 
                            </li>
                                  <?php } ?>
                                          </ul>
                        </div>

                 </div>
     </div>


</body>
</html>
