<?php
require_once("connexiondb.php");

              $nomd=isset($_GET['nomD'])?$_GET['nomD']:"all";
              $num=isset($_GET['num'])?$_GET['num']:"";

              $size= isset($_GET['size'])?$_GET['size']:5;
              $page=isset($_GET['page'])?$_GET['page']:1 ;
              $offset=($page-1)*$size;

       
       if($nomd=="all")
       {
              $requete="select * from declares
              where num like '%$num%'
              limit $size offset $offset ";

              $requeteCount="select count(*) countD from declares
              where num like '%$num%'";

      }
      else{
              $requete="select * from declares
              where  num like '%$num%' 
              and typeDeclaration='$nomd'
              
              limit $size  offset $offset ";

              $requeteCount="select count(*) countD from declares
              where num like '%$num%'
              and typeDeclaration='$nomd'
              ";
       }
              $resultatD=$pdo->query($requete);
              $resultatCount=$pdo->query($requeteCount);
              $tabCount=$resultatCount->fetch();
              $nbrDeclaration=$tabCount['countD'];
              $reste=$nbrDeclaration % $size;

              if($reste===0)
                     $nbrPage=$nbrDeclaration/$size;
              else
                     $nbrPage=floor($nbrDeclaration/$size) + 1;

       
?>

<!DOCTYPE HTML>
<html>
       <head>
              <meta charset="utf-8">
              <title>Acte de déclaration </title>
              <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
              <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
              <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
              <link rel="stylesheet" type="text/css" href="../css/champ.css">

              <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


       </head>
       <body  style="background-image: url('../images/zh1.jpg')"; >
      
       <?php include("menu2.php");?><br><br><br><br><br><br><br><br>      
       <div class="container"> 

      
        <div class="panel panel-success margetop">
                <div class="panel-heading">Espace de déclaration pour l'utilisateur.</div>

                    <div class="panel-body">
                      <form method="get" action="vueVisiteurDeclar.php"  class="form-inline"     align="center">
                             <div class="form-group">
                             <label for="nomD" >Numéro de déclaration :</label>  <br>
                                   <input type="text" name="num" 
                                   placeholder=" Tapez votre numéro de déclaration" 
                                   class="form-control"
                                   value="<?php echo $num  ?>"
                                   required />

                             </div> <br><br><br>
                                                    
                           
                              <label for="nomD" >Type :</label>  
                                   <select name="nomD" class="form-control" id="nomD" required>
                                          <option value="all" <?php  if($nomd==="all")  echo "selected" ?>> Tout les types</option>
                                          <option value="DN"  <?php  if($nomd==="DN")  echo "selected"  ?>> DN( Declaration de naissance normale )</option>
                                          <option value="DNC" <?php  if($nomd==="DNC")  echo "selected" ?>> DNC( Declaration de naissance cas voyage )</option>
                                          <option value="DNE" <?php  if($nomd==="DNE") echo "selected"  ?>> DNE( Declaration de naissance d"enfant abandonné )</option>
                                          <option value="DD"  <?php  if($nomd==="DD")  echo "selected"  ?>> DD( Declaration de décées normale )</option>
                                          <option value="DDA" <?php  if($nomd==="DDA")  echo "selected" ?>> DDA( Declaration de décés anormales )</option>
                                   </select><br><br>
                            
                                          <button type="submit" class="btn btn-success">
                                                 <span></span> 
                                                      Validé
                                          </button>
                                         
                                          <a href="nouvelleDéclarVisi.php">
                                                 <span class="glyphicon glyphicon-plus"></span>
                                                 Ajouter une déclaration
                                          </a>   
                           
                            </form>
                
                      </div>
              </div>



</body>
</html>