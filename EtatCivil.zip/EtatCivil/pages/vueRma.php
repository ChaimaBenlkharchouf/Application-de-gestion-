<?php

require_once('identifier.php');
require_once("connexiondb.php");
              
              $size= isset($_GET['size'])?$_GET['size']:5;
              $page=isset($_GET['page'])?$_GET['page']:1 ;
              $offset=($page-1)*$size;

              $idd=isset($_GET['idD'])?$_GET['idD']:0;
              $requete="select * from mariage where idMar=$idd";
                            $nomd=isset($_GET['nomD'])?$_GET['nomD']:"all";
                            $idd=isset($_GET['idD'])?$_GET['idD']:0;
                            $requete="select * from mariage where idMar=$idd";
                            
                            $resultat=$pdo->query($requete);
                            $deces=$resultat->fetch();
                       
$numMAH=strtoupper($deces['numMAH']);
$dateM=strtoupper($deces['dateM']);
$numdossier=strtoupper($deces['numdossier']);
$time=strtoupper($deces['time']);
$dateMam=strtoupper($deces['dateMam']);
$dateMah=strtoupper($deces['dateMah']);
$nomadl1=strtoupper($deces['nomadl1']);
$nomadl2=strtoupper($deces['nomadl2']);
$page=strtoupper($deces['page']);
$numero=$deces['numero'];
$wasl=strtoupper($deces['wasl']);
$nomh=strtoupper($deces['nomh']);
$prenomh=strtoupper($deces['prenomh']);
$dateNeh=strtoupper($deces['dateNeh']);
$villeh=strtoupper($deces['villeh']);
$prph=strtoupper($deces['prph']);
$mereh =strtoupper($deces['mereh']);
$nationalh =strtoupper($deces['nationalh']);
$travailh =strtoupper($deces['travailh']);
$habiteh =strtoupper($deces['habiteh']);
$cinh =strtoupper($deces['cinh']);
$etath =strtoupper($deces['etath']);
$nomf =strtoupper($deces['nomf']);
$prenomf =strtoupper($deces['prenomf']);
$dateNef =strtoupper($deces['dateNef']);
$villef =strtoupper($deces['villef']);
$prpf =strtoupper($deces['prpf']);
$cinprpf =strtoupper($deces['cinprpf']);
$neprpf =strtoupper($deces['neprpf']);
$nationalprpf =strtoupper($deces['nationalprpf']);
$travailprpf =strtoupper($deces['travailprpf']);
$meref =strtoupper($deces['meref']);
$nationalf =strtoupper($deces['nationalf']);
$travailf =strtoupper($deces['travailf']);
$habitef =strtoupper($deces['habitef']);
$cinf =strtoupper($deces['cinf']);
$etatf =strtoupper($deces['etatf']);
$prix =strtoupper($deces['prix']);
$date_acteM =strtoupper($deces['date_acteM']);
$date_acteH =strtoupper($deces['date_acteH']);



             

if($nomd=="all")
{
       
       $requete="select * from mariage
       where (nomh like '%$nomh%' or nomf like '%$nomh%'
    
       or numdossier like '%$nomh%' or cinf like '%$nomh%'
       or cinh like '%$nomh%')
       limit $size offset $offset ";

       $requeteCount="select count(*) countD from mariage
       where (nomh like '%$nomh%' or nomf like '%$nomh%'
       or cinh like '%$nomh%' or cinf like '%$nomh%'
       or numdossier like '%$nomh%')";

}
else{
       $requete="select * from mariage
       where nomh like '%$nomh%'and (nomf like '%$nomh%')
       and numdossier like '%$nomh%'
       and cinh like '%$nomh%' and cinf like '%$nomh%'
       and page='$nomd' 
       
       limit $size  offset $offset ";

       $requeteCount="select count(*) countD mariage
       where (nomh like '%$nomh%' or nomf like '%$nomh%'
       or cinh like '%$nomh%' or cinf like '%$nomh%'
       or numdossier like '%$nomh%')
     

       and page='$nomd' ";

}
       $resultat=$pdo->query($requete);
       $resultatCount=$pdo->query($requeteCount);
       $tabCount=$resultatCount->fetch();
       $nbrNaissance=$tabCount['countD'];
       $reste=$nbrNaissance % $size;

       if($reste===0)
              $nbrPage=$nbrNaissance/$size;
       else
              $nbrPage=floor($nbrNaissance/$size) + 1;


                     
       
?>

<!DOCTYPE HTML>
<html>
       <head>
              <meta charset="utf-8">
              <title>عقد الزواج </title>
              <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
              <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
              <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
              <meta name="viewport" content="width=device-width, initial-scale=1">
              <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
              <link rel="stylesheet" href="print.css" >

              <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


                <STYle>
                DIV.double {
                    border-style: double;
                    border-radius: 20px;
                }
                pre.arb{
                  background: white ;
                }
             
                </STYle>
            
       </head>
       <body  style="background-image: url('../images/etat1.jpg')"; >


       <?php include("menu.php");?><br><br>      
       <div style="width:85%;" class="container ">
             <div class="panel panel-primary margetop">
        <div class="panel-heading" align="center"> نسخة موجزة من  عقد النكاح </div> <strong>
<b>
         <div align="right">بسم الله الرحمان الرحيم  </div>
<div align="center"><i> المملكة المغربية </div>
          <div align="center"><i>وزارة العدل المحكمة لابتدائية </div>                  
          <div align="center"><i>قسم التوثيق بالجديدة  </div>                            <div align="right">مكتب السعادة رقم 33م  </div>   
                                                                                           <div align="right">  وصل عدد بتاريخ </i> </div> 
                                                                                           <div align="center"><i>عقد الزواج لوكيل الملك </div>                                      
<div align="right"> ملف مستندات الزواج رقم  : <b><?php echo $deces['numMAH'] ?> </b></div>        <div align="right">   <b><?php echo $deces['dateM'] ?> </b>    :السنة</div>
<div align="right"> وصل   : <b><?php echo $deces['wasl'] ?> </b></div>        <div align="right">   <b><?php echo $deces['numdossier'] ?> </b>    :رقم الملف </div>
<div align="right"> على الساعة    : <b><?php echo $deces['time'] ?> </b></div>       
<div align="right"> تاريخ الزواج الميلادي   : <b><?php echo $deces['dateMam'] ?> </b></div>        <div align="right">   <b><?php echo $deces['dateMah'] ?> </b>    : تاريخ الزواج الهجري   </div>
<div align="right"> صفحة   : <b><?php echo $deces['page'] ?> </b></div>        <div align="right">   <b><?php echo $deces['numero'] ?> </b>    :عدد </div>

<div align="right">اسم العدل الأول  : <?php echo $deces['nomadl1'] ?></div>        <div align="right"> اسم العدل التاني  :<b><?php echo $deces['nomadl2'] ?> </div></b></b>

<div align="right">الاسم الشخصي للزوج   : <b><?php echo $deces['nomh'] ?> </b></div>      
<div align="right">الاسم االعائلي للزوج : <b><?php echo $deces['prenomh'] ?></b></div>
<div align="center">جنسيته   : <?php echo $deces['nationalh'] ?></div>      
<div align="right">تاريخ الازدياد : <?php echo $deces['dateNeh'] ?></div> 
<div align="right">مكان الازدياد   : <?php echo $deces['villeh'] ?></div>    
<div align="right">مهنته: <?php echo $deces['travailh'] ?></div> 
<div align="center"> <?php echo $deces['cinh'] ?>: رقم البطاقة الوطنية </div>      
<div align="right">سكناه : <?php echo $deces['habiteh'] ?></div> 
<div align="right">والده : <?php echo $deces['prph'] ?> </div>
<div align="right">والدته: <?php echo $deces['mereh'] ?></div> 
<div align="right">حالته :  <?php echo $deces['etath'] ?></div>            

<div align="right">الاسم الشخصي للزوجة : <b><?php echo $deces['nomf'] ?> </b>    
<div align="right">الاسم االعائلي للزوجة : <b><?php echo $deces['prenomf'] ?></b></div>
<div align="center">جنسيتها   : <?php echo $deces['nationalf'] ?></div>      
<div align="right">تاريخ الازدياد للزوجة : <?php echo $deces['dateNef'] ?></div> 
<div align="right">مكان الازدياد للزوجة   : <?php echo $deces['villef'] ?></div>    
<div align="right"> مهنتها: <?php echo $deces['travailf'] ?></div> 
<div align="center"> <?php echo $deces['cinf'] ?>: رقم البطاقة الوطنية </div>      
<div align="right">سكناها : <?php echo $deces['habitef'] ?></div> 
<div align="right">والدها : <?php echo $deces['prpf'] ?> </div>
<div align="right">تاريخ ازدياد الأب  : <?php echo $deces['neprpf'] ?> </div>
<div align="center"> <?php echo $deces['cinprpf'] ?>: رقم البطاقة الوطنية </div>      
<div align="right">مهنة أب الفتاة : <?php echo $deces['travailprpf'] ?> </div>
<div align="right">جنسية أب الفتاة : <?php echo $deces['nationalprpf'] ?> </div>
<div align="right">والدتها: <?php echo $deces['meref'] ?></div> 
<div align="right">حالتها :  <?php echo $deces['etatf'] ?></div>     
</b>       
</strong> </div> 
</div>  
</div></div> 
                         <div align="center"> 
                            <button  type="submit" class="btn btn-success" onclick="window.print();" classe="btn btn primary" id="print-btn" >
                                          <span href="vueRma.php"> <i class="material-icons">&#xe8ad;</i>
                                          <b>Imprimer </b>
                                          </span> 
                            </button>
                           
                                     </div> <br><br><br>
                                  
</body>
</html>