<?php
    require_once('identifier.php');
    require_once("connexiondb.php");

              $nomh=isset($_GET['nomh'])?$_GET['nomh']:"";
              $nomf=isset($_GET['nomf'])?$_GET['nomf']:"";
              $cinf=isset($_GET['cinf'])?$_GET['cinf']:"";
              $cinh=isset($_GET['cinh'])?$_GET['cinh']:"";
              $numdossier=isset($_GET['numdossier'])?$_GET['numdossier']:"";




              $nomd=isset($_GET['nomD'])?$_GET['nomD']:"all";
              

              $size= isset($_GET['size'])?$_GET['size']:5;
              $page=isset($_GET['page'])?$_GET['page']:1 ;
              $offset=($page-1)*$size;

       
       if($nomd=="all")
       {
              
              $requete="select * from mariage
              where (nomh like '%$nomh%' or nomf like '%$nomh%'
           
              or numdossier like '%$nomh%' or cinf like '%$nomh%'
              or cinh like '%$nomh%')
              limit $size offset $offset ";

              $requeteCount="select count(*) countD from mariage
              where (nomh like '%$nomh%' or nomf like '%$nomh%'
              or cinh like '%$nomh%' or cinf like '%$nomh%'
              or numdossier like '%$nomh%')";

      }
      else{
              $requete="select * from mariage
              where nomh like '%$nomh%'and (nomf like '%$nomh%')
              and numdossier like '%$nomh%'
              and cinh like '%$nomh%' and cinf like '%$nomh%'
              and page='$nomd' 
              
              limit $size  offset $offset ";

              $requeteCount="select count(*) countD mariage
              where (nomh like '%$nomh%' or nomf like '%$nomh%'
              or cinh like '%$nomh%' or cinf like '%$nomh%'
              or numdossier like '%$nomh%')
            

              and page='$nomd' ";

       }
              $resultatD=$pdo->query($requete);
              $resultatCount=$pdo->query($requeteCount);
              $tabCount=$resultatCount->fetch();
              $nbrNaissance=$tabCount['countD'];
              $reste=$nbrNaissance % $size;

              if($reste===0)
                     $nbrPage=$nbrNaissance/$size;
              else
                     $nbrPage=floor($nbrNaissance/$size) + 1;

       
?>

<!DOCTYPE HTML>
<html>
       <head>
              <meta charset="utf-8">
              <title>Register de mariage  </title>
              <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
              <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
              <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">

              <meta name="viewport" content="width=device-width, initial-scale=1">
              <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

              <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

       </head>
       <body  style="background-image: url('../images/etat1.jpg')";>
      
       <?php include("menu.php");?>
      
     
      
      <div class="container" style="text-align:center;"> 

      
        <div  style="width:114%;" class="panel panel-success margetop">
                <div class="panel-heading">Rechercher des mariages...</div>

                    <div class="panel-body">
                      <form method="get" action="mariage.php"  class="form-inline">
                            

                             <div class="form-group">

                                   <input style="width:160%;;"  type="text" name="nomh"    
                                   placeholder="Chercher sur: Nom de femme/Nom d'homme/الاسم العائلي/CIN" 
                                   class="form-control"
                                   value="<?php  echo $nomh;   ?>"

                                   onchange="this.form.submit()" />
                          
                           
                                            
                      
                                          <button type="submit" class="btn btn-success">
                                                 <span class="glyphicon glyphicon-search"></span> 
                                                        Chercher...
                                          </button>
                                          &nbsp;&nbsp;
                                          <a href="nouvelleMariage.php">
                                                 <span class="glyphicon glyphicon-plus"></span>
                                                 Nouvelle mariage
                                          </a>   
                                    </div>
                            </form>
                
                      </div>
              </div>

              <div style="width:114%;"  class="panel panel-danger">
                <div class="panel-heading"> Nombre de mariage: <?php echo $nbrNaissance;  ?> couples </div>
             
                  <div class="panel-body  " >
                     <table  style="width:114%; " class="table table-striped table-bordered">
                            <thead>
                                 <tr>
                                 <th>Id Mariage</th>
                                 <th>رقم المحكمة الابتدائية</th>
                                 <th>Date de mariage</th>
                                 <th>N° de dossier</th>
                                 <th>Temp</th>
                                 <th>date de marige (ميلادي)</th>
                                 <th>date de marige (هجري)</th>
                                 <th>الوصل</th>
                                 <th>  الاسم العائلي للزوج</th>
                                 <th>الاسم الشخصي للزوج</th>
                                 <th>مكان الولادة للزوج</th>
                                 <th>تاريخ الولادة للزوج</th>
                                 <th>CIN</th>
                                 <th> الاسم العائلي للزوجة</th>
                                 <th>الاسم الشخصي للزوجة</th>
                                 <th>مكان الولادة للزوجة</th>
                                 <th>تاريخ الولادة للزوجة</th>
                               <th>CIN</th>
                                 <th>Date de l'acte</th>
                   
                                 
                               
                                 <th >   Action</th>
                                 </tr>  
                            </thead>
                            <tbody>
                                  
                                     <?php while($naissance=$resultatD->fetch()){ ?>
                                        <tr>
                                            
                                            <td><?php echo $naissance['idMar'] ?>  </td>
                                            <td><?php echo $naissance['numMAH'] ?>  </td>
                                            <td><?php echo $naissance['dateM'] ?>  </td>
                                            <td><?php echo $naissance['numdossier'] ?>  </td>
                                            <td><?php echo $naissance['time'] ?>  </td>
                                            <td><?php echo $naissance['dateMam'] ?>  </td> 
                                            <td><?php echo $naissance['dateMah'] ?>  </td>  
                                            <td><?php echo $naissance['wasl'] ?>  </td>
                                            <td><?php echo $naissance['nomh'] ?>  </td>
                                            <td><?php echo $naissance['prenomh'] ?>  </td>
                                            <td><?php echo $naissance['villeh'] ?>  </td>
                                            <td><?php echo $naissance['dateNeh'] ?>  </td>
                                            <td><?php echo $naissance['cinh'] ?>  </td>
                                            <td><?php echo $naissance['nomf'] ?>  </td>
                                            <td><?php echo $naissance['prenomf'] ?>  </td>
                                            <td><?php echo $naissance['villef'] ?>  </td>
                                            <td><?php echo $naissance['dateNef'] ?>  </td>
                                            <td><?php echo $naissance['cinf'] ?>  </td>
                                            <td><?php echo $naissance['date_acteH'] ?>  </td>
                                           
                                            
                                           
                                             <td style="width:100px">
                                                        
                                                    <a  href="vueRma.php?idD=<?php echo $naissance['idMar'] ?> "> 
                                                        <i class="fa fa-eye" style="font-size:20px;color:gris"></i>
                                                    </a>
                                                    &nbsp;
                                                   

                                                    

                                              </td>
                                              
                                          </tr>
                                      <?php } ?>
                            
                                    
                            </tbody>
                     </table>
                    

                                          <div>
                                          
                                          <ul class="nav nav-pills">
                                          <?php for($i=1;$i<=$nbrPage;$i++){ ?>
                            <li class="<?php if($i==$page) echo 'active' ?>"> 
                                   <a href="Rma.php?page=<?php echo $i;?>&nomf=<?php echo $nomf ?>&nomh=<?php echo $nomh ?>&numdossier=<?php echo $numdossier ?>">
                                          <?php echo $i; ?>
                                   </a> 
                            </li>
                                  <?php } ?>
                                          </ul>
                        </div>

                 </div>
         </div>
</div>  
</div>  
 </div>
</body>
</html>








