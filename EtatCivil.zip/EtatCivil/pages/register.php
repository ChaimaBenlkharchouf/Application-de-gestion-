
<!DOCTYPE HTML>
<html>
<head>
<?php   require_once('identifier.php');
?>
<meta charset="utf-8">
<title>Register pour les naissances - décés - mariage / تسجيلا الولادة - الوفيات - الزواج</title>

<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../css/monstyle.css">

<style>
div.cont{

    float:left; 
    margin:10px;  
}


div span img {
    font-size: 1.2rem;
    padding: 80px 90px;
    margin: 10px 0;
    background: #F8E0E6;
    z-index: 5;
    position: relative;
    cursor: pointer;
    transition: all .4s;
}
div span   img::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 5px;
    height: 100%;
    z-index: -1;
    transition: all .4s;
}

div:hover::before {
    width: 100%;
}

div:nth-child(1)::before {
    background: #4285f4;
}

div :nth-child(2)::before {
    background: #db4437;
}

div:nth-child(3)::before {
    background: #f4b400;
}

div:nth-child(4)::before {
    background: #0f9d58;
}
div span  img:hover {
    transform: translateX(20px);
}
</style>


</head>
<body  style="background-image: url('../images/zh1.jpg')"; >
    <?php include("menu.php");?>
    <div class=" container"> 

<div class="  margetop">
        <div class="panel-heading" align="center">           <font style=" font:bold 44px 'Aleo'; text-shadow:1px 1px 25px #000; color:#fff;"><center>REGISTER D'ETAT CIVIL</center></font>
 </div>
     
           </div> 


<br><br>


        <div align ="center" class="cont"><span><a href="Rne.php"><img src="../images/bb1.jpg" alt="Naissance" width="70%"></a> </span></div>
        <div align ="right" class="cont"><span><a  href=" Rde.php"><img src="../face/assets/mort.jpg" alt="deces" width="70%" > </a></span></div>      <br>      
        <div align ="left" class="cont"><span><a href="Rma.php"><img src="../images/mar.jpg" alt="mariage" width="70%" ></span></a>             





 </div>
</div>  

</body>
</html>