<?php

              require_once("connexiondb.php");

              $nomh=isset($_GET['nomh'])?$_GET['nomh']:"";
              $nomf=isset($_GET['nomf'])?$_GET['nomf']:"";
              $cinf=isset($_GET['cinf'])?$_GET['cinf']:"";
              $cinh=isset($_GET['cinh'])?$_GET['cinh']:"";
              $numdossier=isset($_GET['numdossier'])?$_GET['numdossier']:"";




              $nomd=isset($_GET['nomD'])?$_GET['nomD']:"all";
              

              $size= isset($_GET['size'])?$_GET['size']:5;
              $page=isset($_GET['page'])?$_GET['page']:1 ;
              $offset=($page-1)*$size;

       
       if($nomd=="all")
       {
              
              $requete="select * from mariage
              where (nomh like '%$nomh%' or nomf like '%$nomh%'
           
              or numdossier like '%$nomh%' or cinf like '%$nomh%'
              or cinh like '%$nomh%')
              limit $size offset $offset ";

              $requeteCount="select count(*) countD from mariage
              where (nomh like '%$nomh%' or nomf like '%$nomh%'
              or cinh like '%$nomh%' or cinf like '%$nomh%'
              or numdossier like '%$nomh%')";

      }
      else{
              $requete="select * from mariage
              where nomh like '%$nomh%'and (nomf like '%$nomh%')
              and numdossier like '%$nomh%'
              and cinh like '%$nomh%' and cinf like '%$nomh%'
              and page='$nomd' 
              
              limit $size  offset $offset ";

              $requeteCount="select count(*) countD mariage
              where (nomh like '%$nomh%' or nomf like '%$nomh%'
              or cinh like '%$nomh%' or cinf like '%$nomh%'
              or numdossier like '%$nomh%')
            

              and page='$nomd' ";

       }
              $resultatD=$pdo->query($requete);
              $resultatCount=$pdo->query($requeteCount);
              $tabCount=$resultatCount->fetch();
              $nbrNaissance=$tabCount['countD'];
              $reste=$nbrNaissance % $size;

              if($reste===0)
                     $nbrPage=$nbrNaissance/$size;
              else
                     $nbrPage=floor($nbrNaissance/$size) + 1;

       
?>

<!DOCTYPE HTML>
<html>
       <head>
              <meta charset="utf-8">
              <title>Acte de mariage  </title>
              <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
              <link rel="stylesheet" type="text/css" href="../css/champ.css">

              <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
              <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">

              <meta name="viewport" content="width=device-width, initial-scale=1">
              <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

              <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

       </head>
       <body  style="background-image: url('../images/zh1.jpg')"; >
      
       <?php include("menu2.php");?><br><br><br><br><br>
      
       <div  class="container"> 

      
        <div   class="panel panel-success margetop">
                <div class="panel-heading">Espace d'utilisateur</div>

                    <div class="panel-body">
                      <form align="center" method="get" action="vueVisiteurM.php"  class="form-inline">
                            

                             <div class="form-group" > 
                          <div>
                      <label for="nomh">CIN de femme: &nbsp;&nbsp;</label>
                        <nav>   
                        

                              <input style="width:160%;"  type="text" name="nomf"    
                                   placeholder="Tapez le numéro de la carte natinale de femme" 
                                   class="form-control"
                                   value="<?php  echo $nomh;   ?>"required/>
                        </nav>
              
            <label for="nomh">CIN d'homme: &nbsp;&nbsp;</label>
                        <nav>   
                      

                              <input style="width:160%;"  type="text" name="nomh"    
                                   placeholder="Tapez le numéro de la carte natinale d'homme" 
                                   class="form-control"
                                   value="<?php  echo $nomh;   ?>"required/>
                        </nav>
</div>
                                          <button type="submit" class="btn btn-success">
                                                 <span ></span> 
                                                 Validé
                                          </button>
                                          &nbsp;&nbsp;
                                        

                                    </div>
                            </form>
                
                      </div>
              </div>



</body>
</html>








