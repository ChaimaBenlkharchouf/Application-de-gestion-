<?php
     
              require_once("connexiondb.php");

              $N_acte=isset($_GET['N_actenum'])?$_GET['N_actenum']:"";
              $nom=isset($_GET['nom'])?$_GET['nom']:"";
              $nomarabeN=isset($_GET['nomarabeN'])?$_GET['nomarabeN']:"";




              $nomd=isset($_GET['nomD'])?$_GET['nomD']:"all";
              

              $size= isset($_GET['size'])?$_GET['size']:5;
              $page=isset($_GET['page'])?$_GET['page']:1 ;
              $offset=($page-1)*$size;

       
       if($nomd=="all")
       {
              
              $requete="select * from naissance
              where (nom like '%$N_acte%' or N_acte like '%$N_acte%'
           
              or nomarabeN like '%$N_acte%')
              limit $size offset $offset ";

              $requeteCount="select count(*) countD from naissance
              where (nom like '%$N_acte%' or N_acte like '%$N_acte%'
              
              or nomarabeN like '%$N_acte%')";

      }
      else{
              $requete="select * from naissance
              where nom like '%$nom%'and (N_acte like '%$N_acte%')
              and nomarabeN like '%$nomarabeN%'
            
              and typeDeclaration='$nomd' 
              
              limit $size  offset $offset ";

              $requeteCount="select count(*) countD naissance
              where (nom like '%$N_acte%' or N_acte like '%$N_acte%'

              or nomarabeN like '%$N_acte%')
            

              and typeDeclaration='$nomd' ";

       }
              $resultatD=$pdo->query($requete);
              $resultatCount=$pdo->query($requeteCount);
              $tabCount=$resultatCount->fetch();
              $nbrNaissance=$tabCount['countD'];
              $reste=$nbrNaissance % $size;

              if($reste===0)
                     $nbrPage=$nbrNaissance/$size;
              else
                     $nbrPage=floor($nbrNaissance/$size) + 1;

       
?>

<!DOCTYPE HTML>
<html>
       <head>
              <meta charset="utf-8">
              <title>Acte de naissance  </title>
              <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
              <link rel="stylesheet" type="text/css" href="../css/champ.css">

              <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
              <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">

              <meta name="viewport" content="width=device-width, initial-scale=1">
              <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

              <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

       </head>
       <body  style="background-image: url('../images/zh1.jpg')";  >
       <?php include("menu2.php");?><br><br><br><br><br>
    
      <br><br><br>
       <div style="text-align:center;" class="container"> 

      
        <div class="panel panel-success margetop">
                <div class="panel-heading">Espace d'utilisateur</div>

                    <div class="panel-body">
                      <form method="get" action="vueVisiteur.php"  class="form-inline">
                            

                             <div class="form-group">  
                                   <label for="nom">Nom :&nbsp;&nbsp;</label>

                                   <input   type="text" name="nom"    
                                   placeholder="Taper votre Nom/الاسم العائلي " 
                                   class="form-control"
                                   value="<?php  echo $N_acte;   ?>" required/> 
                             <label for="N_actenum">N° d'acte :</label>

                                   <input   type="text" name="N_actenum"    
                                   placeholder="Taper votre N° d'acte" 
                                   class="form-control"
                                   value="<?php  echo $N_acte;   ?>"required/> <br><br><br>
                               <br><br>
                          
                                          <button type="submit" class="btn btn-success">
                                                 <span ></span> 
                                                 Validé
                                          </button>
                                         
                                    </div>
                            </form>
                
                      </div>
              </div>


</body>
</html>








