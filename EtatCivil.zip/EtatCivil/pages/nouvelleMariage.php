<?php
    require_once('identifier.php');
    require_once('connexiondb.php');
   
    $requete="select * from mariage";
    $resultatD=$pdo->query($requete);

?>
<!DOCTYPE HTML>
<html>
        <head>
            <meta charset="utf-8">
                    <title>nouvelle mariage</title>

                    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
                    <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
                    <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
                    <link rel="stylesheet" type="text/css" href="../css/champ.css">

       </head>
    <body>

        <?php include("menu.php");?>
                <div class=" container"> 


                    <div class="panel panel-danger margetop">
                          
                            <div class="panel-heading">Veuiller saisir les données des mariés</div>
                               
                                <div class="panel-body">
                                        <form method="post" action="insertMariage.php" class="form" align="right">
                                            
                                                <div class="form-group">

                                                    <label for="nomD"> :رقم المحكمة الابتدائية</label>
                                                    <input type="text" name="numMAH" 
                                                    placeholder=" أدخل رقم قسم قضاء الأسرة بالمحكمة الابتدائية بالجديدة " 
                                                    class="form-control"required/><br>
                                                </div>

                                                
                                                    
                                                <div class="form-group" >
                                                    <label for="nomD">:تاريخ الطلب </label>   
                                                    <input type="date" name="dateM"  id="date"
                                                    placeholder="أدخل تاريخ الطلب الزواج " 
                                                    class="form-control"required /> <br>
                                                    </div>
                                                    <div class="form-group" >
                                                    <label for="nomD">:رقم الملف</label>   
                                                    <input type="text" name="numdossier" 
                                                    placeholder="أدخل رقم ملف مستندات الزواج  " 
                                                    class="form-control"required/> <br>
                                                    </div>
                                                    <div class="form-group" >
                                                    <label for="nomD">:على الساعة  </label>   
                                                    <input type="text" name="time" 
                                                    placeholder="أدخل وقت تسجيل الطلب " 
                                                    class="form-control"required/> <br>
                                                    </div>
                                                    <div class="form-group" >
                                                    <label for="nomD">: تاريخ الزواج (ميلادي) </label>   
                                                    <input type="date" name="dateMam" 
                                                    placeholder="أدخل تاريخ الزواج الميلادي " 
                                                    class="form-control"required/> <br>
                                                    </div>
                                                    <div class="form-group" >
                                                    <label for="nomD">:تاريخ الزواج(هجري) </label>   
                                                    <input type="date" name="dateMah" 
                                                    placeholder="أدخل تاريخ الزواج الهجري   " 
                                                    class="form-control"required/> <br>
                                                    </div>
                                                

                                                    <div class="form-group">
                                                    <label for="nomD">:اسم العدل الأول </label>
                                                    <input type="text" name="nomadl1" 
                                                    placeholder="أدخل اسم العدل الأول" 
                                                    class="form-control"required/><br>
                                                    </div>
                                                    
                                                 
                                                   

                                                <div class="form-group">

                                                    <label for="nomD">:اسم العدل الثاني </label>
                                                    <input type="text" name="nomadl2" 
                                                    placeholder=" (أدخل اسم العدل الثاني(ة" 
                                                    class="form-control"required/><br>
                                                </div>
                                                <div class="form-group">
                                                    <label for="nomD"> :الصفحة</label>
                                                    <input type="text" name="page" 
                                                    placeholder="  أدخل رقم الصفحة " 
                                                    class="form-control"required/><br>
                                                    </div>
                                                <div class="form-group">
                                                    <label for="nomD">:عدد</label>
                                                    <input type="text" name="numero " 
                                                    placeholder="أدخل عدد الملف" 
                                                    class="form-control"required/><br>
                                                    </div>

                                                    
                                                <div class="form-group">
                                                    <label for="nomD"> : الوصل</label>
                                                    <input type="text" name="wasl" 
                                                    placeholder="أدخل رقم الوصل  " 
                                                    class="form-control"required/><br>
                                                    </div>

                                                    <div class="form-group">
                                                    <label for="nomD">:الاسم العائلي للزوج </label>
                                                    <input type="text" name="nomh" id="nm"
                                                    placeholder=" أدخل الاسم العائلي للزوج" 
                                                    class="form-control"required/><br>
                                                    </div>
                                                    <div class="form-group">
                                                    <label for="nomD">:الاسم الشخصي للزوج </label>
                                                    <input type="text" name="prenomh" 
                                                    placeholder=" أدخل الاسم الشخصي للزوج  " 
                                                    class="form-control"required/><br>
                                                    </div>
                                                    <div class="form-group">
                                                    <label for="nomD">:تاريخ ازدياد الزوج </label>
                                                    <input type="date" name="dateNeh" 
                                                    placeholder=" (أدخل تاريخ الولادة (ميلادية" 
                                                    class="form-control"required/><br>
                                                    </div>
                                                    
                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">مكان ازدياد الزوج</label>
                                                    <input type="text" name="villeh" 
                                                    placeholder="أدخل مكان ازدياد الزوج" 
                                                    class="form-control"required/><br>
                                                    </div>

                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">:اسم أب الزوج</label>
                                                    <input type="text" name="prph" 
                                                    placeholder=" أدخل اسم أب الزوج" class="form-control" required/><br>
                                                    </div>
                                                
                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">:اسم أم الزوج</label>
                                                    <input type="text" name="mereh" 
                                                    placeholder="أدخل اسم أم الزوج  " 
                                                    class="form-control"required/><br>
                                                    </div>

                                                    <div class="form-group">
                                                    <label for="nomD">جنسيته </label>
                                                    <input type="text" name="nationalh" 
                                                    placeholder=" أدخل جنسية الزوج" 
                                                    class="form-control"required/><br>
                                                    </div>

                                                    <div class="form-group">
                                                    <label for="nomD">:مهنته</label>
                                                    <input type="text" name="travailh" 
                                                    placeholder=" أدخل مهنة الزوج" 
                                                    class="form-control"required/><br>
                                                    </div>

                                                    <div class="form-group">
                                                    <label for="nomD">:الساكن في </label>
                                                    <input type="text" name="habiteh" 
                                                    placeholder="أدخل مقر سكن الزوج " 
                                                    class="form-control"required/><br>
                                                    </div>

                                                    <div class="form-group">
                                                    <label for="nomD">CIN</label>
                                                    <input type="text" name="cinh" 
                                                    placeholder="أدخل رمز البطاقة الوطنية" 
                                                    class="form-control"required/><br>
                                                    </div>

                                                    <div class="form-group">
                                                    <label for="nomD">:حالته</label>
                                                    <input type="text" name="etath" 
                                                    placeholder="(أدخل حالة الزوج (عازب /مطلق/ أرمل" 
                                                    class="form-control"required/><br>
                                                    </div>
    

                                                    <div class="form-group">
                                                    <label for="nomD">:الاسم العائلي للزوجة </label>
                                                    <input type="text" name="nomf" 
                                                    placeholder=" أدخل الاسم العائلي للزوجة " 
                                                    class="form-control"required/><br>
                                                    </div>
                                                    <div class="form-group">
                                                    <label for="nomD">:الاسم الشخصي للزوجة </label>
                                                    <input type="text" name="prenomf" 
                                                    placeholder="  أدخل الاسم الشخصي للزوجة " 
                                                    class="form-control"required/><br>
                                                    </div>
                                                    <div class="form-group">
                                                    <label for="nomD">:تاريخ ازدياد الزوجة </label>
                                                    <input type="date" name="dateNef" 
                                                    placeholder=" (أدخل تاريخ ازدياد الزوجة(ميلادية" 
                                                    class="form-control"required/><br>
                                                    </div>
                                                    
                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">مكان ازدياد الزوجة</label>
                                                    <input type="text" name="villef" 
                                                    placeholder="أدخل مكان ازدياد الزوجة " 
                                                    class="form-control"required/><br>
                                                    </div>

                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">:اسم أب الزوجة</label>
                                                    <input type="text" name="prpf" 
                                                    placeholder="أدخل اسم أب الزوجة "
                                                    class="form-control"required/><br>
                                                    </div>
                                                
                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">CIN de pére</label>
                                                    <input type="text" name="cinprpf" 
                                                    placeholder="أدخل رمز البطاقة الوطنية للأب "
                                                    class="form-control"required/><br>
                                                    </div>
                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">:تاريخ ازدياد الأب </label>
                                                    <input type="date" name="neprpf" 
                                                    placeholder="(أدخل  تاريخ ازدياد الأب (ميلادي "
                                                    class="form-control"required/><br>
                                                    </div>
                                                    <div class="form-group">
                                                    <label for="nomD">: جنسية الأب </label>
                                                    <input type="text" name="nationalprpf" 
                                                    placeholder=" أدخل جنسية الأب  "
                                                    class="form-control"required/><br>
                                                    </div>

                                                    <div class="form-group">
                                                    <label for="nomD">:مهنة الأب </label>
                                                    <input type="text" name="travailprpf" 
                                                    placeholder="أدخل مهنة الأب "
                                                    class="form-control"required/><br>
                                                    </div>
                                                
                                                    <div class="form-group">
                                                    <label for="nomD">:اسم أم الزوجة</label>
                                                    <input type="text" name="meref" 
                                                    placeholder="أدخل اسم أم الزوجة  " 
                                                    class="form-control"required/><br>
                                                    </div>

                                                    <div class="form-group">
                                                    <label for="nomD">جنسيتها</label>
                                                    <input type="text" name="nationalf" 
                                                    placeholder="أدخل جنسية الزوجة   " 
                                                    class="form-control"required/><br>
                                                    </div>

                                                    <div class="form-group">
                                                    <label for="nomD">:مهنتها</label>
                                                    <input type="text" name="travailf" 
                                                    placeholder="أدخل مهنة الزوجة" 
                                                    class="form-control"required/><br>
                                                    </div>

                                                    <div class="form-group">
                                                    <label for="nomD">:الساكنة في </label>
                                                    <input type="text" name="habitef" 
                                                    placeholder="أدخل مقر سكن الزوجة " 
                                                    class="form-control"required/><br>
                                                    </div>
                                             
                                                 <div class="form-group">
                                                    <label for="pnomDhoto">Photo d'homme: </label>
                                                    <input type="file" name="photo" 
                                                    class="form-control" required/><br>
                                                    </div>
                                                    <div class="form-group">
                                                    <label for="pnomDhotof">Photo de femme: </label>
                                                    <input type="file" name="photof" 
                                                
                                                    class="form-control"required/><br>
                                                    </div>


                                                    <div class="form-group">
                                                    <label for="nomD">CIN</label>
                                                    <input type="text" name="cinf" 
                                                    placeholder="أدخل رمز البطاقة الوطنية للزوجة" 
                                                    class="form-control"required/><br>
                                                    </div>

                                                    <div class="form-group">
                                                    <label for="nomD">:حالتها</label>
                                                    <input type="text" name="etatf" 
                                                    placeholder="(أدخل حالة الزوجة (عازب /مطلق/ أرمل" 
                                                    class="form-control"required/><br>
                                                    </div>
                                                    
                                                    <div class="form-group">
                                                    <label for="nomD">:الصداق</label>
                                                    <input type="text" name="prix" 
                                                    placeholder="الصداق المتفق عليه بالدرهم " 
                                                    class="form-control"required/><br>
                                                    </div>
                                                    <div class="form-group">
                                                    <label for="nomD">:تاريخ العقد (ميلادي) </label>
                                                    <input type="date" name="date_acteM" 
                                                    placeholder=" أدخل تاريخ العقد (ميلادي) "
                                                    class="form-control"required/><br>
                                                    </div>
                                                    <div class="form-group">
                                                    <label for="nomD">:تاريخ العقد (هجري) </label>
                                                    <input type="date" name="date_acteH" 
                                                    placeholder="أدخل تاريخ العقد (هجري) "
                                                    class="form-control"required/><br>
                                                    </div>

                                                    <button type="button" class="btn btn-primary" id="submit">
                                                        <span class="glyphicon glyphicon-envelope" class="material-icons"></span> 
                                                           <b> Envoyer </b>
                                                     </button>
                                  
                                                        <button type="submit" class="btn btn-success" >

                                                                <span class="glyphicon glyphicon-save"></span> 
                                                                    Enregistrer
                                                        </button>

                                            </form>

                                            
                                      
                                </div>
                    </div>
                </div>  

    </body>
</html>