<meta charset="utf-8">
    <title>Contactez-nous</title>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
<nav class="navbar navbar-inverse navbar-fixed-top">

    <div class="container-fluid">
        <div class ="navbar-header">
            
              <a href="../face/acceuil.php" class="navbar-brand">Etat Civil</a>
        </div>
        <ul class="nav navbar-nav">
        
        </li>
            <li><a href="../face/bureau.php">Guide de l'état civil  </a>  
        
            
        </li>
            <li><a href="../pages/visiteur.php">Services électroniques</a>   </li>  
                <li><a href="../face/Mar.php">Marocains à l'étranger</a></li>
                        <li><a href="../face/Etrang.php">Etrangers au Maroc</a></li>
                       
                        <li>
                    

                
                        <li><a href="../pages/login.php" > Administration</a></li>
                        <li><a href="../pages/visiteur.php">Visiteur</a></li>
                
            <li><a href="../contact/index.php">Contact</a>    </li> 

          
           
                </ul>

      

    </div>
</nav>


