<?php
    require_once('identifier.php');

    require_once('connexiondb.php');

    $iduser=isset($_POST['iduser'])?$_POST['iduser']:0;

    $login=isset($_POST['login1'])?$_POST['login1']:"";

    $email=isset($_POST['email'])?strtoupper($_POST['email']):"";
   
    $role=isset($_POST['role1'])?$_POST['role1']:"";

    $requete="update utilisateur set login1=?,email=?,role1=? where iduser=?";

    $params=array($login,$email,$role,$iduser);

    $resultat=$pdo->prepare($requete);

    $resultat->execute($params);
    
    header('location:login.php');
?>
