<?php
     
              require_once("connexiondb.php");

              $N_acte=isset($_GET['N_actenum'])?$_GET['N_actenum']:"";
              $nom=isset($_GET['nom'])?$_GET['nom']:"";
              $nomarabeN=isset($_GET['nomarabeN'])?$_GET['nomarabeN']:"";




              $nomd=isset($_GET['nomD'])?$_GET['nomD']:"all";
              

              $size= isset($_GET['size'])?$_GET['size']:5;
              $page=isset($_GET['page'])?$_GET['page']:1 ;
              $offset=($page-1)*$size;

       
       if($nomd=="all")
       {
              
              $requete="select * from naissance
              where (nom like '%$N_acte%' or N_acte like '%$N_acte%'
           
              or nomarabeN like '%$N_acte%')
              limit $size offset $offset ";

              $requeteCount="select count(*) countD from naissance
              where (nom like '%$N_acte%' or N_acte like '%$N_acte%'
              
              or nomarabeN like '%$N_acte%')";

      }
      else{
              $requete="select * from naissance
              where nom like '%$nom%'and (N_acte like '%$N_acte%')
              and nomarabeN like '%$nomarabeN%'
            
              and typeDeclaration='$nomd' 
              
              limit $size  offset $offset ";

              $requeteCount="select count(*) countD naissance
              where (nom like '%$N_acte%' or N_acte like '%$N_acte%'

              or nomarabeN like '%$N_acte%')
            

              and typeDeclaration='$nomd' ";

       }
              $resultatD=$pdo->query($requete);
              $resultatCount=$pdo->query($requeteCount);
              $tabCount=$resultatCount->fetch();
              $nbrNaissance=$tabCount['countD'];
              $reste=$nbrNaissance % $size;

              if($reste===0)
                     $nbrPage=$nbrNaissance/$size;
              else
                     $nbrPage=floor($nbrNaissance/$size) + 1;

       
?>

<!DOCTYPE HTML>
<html>
       <head>
              <meta charset="utf-8">
              <title>Espace d'utilisateur  </title>
              <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
              <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
              <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">

              <meta name="viewport" content="width=device-width, initial-scale=1">
              <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

              <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

       </head>
       <body  style="background-image: url('../images/zh1.jpg')";  >
      
       <?php include("menu2.php");?><br><br>      
       <br><br><br><br><br>


              <div   class="panel panel-danger"> 
                  <?php if($naissance=$resultatD->fetch()){ ?>
                <div class="panel-heading"> Nom de personne: <?php echo $naissance['nom'] ?> </div>
              
                <div    class="panel-body">
                     <table  class="table table-striped table-bordered">
                            <thead>
                            <tr>
                          
                                 <th>N° d'acte</th>
                                 <th>Nom</th>
                                 <th>Prénom</th>
                              
                               
                                 <th>Date de l'acte</th>
                                    
                                 <th >   Action</th>
                                 </tr>  
                            </thead>
                            <tbody>
                                    
                                        <tr>
                                            
                                            <td><?php echo $naissance['N_acte'] ?>  </td>
                                            <td><?php echo $naissance['nom'] ?>  </td>
                                            <td><?php echo $naissance['prenom'] ?>  </td>
                                            <td><?php echo $naissance['date_acte'] ?>  </td>
                                           
                                             <td >
                                                        
                                                    <a  href="vueNeVisiteur.php?idD=<?php echo $naissance['idNaissance'] ?> "> 
                                                        <i> Clicket ICI pour Imprimer l'acte</i>
                                                    </a>
                                         
                                              </td>
                                           
                                          </tr>
                                
                            
                                    
                            </tbody>
                     </table>


                 </div>
               <?php } ?>
</div>  

</body>
</html>








