<?php
    require_once('identifier.php');
    require_once('connexiondb.php');

    $iduser=isset($_GET['iduser'])?$_GET['iduser']:0;

    $requeteuser="select * from utilisateur where iduser=$iduser";
    $resultatuser=$pdo->query($requeteuser);
    $user=$resultatuser->fetch();

    $login=$user['login1'];
    $email=$user['email'];
    $role=strtoupper($user['role1']);


?>
<! DOCTYPE HTML>
<HTML>
    <head>
        <meta charset="utf-8">
        <title>Edition de l'utilisateur</title>
        <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
        <link rel="stylesheet" type="text/css" href="../css/champ.css">

    </head>
    <body  style="background-image: url('../images/zh1.jpg')"; >
        <?php include("menu.php"); ?>
        
        <div class="container">
                       
             <div class="panel panel-danger margetop">
                <div class="panel-heading">Edition de l'utilisateur :</div>
                <div class="panel-body">
                    <form method="post" action="updateUser.php" class="form" >
						<div class="form-group">
                             <label for="iduser">id : <?php echo $iduser ?></label>
                            <input type="hidden" name="iduser" class="form-control"
                             value="<?php echo $iduser ?>"required/>
                        </div>
                        <div class="form-group">
                             <label for="login1">Login :</label>
                            <input type="text" name="login1" placeholder="Login" class="form-control" 
                            value="<?php echo $login ?>"required/>
                        </div>
                        <div class="form-group">
                             <label for="email">Email :</label>
                            <input type="text" name="email" placeholder="Email" class="form-control"
                                   value="<?php echo $email ?>"required/>
                        </div>
                     
        

				        <button type="submit" class="btn btn-success">
                            <span class="glyphicon glyphicon-save"></span>
                            Enregistrer
                        </button> 
                        &nbsp;&nbsp;
 &nbsp;&nbsp;
                        <a href="editerPwd.php?iduser=<?php echo $iduser ?>">Changer le mot de passe</a>

					</form>
                </div>
            </div>   
        </div>      
    </body>
</HTML>