<?php
require_once('identifier.php');
require_once("connexiondb.php");

              $nomd=isset($_GET['nomD'])?$_GET['nomD']:"all";
              $num=isset($_GET['num'])?$_GET['num']:"";

              $size= isset($_GET['size'])?$_GET['size']:5;
              $page=isset($_GET['page'])?$_GET['page']:1 ;
              $offset=($page-1)*$size;

       
       if($nomd=="all")
       {
              $requete="select * from declares
              where num like '%$num%'
              limit $size offset $offset ";

              $requeteCount="select count(*) countD from declares
              where num like '%$num%'";

      }
      else{
              $requete="select * from declares
              where  num like '%$num%' 
              and typeDeclaration='$nomd'
              
              limit $size  offset $offset ";

              $requeteCount="select count(*) countD from declares
              where num like '%$num%'
              and typeDeclaration='$nomd'
              ";
       }
              $resultatD=$pdo->query($requete);
              $resultatCount=$pdo->query($requeteCount);
              $tabCount=$resultatCount->fetch();
              $nbrDeclaration=$tabCount['countD'];
              $reste=$nbrDeclaration % $size;

              if($reste===0)
                     $nbrPage=$nbrDeclaration/$size;
              else
                     $nbrPage=floor($nbrDeclaration/$size) + 1;

       
?>

<!DOCTYPE HTML>
<html>
       <head>
              <meta charset="utf-8">
              <title>Gestion déclaration</title>
              <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
              <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
              <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">

              <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


       </head>
       <body  style="background-image: url('../images/zh1.jpg')"; >
      
       <?php include("menu.php");?>
      
       <div class="container"> 

      
        <div class="panel panel-success margetop">
                <div class="panel-heading">Rechercher des déclaration...</div>

                    <div class="panel-body">
                      <form method="get" action="déclaration.php"  class="form-inline">
                             <div class="form-group">

                                   <input type="text" name="num" 
                                   placeholder="Numéro de déclaration" 
                                   class="form-control"
                                   value="<?php echo $num  ?>"
                                   onchange="this.form.submit()" />

                             </div> 
                                                    
                           
                              <label for="nomD" >Type :</label>  
                                   <select name="nomD" class="form-control" id="nomD" 
                                           onchange="this.form.submit()">
                                          <option value="all" <?php  if($nomd==="all")  echo "selected" ?>> Tout les types</option>
                                          <option value="DN"  <?php  if($nomd==="DN")  echo "selected"  ?>> DN( Declaration de naissance normale )</option>
                                          <option value="DNC" <?php  if($nomd==="DNC")  echo "selected" ?>> DNC( Declaration de naissance cas voyage )</option>
                                          <option value="DNE" <?php  if($nomd==="DNE") echo "selected"  ?>> DNE( Declaration de naissance d"enfant abandonné )</option>
                                          <option value="DD"  <?php  if($nomd==="DD")  echo "selected"  ?>> DD( Declaration de décées normale )</option>
                                          <option value="DDA" <?php  if($nomd==="DDA")  echo "selected" ?>> DDA( Declaration de décés anormales )</option>
                                   </select>
                                
                            
                                          <button type="submit" class="btn btn-success">
                                                 <span class="glyphicon glyphicon-search"></span> 
                                                        Chercher...
                                          </button>
                                          &nbsp;&nbsp;
                                          <?php if ($_SESSION['user']['role1']=='ADMIN')  { ?>
                                          <a href="nouvelleDéclaration.php">
                                                 <span class="glyphicon glyphicon-plus"></span>
                                                 Nouvelle déclaration
                                          </a>   
                                   <?php } ?>
                            </form>
                
                      </div>
              </div>


         <div class="panel panel-danger ">
                <div class="panel-heading">Nombre de déclaration (<?php echo $nbrDeclaration  ?> Déclarations) </div>
                  <div class="panel-body">
                     <table class="table table-striped table-bordered">
                            <thead>
                                 <tr>
                                 <th>Id déclaration</th>
                                 <th>Nom</th>
                                 <th>Prénom</th>
                                 <th>carte nationale</th>
                                 <th>Date de naissance</th>
                                 <th>Type de déclaration</th>
                                 <th>N° de déclaration</th>
                                 <?php if ($_SESSION['user']['role1']=='ADMIN')  { ?>
                                 <th>Action</th>
                                 <?php }?>
                                 </tr>  
                            </thead>
                            <tbody>
                                  
                                     <?php while($declares=$resultatD->fetch()){ ?>
                                        <tr>
                                            
                                            <td><?php echo $declares['idDeclaration'] ?>  </td>
                                            <td><?php echo $declares['nom'] ?>  </td>
                                            <td><?php echo $declares['prenom'] ?>  </td>
                                            <td><?php echo $declares['carteN'] ?>  </td>
                                            <td><?php echo $declares['date'] ?>  </td>
                                            <td><?php echo $declares['typeDeclaration'] ?>  </td>
                                            <td><?php echo $declares['num'] ?>  </td>
                                            <?php if ($_SESSION['user']['role1']=='ADMIN')  { ?>
                                             <td>
                                                        
                                                    <a  href="vueDeclaration.php?idD=<?php echo $declares['idDeclaration'] ?> "> 
                                                        <span class="fa fa-eye" style="font-size:20px;color:gris"></span>
                                                    </a>
                                                    &nbsp;
                                                    <a href="editerDéclaration.php?idD=<?php echo $declares['idDeclaration'] ?> ">
                                                         <span class="glyphicon glyphicon-edit"></span>
                                                        </a> 
                                                        &nbsp;
                                                    <a onclick="return confirm('Etes-vous sur de vouloir supprimer la déclaration')" 
                                                         href="supprimerDeclaration.php?idD=<?php echo $declares['idDeclaration'] ?> "> 
                                                        <span class="glyphicon glyphicon-trash"></span>
                                                    </a>

                                                    

                                              </td>
                                              <?php }?>
                                          </tr>
                                      <?php } ?>
                            
                                    
                            </tbody>
                     </table>

                                          <div>
                                          
                                          <ul class="nav nav-pills">
                                          <?php for($i=1;$i<=$nbrPage;$i++){ ?>
                            <li class="<?php if($i==$page) echo 'active' ?>"> 
                                   <a href="déclaration.php?page=<?php echo $i;?>&num=<?php echo $num ?>&nomD=<?php echo $nomd ?>">
                                          <?php echo $i; ?>
                                   </a> 
                            </li>
                                  <?php } ?>
                                          </ul>
                        </div>

                 </div>
         </div>
</div>  

</body>
</html>