

<?php
    require_once('../pages/connexiondb.php');

     require_once('../pages/identifier.php');
    
    



  $name=strtoupper(isset($_POST['name'])?$_POST['name']:"");
  $email=strtoupper(isset($_POST['email'])?$_POST['email']:"");
  $phone=strtoupper(isset($_POST['phone'])?$_POST['phone']:"");
  $message=strtoupper(isset($_POST['message'])?$_POST['message']:"");



  $query="insert into contact(name,email,phone,message) values(?,?,?,?)";
  $params=array($name,$email,$phone,$message);
  $resultatD=$pdo->prepare($query);
  $resultatD->execute($params);

  header('location:../face/Acceuil.php');


?>
