<?php
header("location:pages/calendr.php")
?>