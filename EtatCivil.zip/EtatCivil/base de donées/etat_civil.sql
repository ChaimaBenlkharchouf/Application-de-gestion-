
drop database if exists etat_civil;

create database if not exists etat_civil;

use etat_civil;

create table declares(
    idDeclaration int(4) auto_increment primary key,
    nom varchar(50),
    nomarabe varchar(50),
    prenom varchar(50),
    prenomarabe varchar(50),
    date varchar(50),
    ville varchar(50),
    carteN varchar(50),
    adress varchar(50),
    tele_email varchar(50),
    prp varchar(50),
    prparabe varchar(50),
    prm varchar(50),
    prmarabe varchar(50),
    typeDeclaration varchar(50),
    num varchar(50)
    
);
create  table naissance(
    idNaissance int(4) auto_increment primary key,
     N_acte varchar(50), 
    nom varchar(50),
    prenom varchar(50),
    ville varchar(50),
    date_naissance varchar(50),
    N_et_lieu_declaration varchar(50), 
    nom_anterieur varchar(50),
    nom_famille_confirme varchar(50),
    prenom_pere varchar(50),
    nom_mere varchar(50),
    prenom_mere varchar(50),
    date_acte varchar(50),
    carte_national varchar(100),
    typeDeclaration varchar(50),
    num varchar(50)
);


create table deces(
    idDeces int(4) auto_increment primary key,
    N_acte_d varchar(50),
    nom_d varchar(50),
    nom_darabe varchar(50),
    prenom_d varchar(50),
    prenom_darabe varchar(50),
    carte_national_d varchar(100),
    ville_d varchar(50),
    ville_darabe varchar(50),
    date_naissance_d varchar(50),
    datearabe varchar(50),
    corespD varchar(50),
    coresparabeD varchar(50), 
    national varchar(50),
  /*  N_et_lieu_declaration_d varchar(50), */
    travail_d varchar(50), 
    prenom_pere_d varchar(50),
    nationalp varchar(50),
    neprp varchar(50), 
    neprparabe varchar(50), 
    travail_dprp varchar(50), 
    prenom_mere_d varchar(50),
    nationalm varchar(50),
    neprm varchar(50),  
    neprparabe varchar(50), 
    travail_dprm varchar(50), 
    /*declarant varchar(50), */
    nom_antarabe_d
    
    date_acte_d varchar(50),
   
     idDeclaration int(4)
);


create table utilisateur(
    iduser int(4) auto_increment primary key,
    login1 varchar(50), 
    email varchar(255),
    role1 varchar(50),  
    etat int(1),
    pwd varchar(255)
   
);

Alter table naissance add constraint foreign key(idDeclaration) references declares(idDeclaration);
Alter table deces add constraint foreign key(idDeclaration) references declares(idDeclaration);




INSERT INTO declares(typeDeclaration,num) VALUES
	('DN','A'),
	('DNC','B'),
	('DNE','C'),
	('DD','D'),
	('DDA','E'),

    ('DN','A'),
	('DNC','B'),
	('DNE','C'),
	('DD','D'),
	('DDA','E'),
    
    ('DN','A'),
	('DNC','B'),
	('DNE','C'),
	('DD','D'),
	('DDA','E');

	
INSERT INTO utilisateur(login1,email,role1,etat,pwd) VALUES 
    ('admin','admin@gmail.com','ADMIN',1,md5('123')),
    ('user1','user1@gmail.com','VISITEUR',0,md5('123')),
    ('user2','user2@gmail.com','VISITEUR',1,md5('123'));	

INSERT INTO naissance(N_acte,nom,prenom,ville,date_naissance,N_et_lieu_declaration,nom_anterieur,nom_famille_confirme,prenom_pere,nom_mere,prenom_mere,date_acte,carte_national,idDeclaration) VALUES
    ('200110','CHAiMA','BENLKHARCHOUF','ELJADIDA','2000/07/18','ELJADIDA','BENLKHARCHOUF','BENLKHARCHOUF','ALI','NAZHA','AALAMI','Chrysantheme.jpg',1),
	('200111','lina','nouri','ELJADIDA','2013/01/15','ELJADIDA','NOURI','SAMOUNI','KHALID','NAJAT','WANIR','Desert.jpg',2),
    ('200112','HIBA','LWARDI','OUJDA','1994/12/01','ELJADIDA','LWARDI','LWARDI','AMINE','LAILA','KAWSSI','Hortensias.jpg',3),
    ('200113','KHADIJA','LMARI','ELJADIDA','2005/05/16','ELJADIDA','LAMRI','BENLKHARCHOUF','MOHAMMED','SALMA','NAJI','Meduses.jpg',1),     
    ('200114','ADAM','ZIANI','ELJADIDA','1999/03/09','ELJADIDA','YAHYA','NESSRIN','BOSSHABA','Penguins.jpg',2),
    ('200115','OUSSAMA','ALI','ELJADIDA','2018/11/30','ELJADIDA','JALAL','RACHIDA','SAHIBI','Tulipes.jpg',3),

    
    ('200110','CHAiMA','BENLKHARCHOUF','ELJADIDA','2000/07/18','ELJADIDA','BENLKHARCHOUF','BENLKHARCHOUF','ALI','NAZHA','AALAMI','Chrysantheme.jpg',1),
	('200111','lina','nouri','ELJADIDA','2013/01/15','ELJADIDA','NOURI','SAMOUNI','KHALID','NAJAT','WANIR','Desert.jpg',2),
    ('200112','HIBA','LWARDI','OUJDA','1994/12/01','ELJADIDA','LWARDI','LWARDI','AMINE','LAILA','KAWSSI','Hortensias.jpg',3),
    ('200113','KHADIJA','LMARI','ELJADIDA','2005/05/16','ELJADIDA','LAMRI','BENLKHARCHOUF','MOHAMMED','SALMA','NAJI','Meduses.jpg',1),     
    ('200114','ADAM','ZIANI','ELJADIDA','1999/03/09','ELJADIDA','YAHYA','NESSRIN','BOSSHABA','Penguins.jpg',2),
    ('200115','OUSSAMA','ALI','ELJADIDA','2018/11/30','ELJADIDA','JALAL','RACHIDA','SAHIBI','Tulipes.jpg',3),



     ('200110','CHAiMA','BENLKHARCHOUF','ELJADIDA','2000/07/18','ELJADIDA','BENLKHARCHOUF','BENLKHARCHOUF','ALI','NAZHA','AALAMI','Chrysantheme.jpg',1),
	('200111','lina','nouri','ELJADIDA','2013/01/15','ELJADIDA','NOURI','SAMOUNI','KHALID','NAJAT','WANIR','Desert.jpg',2),
    ('200112','HIBA','LWARDI','OUJDA','1994/12/01','ELJADIDA','LWARDI','LWARDI','AMINE','LAILA','KAWSSI','Hortensias.jpg',3),
    ('200113','KHADIJA','LMARI','ELJADIDA','2005/05/16','ELJADIDA','LAMRI','BENLKHARCHOUF','MOHAMMED','SALMA','NAJI','Meduses.jpg',1),     
    ('200114','ADAM','ZIANI','ELJADIDA','1999/03/09','ELJADIDA','YAHYA','NESSRIN','BOSSHABA','Penguins.jpg',2),
    ('200115','OUSSAMA','ALI','ELJADIDA','2018/11/30','ELJADIDA','JALAL','RACHIDA','SAHIBI','Tulipes.jpg',3);

select * from declares;
select * from naissance;
select * from deces;
select login1,pwd from utilisateur;


